<?php
include ('database/include.php');
if(!isset($_SESSION['userType'])){
    header("Location: ./signin.php");
}else{
    if(!isset($_SESSION['userType'])){
        session_unset();
        session_destroy();
        header("Location: ./signin.php");
    }
}
?>
<!doctype html>
<html lang="en">

<head>
    <title>About Us</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'poppins';
        }

        .aboutus p,
        h2 {
            color: #003975;
            font-weight: 500;
        }

        .card {
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23);
        }

        a {
            text-decoration: none;
        }

        li {
            list-style-type: none;
        }

        .card-text {
            font-size: small;
        }

        i {
            color: #003975;
        }
    </style>
    <?php include 'meta.php' ?>
</head>

<body>
<?php
        if($_SESSION['userType'] == 'admin'){
    ?>
    <!-- navigation bar  -->
    <section>
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"><img src="images/logo.png" width="70" height="70" alt=""></a>
                <button justify-content-end class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="justify-content-end collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link text-light" href="admin_home.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="cadets.php">Cadets</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="add_event.php">Events</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="attendance.php">Report</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="about_us.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </section>
    <?php    } else {
    ?>
    <!-- navigation bar for student -->
    <section>
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"><img src="images/logo.png" width="70" height="70" alt=""></a>
                <button justify-content-end class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="justify-content-end collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link text-light" href="student_dashboard.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="EnrollForm.php">Enroll Form</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="student_events.php">Events</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="studentProfile.php">Update Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="about_us.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </section>
    <?php    }
    ?>
    <div class="container aboutus mt-4">
        <center>
            <u style="color:#35b729 ;">
                <h2>Who We Are</h2>
            </u><br>
        </center>
        <p style="text-align: justify;">We are Team of Young and Enthusiastic IT Department Students bringing the solution for NCC Club of Vishwakarma Goverment Engineering College.Main motto of this portal is to reduce the efforts of Cadets and provide better service.We provide a Portal in which Cadets can see and enroll in various events of the NCC without any paper work. </p>
        <!-- </div> -->


        <div class="row" style="width: 100%;margin: 4rem 0;">
            <div class="col-md-5">
                <br>
                <h4>Guide:</h4>
                <div class="card text-center" style="width: 15rem;margin:0 auto;">
                    <img src="images/coordinator_DJV.jpeg" class="card-img-top" alt="...">
                    <h5 class=" card-title fw-bold">Dr. Dhaval J. Varia</h5>
                    <p class="card-text">Assistant Professor<br>
                        Ph. D.<br>
                        d.varia@vgecg.ac.in</p>
                </div>
            </div>

            <div class="col-md-7">
                <br>
                <h4>Students:</h4>
                <div class="row" style="width: 100%;margin:0">
                    <div class="col-lg-6 col-md-12">
                        <div class="card text-center p-3  mt-2" style="width: 15rem;margin:0 auto;">
                            <center>
                                <h5 class="card-title fw-bold ">1. Govind Gojiya</h5>
                                <p class="card-text">govind@duck.com</p>
                                <ul class="d-flex p-0" style="margin: 0 1.5rem;text-align:center;">

                                    <!-- linkedin -->
                                    <li>
                                        <a class="btn btn-link btn-lg text-dark" href="https://www.linkedin.com/in/govind-gojiya" title="linkedin"><i class="fa fa-linkedin "></i></a>
                                    </li>
                                    <!-- Instagram -->
                                    <li>
                                        <a class="btn btn-link text-dark btn-lg" href="https://instagram.com/g_j_gojiya?igshid=ZDdkNTZiNTM=" title="instragram"><i class="fa fa-instagram "></i></a>
                                    </li>
                                    <!-- github -->
                                    <li>
                                        <a class="btn btn-link btn-lg text-dark " href="https://github.com/govindgojiya" title="github"><i class="fa fa-github"></i></a>
                                    </li>
                                </ul>
                            </center>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="card text-center p-3  mt-2" style="width: 15rem;margin:0 auto;">
                            <center>
                                <h5 class=" card-title fw-bold">2. Krutika Prajapati</h5>
                                <p class="card-text">prajapatikrutika@duck.com</p>
                                <ul class="d-flex p-0" style="margin: 0 1.5rem;text-align:center;">

                                    <!-- linkedin -->
                                    <li>
                                        <a class="btn btn-link btn-lg text-dark" href="https://www.linkedin.com/in/krutika-prajapati-b8b367203/" title="linkedin"><i class="fa fa-linkedin "></i></a>
                                    </li>
                                    <!-- Instagram -->
                                    <li>
                                        <a class="btn btn-link text-dark btn-lg" href="" title="instragram"><i class="fa fa-instagram "></i></a>
                                    </li>
                                    <!-- github -->
                                    <li>
                                        <a class="btn btn-link btn-lg text-dark " href="https://github.com/krutikaprajapati" title="github"><i class="fa fa-github"></i></a>
                                    </li>
                                </ul>
                            </center>
                        </div>
                    </div>
                </div>

                <div class="row" style="width: 100%;margin:0">
                    <div class="col-lg-6 col-md-12">
                        <div class="card text-center p-3 mt-2" style="width: 15rem;margin:0 auto;">
                            <center>
                                <h5 class=" card-title fw-bold">3. Mayank Patel</h5>
                                <p class="card-text">mrmayank6877@gmail.com</p>
                                <ul class="d-flex p-0" style="margin: 0 1.5rem;text-align:center;">

                                    <!-- linkedin -->
                                    <li>
                                        <a class="btn btn-link btn-lg text-dark" href="https://www.linkedin.com/in/mayankkumar-patel-23a7b6203" title="linkedin"><i class="fa fa-linkedin "></i></a>
                                    </li>
                                    <!-- Instagram -->
                                    <li>
                                        <a class="btn btn-link text-dark btn-lg" href="https://instagram.com/mr_.mayank._?igshid=YmMyMTA2M2Y=" title="instragram"><i class="fa fa-instagram "></i></a>
                                    </li>
                                    <!-- github -->
                                    <li>
                                        <a class="btn btn-link btn-lg text-dark " href="http://www.github.com/mr-mayank" title="github"><i class="fa fa-github"></i></a>
                                    </li>
                                </ul>
                            </center>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="card text-center p-3  mt-2" style="width: 15rem;margin:0 auto;">
                            <center>
                                <h5 class=" card-title fw-bold">4. Priyanka Parekh</h5>
                                <p class="card-text">parekhpriyanka177@gmail.com</p>
                                <ul class="d-flex p-0" style="margin: 0 1.5rem;text-align:center;">

                                    <!-- linkedin -->
                                    <li>
                                        <a class="btn btn-link btn-lg text-dark" href="https://www.linkedin.com/in/priyanka-parekh-72367720a" title="linkedin"><i class="fa fa-linkedin "></i></a>
                                    </li>
                                    <!-- Instagram -->
                                    <li>
                                        <a class="btn btn-link text-dark btn-lg" href="https://instagram.com/_priyanka__027?igshid=ZDdkNTZiNTM=" title="instragram"><i class="fa fa-instagram "></i></a>
                                    </li>
                                    <!-- github -->
                                    <li>
                                        <a class="btn btn-link btn-lg text-dark " href="https://github.com/PriyankaParekh" title="github"><i class="fa fa-github"></i></a>
                                    </li>
                                </ul>
                            </center>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <?php include 'footer.php';?>
</body>

</html>