<?php

include 'database/include.php';
if (isset($_SESSION['userType'])) {
    $userType = $_SESSION['userType'];
    if ($userType == 'student') {
        header("Location: ./student_dashboard.php");
    } elseif ($userType == 'admin') {
        header("Location: ./admin_home.php");
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>signup</title>
    <?php include 'meta.php' ?>
    <style>
        @media (max-width: 768px) {
            .signup_page .row .sign_up_card{
                padding: 1rem !important;
            }
        }
    </style>
</head>

<body style=" background-image: url(./images/img.jpg);background-repeat: no-repeat;background-size: cover;background-attachment: fixed;background-position:center;">
    <div class="signup_page">
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="sign_up_card">
                        <form action="addStudent.php" method="post">
                            <center>
                                <h3>Sign Up</h3>
                            </center><br>
                            <div class="name_div">
                                <input size="30" type="text" id="name" name="name" placeholder="Enter your name">
                            </div>
                            <br>
                            <div class="email_div">
                                <input size="30" type="email" id="email" name="email" placeholder="Enter your Email Address">
                            </div>
                            <br>
                            <div class="ano_div">
                                <select name="anoId" style="width: 100%;padding: 0.8rem;">
                                    <option value="" disabled selected>Select ANO</option>
                                    <?php 
                                        $searchAno = "SELECT * FROM `admin_credentials`";
                                        $queryForAno = mysqli_query($conn, $searchAno);
                                        while ($row = mysqli_fetch_array($queryForAno)) {
                                            $anoId = $row['id'];
                                            $anoName = $row['username'];
                                            echo "<option value='$anoId'>$anoName</option>";
                                        }
                                    ?>
                                </select>
                            </div>
                            <br>
                            <p>Have Account? <a href="signin.php">Sign in</a></p>

                            <center> <button type="submit" class="btn mt-2" name="addStudent">Submit</button></center>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</body>

</html>