<?php 
ob_start();
session_start();
include('DbConnection.php'); 
$conn = OpenCon();
?>