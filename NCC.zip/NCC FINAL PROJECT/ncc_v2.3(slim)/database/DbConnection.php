<?php

function OpenCon()
 {
 $dbhost = " sql206.epizy.com ";
 $dbuser = "epiz_33121596";
 $dbpass = "GFY5JKofUDv0Z";
 $db = "epiz_33121596_ncc";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connection to 
 Db failed: %s\n". $conn -> error);
 
 return $conn;
 }
 

?>