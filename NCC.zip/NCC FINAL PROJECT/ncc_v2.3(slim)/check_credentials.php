
<?php
include('database/include.php');
if (isset($_POST['check_credentials'])) {
    $user_type = $_POST['user_type'];

    if($user_type == 'student'){
    $email = $_POST['email'];
    $pwd = $_POST['password'];
    $pwd = md5($pwd);

    $searchUser = "SELECT * FROM `student_credentials` WHERE `email` = ?";
    $findUser = $conn->prepare($searchUser);
    $findUser->bind_param("s", $email);
    $findUser->execute();
    $res = $findUser->get_result();
    $userDetails = mysqli_fetch_assoc($res);

    if ($res->num_rows) {

        $databasePWD = $userDetails['password'];
        if ($pwd === $databasePWD) {
            if($userDetails['active_status'] == 2){
                echo "<script>alert('Your credential not approved by admin(ANO). Wait for approval. !!')</script>";
                echo "<script>window.location.href = './student_dashboard.php';</script>";
            } else if($userDetails['active_status'] == 1){
                $_SESSION['userId'] = $userDetails['id'];
                $_SESSION['userType'] = $user_type;
                echo "<script>alert('Successfully Login !!')</script>";
                echo "<script>window.location.href = './student_dashboard.php';</script>";
            } else if($userDetails['active_status'] == 3){
                echo "<script>alert('Your credential rejected by admin(ANO). Contact admin(ANO) for more details. !!')</script>";
                echo "<script>window.location.href = './student_dashboard.php';</script>";
            }else {
                echo "<script>alert('Something went wrong !!')</script>";
                echo "<script>window.location.href = './student_dashboard.php';</script>";
            }
        } else {
            echo "<script>alert('Password is not coorect !!')</script>";
            echo "<script>window.location.href = './signin.php';</script>";
        }
    } else {
        echo "<script>alert('User Does not Exist !!')</script>";
        echo "<script>window.location.href = './signin.php';</script>";
    }
}
elseif($user_type=='admin'){
    $email = $_POST['email'];
    $pwd = $_POST['password'];
    $pwd = md5($pwd);

    $searchUser = "SELECT * FROM `admin_credentials` WHERE `email` = ? ";
    $findUser = $conn->prepare($searchUser);
    $findUser->bind_param("s", $email);
    $findUser->execute();
    $res = $findUser->get_result();
    $userDetails = mysqli_fetch_assoc($res);

    if ($res->num_rows) {

        $databasePWD = $userDetails['password'];
        if ($pwd === $databasePWD) {
            $_SESSION['anoID'] = $userDetails['id'];
            $_SESSION['userType'] = $user_type;
            echo "<script>alert('Successfully Login !!')</script>";
            echo "<script>window.location.href = './admin_home.php';</script>";
        } else {
            echo "<script>alert('Password is not coorect !!')</script>";
            echo "<script>window.location.href = './signin.php';</script>";
        }
    } else {
        echo "<script>alert('Admin Does not Exist !!')</script>";
        echo "<script>window.location.href = './signin.php';</script>";
    }
}

}
