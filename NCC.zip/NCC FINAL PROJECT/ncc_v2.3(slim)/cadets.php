<?php
include('database/include.php');
if(!isset($_SESSION['userType'])){
    header("Location: ./signin.php");
}else{
    if($_SESSION['userType'] != 'admin'){
        session_unset();
        session_destroy();
        header("Location: ./signin.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Cadets</title>
    <style>
        table {
            border-collapse: collapse;
            table-layout: fixed;
        }

        th {
            text-align: center !important;
        }


        td {
            text-align: center;
            word-wrap: break-word !important;
            width: 200px !important;
            border-bottom: 2px solid #f2f2f2;

        }

        td:hover {
            background-color: #b6d5f5;
        }

        #table-wrapper {
            position: relative;
        }

        #table-scroll {
            height: 590px;
            overflow: auto;
            margin-top: 20px;
        }

        #table-wrapper table {
            width: 100%;
            padding-top: 1rem;
        }
    </style>
    <?php include ('meta.php') ?>
</head>

<body>
    <section>
        <nav class="navbar navbar-expand-lg ">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"><img src="images/logo.png" width="70" height="70" alt=""></a>
                <button justify-content-end class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="justify-content-end collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link text-light" href="admin_home.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="cadets.php">Cadets</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="add_event.php">Events</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="attendance.php">Report</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="about_us.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

    </section>
    <section>
        <center class="mt-5"><h2>New Cadets</h2></center>
    <div id="table-wrapper" class="container">
        <div class="main mt-5" id="table-scroll" style="height: auto;margin-bottom: 5rem;">
            <table id="myTable" class="myTable">
                <thead style="background-color: #003975; color:white">
                    <tr>
                        <th scope="col" class="text-center">Sr No.</th>
                        <th scope="col" class="text-center">Name</th>
                        <th scope="col" class="text-center">Email</th>
                        <th scope="col" class="text-center">Approval</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM `student_credentials` where `anoID` = '$_SESSION[anoID]' AND `active_status` = '2'";
                    $result = mysqli_query($conn, $sql);
                    $srno = 0;

                    while ($row = mysqli_fetch_assoc($result)) {
                        $srno = $srno + 1;

                            echo "<tr>
                            <th scope='row'>" . $srno . "</th>
                            <td>" . $row['name'] ."</td>
                            <td>" . $row['email'] . "</td>
                            <td><form action='approve.php' method='post'> <input type='hidden' name='id' value='" . $row['id'] . "'> <button name='approve' type='submit' class='btn text-center my-3 text-light' style='background-color: #35b729;'>Approve</button> <button name='reject' type='submit' class='btn text-center my-3 text-light' style='background-color: #35b729;'>Reject</button></form></td>
                        </tr>";
                    }

                    ?>
                </tbody>
            </table>
        </div>
    </div>
    </section>
    <section>
    <center class="mt-5"><h2>Current Cadets</h2></center>
    <div id="table-wrapper" class="container">
        <div class="main mt-5" id="table-scroll"  style="height: auto;margin-bottom: 5rem;">
            <table id="myTable1" class="myTable">
                <thead style="background-color: #003975; color:white">
                    <tr>
                        <th scope="col" class="text-center">Sr No.</th>
                        <th scope="col" class="text-center">Register Number</th>
                        <th scope="col" class="text-center">Name</th>
                        <th scope="col" class="text-center">Mobile</th>
                        <th scope="col" class="text-center">Email</th>
                        <th scope="col" class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM `student_credentials` where `anoID` = '$_SESSION[anoID]' AND `active_status` = '1'";
                    $result = mysqli_query($conn, $sql);
                    $srno = 0;

                    while ($row = mysqli_fetch_assoc($result)) {
                        $srno = $srno + 1;
                        $sql1 = "SELECT * FROM `personaldetails` where `userID` = '$row[id] '";
                        $result1 = mysqli_query($conn, $sql1);
                        if($row['regNo']== NULL){
                            $regNo = "Not Assigned";
                        }
                        else{
                            $regNo = $row['regNo'];
                        }
                        if(mysqli_num_rows($result1) > 0){
                            $row1 = mysqli_fetch_assoc($result1);

                            echo "<tr>
                            <th scope='row'>" . $srno . "</th>
                            <td>" . $regNo . "</td>
                            <td>" . $row1['fname'] ." ". $row1['lname'] ."</td>
                            <td>" . $row1['contactNo'] . "</td>
                            <td>" . $row1['email'] . "</td>
                            <td><form action='studentProfile.php' method='post'> <input type='hidden' name='id' value='" . $row['id'] . "'> <button name='showDetails' type='submit' class='btn text-center mt-3 text-light' style='background-color: #35b729;'>View</button> </form></td>
                        </tr>";
                        }
                      else{
                        echo "<tr>
                        <th scope='row'>" . $srno . "</th>
                        <td>" . $regNo . "</td>
                        <td>Not Updated</td>
                        <td>Not Updated</td>
                        <td>".$row['email']."</td>
                        <td><form action='studentProfile.php' method='post'> <input type='hidden' name='id' value='" . $row['id'] . "'> <button name='showDetails' type='submit' class='btn text-center mt-3 text-light' style='background-color: #35b729;' disabled >View</button> </form></td>
                    </tr>";

                      }
                    }

                    ?>
                </tbody>
            </table>

        </div>
    </div>
    </section>
    
    <?php include ('footer.php') ?>

    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
        });
        $(document).ready(function() {
            $('#myTable1').DataTable();
        });
    </script>

</body>

</html>