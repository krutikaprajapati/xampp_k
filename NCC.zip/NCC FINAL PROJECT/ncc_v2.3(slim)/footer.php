<footer class="text-center text-white" style="background-color: #003975;color:white;">
    <div class="row" style="width:100%;">
        <div class="col-md-4 mt-4 title">
            Get connected with us on social networks:
        </div>
        <div class="col-md-2"></div>
        <div class="col-md-6">
            <div class="container pt-3">
                <section class="hover-effect1">
                    <ul>
                        <li>
                            <a class="btn btn-link btn-floating btn-lg text-light m-1" href="https://mobile.twitter.com/nccvgec" title="twitter"><i class="fa fa-twitter "></i></a>
                        </li>
                        <li>
                            <a class="btn btn-link btn-floating btn-lg text-light m-1" href="https://instagram.com/ncc_vgec_official?igshid=YmMyMTA2M2Y=" title="instragram"><i class="fa fa-instagram "></i></a>
                        </li>
                        <li>
                            <a class="btn btn-link btn-floating btn-lg text-light m-1" href="https://www.facebook.com/nccvgec?mibextid=ZbWKwL" title="facebook"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li>
                            <a class="btn btn-link btn-floating btn-lg text-light m-1" href="https://www.vgecg.ac.in/ncc.php" title="google"><i class="fa fa-google"></i></a>
                        </li>
                        <li>
                            <a class="btn btn-link btn-floating btn-lg text-light m-1" href="https://www.linkedin.com/school/vishwakarma-government-engineering-college-chandkheda-gandhinagar-017/" title="linkedin"><i class="fa fa-linkedin "></i></a>
                        </li>
                    </ul>
                </section>
            </div>
        </div>
        <hr>
    </div>
    <center>
        <div class="row" style="width:100%;">
            <p>Content Owned by NCC, VGEC</p>
            <p>Developed and hosted by IT Department Students, VGEC</p>
            <p class="mb-0"> Last Updated: Dec 2, 2022</p>
        </div>
    </center>
    <hr>
    <div class="text-center p-1 pb-3" style="background-color: #003975;color:white !important;">
        © 2022 Copyright: All Rights reserved
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
<script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
