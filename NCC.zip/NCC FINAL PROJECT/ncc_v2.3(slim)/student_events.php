<?php
include('database/include.php');
if (!isset($_SESSION['userType'])) {
    header("Location: ./signin.php");
} else {
    if ($_SESSION['userType'] != 'student') {
        session_unset();
        session_destroy();
        header("Location: ./signin.php");
    }
}

$uniqueID = $_SESSION['updateID'];
$getUserInfo = "SELECT * FROM `personaldetails` WHERE `userID` = '$uniqueID'";
$getUserInfoResult = mysqli_query($conn, $getUserInfo);
if(mysqli_num_rows($getUserInfoResult) < 1){
    echo "<script>alert('Please first fill up enroll form to register events.')</script>";
    echo "<script>window.location.href = 'EnrollForm.php'</script>";
}

if (isset($_POST['yes'])) {
    $event_id = $_POST['eventId'];
    $student_id = $_SESSION['userId'];
    $searchEvent = "SELECT * FROM `event_handle` WHERE `id` = ?";
    $findEvent = $conn->prepare($searchEvent);
    $findEvent->bind_param("i", $event_id);
    $findEvent->execute();
    $res = $findEvent->get_result();
    $eventDetails = mysqli_fetch_assoc($res);
    $participant = $eventDetails['participant'];
    if ($participant == NULL || $participant == '') {
        $participant = $student_id;
    } else {
        $participant = $participant . ',' . $student_id;
    }
    $updateEvent = "UPDATE `event_handle` SET `participant` = ? WHERE `id` = ?";
    $updateEvent = $conn->prepare($updateEvent);
    $updateEvent->bind_param("si", $participant, $event_id);
    if ($updateEvent->execute()) {
        echo "<script>alert('Successfully Registered !!')</script>";
        // echo "<script>window.open('./student_events.php','_self')</script>";
        echo "<script>window.location.href = './student_events.php';</script>";
    } else {
        echo "<script>alert('Something went wrong !!')</script>";
        // echo "<script>window.open('./student_events.php','_self')</script>";
        echo "<script>window.location.href = './student_events.php';</script>";

    }
}

if (isset($_POST['no'])) {
    $event_id = $_POST['eventId'];
    $student_id = $_SESSION['userId'];
    $searchEvent = "SELECT * FROM `event_handle` WHERE `id` = ?";
    $findEvent = $conn->prepare($searchEvent);
    $findEvent->bind_param("i", $event_id);
    $findEvent->execute();
    $res = $findEvent->get_result();
    $eventDetails = mysqli_fetch_assoc($res);
    $participant = $eventDetails['notInterested'];
    if ($participant == NULL || $participant == '') {
        $participant = $student_id;
    } else {
        $participant = $participant . ',' . $student_id;
    }
    $updateEvent = "UPDATE `event_handle` SET `notInterested` = ? WHERE `id` = ?";
    $updateEvent = $conn->prepare($updateEvent);
    $updateEvent->bind_param("si", $participant, $event_id);
    if ($updateEvent->execute()) {
        echo "<script>alert('Your response has been submited !!')</script>";
        // echo "<script>window.open('./student_events.php','_self')</script>";
        echo "<script>window.location.href = './student_events.php';</script>";
    } else {
        echo "<script>alert('Something went wrong !!')</script>";
        // echo "<script>window.open('./student_events.php','_self')</script>";
        echo "<script>window.location.href = './student_events.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Student Event Dashboard</title>
    <style>
        th {
            text-align: center !important;
        }

        body {
            font-family: 'Raleway', sans-serif;
        }
        
        @media (max-width: 992px) {
            .mobile-text {
                text-align: center !important;
            }
        }
    </style>
    <?php include 'meta.php' ?>
</head>

<body>
    <section>
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"><img src="images/logo.png" width="70" height="70" alt=""></a>
                <button justify-content-end class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="justify-content-end collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link text-light" href="student_dashboard.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="EnrollForm.php">Enroll Form</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="student_events.php">Events</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="studentProfile.php">Update Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="about_us.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </section>

    <section>
        <center>
            <h4 class="heading mt-4">New Events</h4>
        </center>
        <div class="row mt-3" style="width: 100%;text-align:center;margin: 0 auto;">


            <?php
            $sql = "SELECT * FROM `event_handle`";
            $result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_assoc($result)) {
                $tdate = date("Y-m-d");
                $edate = $row['startDate'];
                $participate = false;
                $arrayParticipate = explode(",", $row['participant']);
                $arrayNotInterested = explode(",", $row['notInterested']);
                foreach ($arrayNotInterested as $value) {
                    if ($value == $_SESSION['userId']) {
                        $participate = true;
                    }
                }
                foreach ($arrayParticipate as $value) {
                    if ($value == $_SESSION['userId']) {
                        $participate = true;
                    }
                }

                if ($tdate <= $edate && $participate == false) {
                    echo '
                        <div class="col-md-4">
                        <div class="card" style="margin: 0 auto; padding: 1rem;">
                        <div class="row">
                        <label for="" class="col-md-4 col-form-label">Event name:</label>
                        <div class="col-md-8 col-form-label">
                        <p style="text-align: justify;margin: 0;" class="mobile-text">
                        ' . $row['evName'] . '
                        </p>
                        </div>
                        </div>

                    <div class="row">
                        <label for="" class="col-md-4 col-form-label">Event Details:</label>
                        <div class="col-md-8 col-form-label">
                        <p style="text-align: justify;margin: 0;" class="mobile-text"> 
                        ' . $row['evDetails'] . '
                        </p>
                           
                        </div>
                    </div>

                    <div class=" row">
                        <label for="" class="col-md-4 col-form-label">Starting Date:</label>
                        <div class="col-md-8">
                            <input type="text" readonly class="form-control-plaintext col-form-label mobile-text" id="startDate" name="startDate" value="' . $row['startDate'] . '">
                        </div>
                    </div>

                    <div class="row">
                        <label for="" class="col-md-4 col-form-label">Ending Date:</label>
                        <div class="col-md-8">
                            <input type="text" readonly class="form-control-plaintext col-form-label mobile-text" id="endDate" name="endDate" value="' . $row['endDate'] . '">
                        </div>
                    </div>

                    <div class="btn_group" style="display: flex;margin:0 auto;flex-wrap: wrap;justify-content: space-around;">
                    ';
            ?>
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" class="m-3">
                        <input type="hidden" id="yes" name="eventId" value="<?php echo $row['id'] ?>">
                        <input type="Submit" value="Participate" name="yes" class="btn btn-lg text-light m-2" style="background-color: #35b729;">
                    </form>
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" class="m-3">
                        <input type="hidden" id="no" name="eventId" value="<?php echo $row['id'] ?>">
                        <input type="Submit" value="Not Interested" name="no" class="btn btn-lg text-light m-2" style="background-color: #35b729;">
                    </form>
            <?php
                    echo '
                    </div>
                    </div>
                    </div>
                            
                    ';
                }
            }
            ?>
        </div>
    </section>

    <section class="" style="margin-top: 4rem;">
        <center>
            <h4 class="heading">Attended Events</h4>
        </center>
    </section>

    <div id="table-wrapper" class="p-5 pt-0 my-3">
        <div class="main" id="table-scroll">
            <table class="table text-center" id="myTable" class="myTable">
                <thead style="background-color: #003975; color:white;">
                    <tr>
                        <th scope="col">Sr. No</th>
                        <th scope="col">Event name</th>
                        <th scope="col">Starting Date</th>
                        <th scope="col">Ending Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM `event_handle`";
                    $result = mysqli_query($conn, $sql);
                    $i = 1;
                    while ($row = mysqli_fetch_assoc($result)) {
                        $tdate = date("Y-m-d");
                        $edate = $row['endDate'];
                        $participate = false;
                        $arrayParticipate = explode(",", $row['participant']);
                        foreach ($arrayParticipate as $value) {
                            if ($value == $_SESSION['userId']) {
                                $participate = true;
                            }
                        }
                        if ($tdate >= $edate && $participate == true) {
                            echo '
                            <tr>
                                <th scope="row">' . $i . '</th>
                                <td>' . $row['evName'] . '</td>
                                <td>' . $row['startDate'] . '</td>
                                <td>' . $row['endDate'] . '</td>
                            </tr>
                            ';
                        }
                        $i++;
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php include 'footer.php' ?>

    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
        });
    </script>

</body>

</html>