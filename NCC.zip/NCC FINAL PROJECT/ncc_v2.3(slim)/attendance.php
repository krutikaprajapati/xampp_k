<?php
include('database/include.php');
if (!isset($_SESSION['userType'])) {
    header("Location: ./signin.php");
} else {
    if ($_SESSION['userType'] != 'admin') {
        session_unset();
        session_destroy();
        header("Location: ./signin.php");
    }
}


?>
<!doctype html>
<html lang="en">

<head>
    <title>Attendance</title>
    <style>
        th,
        td {
            text-align: center !important;
        }

        body {
            font-family: 'Raleway', sans-serif;
        }

        @media (max-width: 768px) {
            .noWrappingClass {
                white-space: nowrap;
            }
        }
    </style>
    <?php include('meta.php') ?>
</head>

<body>

    <!-- navigation bar  -->
    <section>
        <nav class="navbar navbar-expand-lg ">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"><img src="images/logo.png" width="70" height="70" alt=""></a>
                <button justify-content-end class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="justify-content-end collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link text-light" href="admin_home.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="cadets.php">Cadets</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="add_event.php">Events</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="attendance.php">Report</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="about_us.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

    </section>
    <br>
    <br>
    <center>
        <h3>
            Current Events
        </h3>
    </center>
    <div id="table-wrapper" class="p-5 pt-0 mt-3">
        <div class="main mt-5" id="table-scroll">
            <table class="table" id="myTable" class="myTable">
                <thead style="background-color: #003975; color:white">
                    <tr>
                        <th scope="col">Sr. No</th>
                        <th scope="col">Event</th>
                        <th scope="col">Report Generation</th>

                    </tr>
                </thead>
                <tbody>
                    <?php
                    $eventDetails = "SELECT * FROM `event_handle`";
                    $eventDetailsQuery =  mysqli_query($conn, $eventDetails);
                    $i = 1;
                    while ($row = mysqli_fetch_array($eventDetailsQuery)) {
                        $tdate = date('Y-m-d');
                        $date = $row['endDate'];
                        $create = $row['evCreate'];

                        if ($date > $tdate) {
                            echo "<tr>";
                            echo "<td>" . $i . "</td>";
                            echo "<td>" . $row['evName'] . "($create)" . "</td>";
                            echo "<td>"; ?> <form action="viewAttendee.php" method="post"><input type="hidden" name="evId" value="<?php echo $row['id']; ?>"> <button style="padding: 0.5rem 0.7rem; background-color: #35b729;" type="submit" class="btn btn-sm text-light" name="attandee">Report</button></form> <?php echo "</td>";
                                                                                                                                                                                                                                                                                                                    echo "</tr>";
                                                                                                                                                                                                                                                                                                                    $i++;
                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <br>
    <br>

    <center>
        <h3>
            Previous Events
        </h3>
    </center>
    <section>
        <div id="table-wrapper" class="p-5 pt-0 mt-3">
            <div class="main mt-5" id="table-scroll" style="overflow: scroll;">
                <table class="table" id="myTable1" class="myTable">
                    <thead style="background-color: #003975; color:white">
                        <tr>
                            <th scope="col">Sr. No</th>
                            <th scope="col">Event</th>
                            <th scope="col">Camp Photo</th>
                            <th scope="col">Add Photo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $eventDetails = "SELECT * FROM `event_handle`";
                        $eventDetailsQuery =  mysqli_query($conn, $eventDetails);
                        $i = 1;
                        while ($row = mysqli_fetch_array($eventDetailsQuery)) {
                            $tdate = date('Y-m-d');
                            $date = $row['endDate'];
                            $create = $row['evCreate'];
                            if ($date < $tdate && ($row['campPhoto'] == NULL || $row['campPhoto'] == '')) {
                                echo "<tr>";
                                echo "<td>" . $i . "</td>";
                                echo "<td>" . $row['evName'] . "(" .$create .")</td>";

                        ?>
                                <form enctype="multipart/form-data" method="POST" action="addCampPhoto.php">
                                    <td>
                                        <input type="hidden" name="evId" value="<?php echo $row['id']; ?>">
                                        <input type="file" name="campPhoto" id="campPhoto" required>
                                    </td>
                                    <td>
                                        <button style="padding: 0.5rem 0.7rem; background-color: #35b729;" type="submit" class="btn btn-sm text-light" name="addCampPhoto">Add</button>
                                    </td>

                                </form>
                        <?php

                                echo "</tr>";
                                $i++;
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <section>
    <div id="table-wrapper" class="p-5 pt-0 mt-3">
        <div class="main mt-5" id="table-scroll" style="overflow: scroll;">
            <table class="table" id="myTable2" class="myTable">
                <thead style="background-color: #003975; color:white">
                    <tr>
                        <th scope="col">Sr. No</th>
                        <th scope="col">Event</th>
                        <th scope="col">Event Details</th>
                        <th scope="col">Report </th>
                        <th scope="col">Print CATC Report </th>

                    </tr>
                </thead>
                <tbody>
                    <?php
                    $eventDetails = "SELECT * FROM `event_handle`";
                    $eventDetailsQuery =  mysqli_query($conn, $eventDetails);
                    $i = 1;
                    while ($row = mysqli_fetch_array($eventDetailsQuery)) {
                        $tdate = date('Y-m-d');
                        $date = $row['endDate'];
                        if ($date < $tdate) {
                            echo "<tr>";
                            echo "<td>" . $i . "</td>";
                            echo "<td>" . $row['evName'] . "($create)" . "</td>";
                            echo "<td class='noWrappingClass' style='text-align: justify !important;'> " . $row['evDetails'] . "</td>";
                            echo "<td>"; ?> <form action="viewAttendee.php" method="post"><input type="hidden" name="evId" value="<?php echo $row['id']; ?>"> <button style="padding: 0.5rem 0.7rem; background-color: #35b729;" type="submit" class="btn btn-sm text-light" name="attandee">Report</button></form> <?php echo "</td>";
                            echo "<td>"; ?> <form action="CATCReport.php" method="post"><input type="hidden" name="evId" value="<?php echo $row['id']; ?>"> <button style="padding: 0.5rem 0.7rem; background-color: #35b729;" type="submit" class="btn btn-sm text-light" name="CATCattandee">Report</button></form> <?php echo "</td>";
                                echo "</tr>";
                                $i++;
                            }
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    </section>
    <br>
    <br>
    <br>
    <?php include 'footer.php' ?>

    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
            $('#myTable1').DataTable(
                {
                "autoWidth": false, 
                "columns": [
                    null,
                    null,
                    { "width": "5rem" },
                    null  
                ]
            });
            $('#myTable2').DataTable(
                {
                "autoWidth": false, 
                "columns": [
                    null,
                    null,
                    { "width": "15rem" },
                    null,
                    null  
                ]
            });
        });
    </script>

</body>

</html>