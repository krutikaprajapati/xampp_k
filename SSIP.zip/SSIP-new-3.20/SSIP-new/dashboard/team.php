<?php
include("../Connection.php");
$ref = $_GET["ref"];
$game = "SELECT game_id FROM player p WHERE p.team_ref='$ref'";
$conn = mysqli_query($connect, $game);
while ($row = mysqli_fetch_array($conn)){
  $game_id = $row['game_id'];
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  </head>
  <body>
    
<nav class="navbar bg-light fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Hello Team Leader</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="player.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="allCoachTeam.php?gid=<?php echo $game_id; ?>">All Coach</a>
          </li>
           </ul>
        
      </div>
    </div>
  </div>
</nav>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>profile</title>

    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <!-- <link href="css/styles.css" rel="stylesheet" /> -->
    <link rel="stylesheet" href="css/styles.css?v=<?php echo time(); ?>">
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>

    <script src="js/scripts.js"></script>

    <!-- css  -->
    <link rel="stylesheet" href="assets/css/profile.css">

</head>

<body>
    <div class="container">
    <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th scope="col">Sr No.</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Contact Number</th>
            <th scope="col">View Details</th>
          </tr>
        </thead>
        <tbody>
        <?php
        $team = "SELECT * FROM player p WHERE p.team_ref='$ref'";
        $conn = mysqli_query($connect, $team);
        $count = 1;
        while ($row = mysqli_fetch_array($conn)) { ?>
          <tr>
            <th scope="row"><?php echo $count++; ?></th>
            <td><?php  echo $row['f_name']." ".$row['m_name']." ".$row["l_name"]; ?></td>
            <td><?php  echo $row['f_name']." ".$row['m_name']." ".$row["l_name"]; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><button class="btn btn-primary" type="button" data-bs-toggle="modal"
                data-bs-target="#exampleModal">Details</button></td>
          </tr>
        <?php }
        ?>   
          
        </tbody>
      </table>

    </div>

    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <b> Team Name : TechBenders <br/>
                        Leader : Janvi Gupta <br/>
                        Leader's Mail : janvi@gmail.com<br/>
                        Members : 12
                        Level : National Level Team
                        Achivements : 3 Gold medals, 5 Silver Medals, 9 Bronze Medals <br/>
                    </b>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

</body>

</html>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>
