<?php
include("../Connection.php");
$gid = $_GET["gid"];
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>All Coach</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

</head>

<body>
  <div class="container mt-4">
    <table class="table table-striped table-hover">
      <thead>
        <tr>
          <th scope="col">Sr No.</th>
          <th scope="col">Coach Photo</th>
          <th scope="col">Coach Name</th>
          <th scope="col">Coach Email</th>
          <th scope="col">View Details</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $team = "SELECT * FROM coach_registration c WHERE c.game_id='$gid'";
        $conn = mysqli_query($connect, $team);
        $count = 1;
        while ($row = mysqli_fetch_array($conn)) { ?>
        
          <tr>
            <th scope="row"><?php echo $count++; ?></th>
            <td><?php  echo $row['f_name']." ".$row['m_name']." ".$row["l_name"]; ?></td>
            <td><?php  echo $row['f_name']." ".$row['m_name']." ".$row["l_name"]; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><button class="btn btn-primary" type="button" data-bs-toggle="modal"
                data-bs-target="#exampleModal">Details</button></td>
          </tr>
        <?php }
        ?>   
    </tbody>
    </table>
  </div>

  <!-- Button trigger modal -->
  <!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
  Launch demo modal
</button> -->

  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <b> Team Name : TechBenders <br />
            Leader : Janvi Gupta <br />
            Leader's Mail : janvi@gmail.com<br />
            Members : 12
            Level : National Level Team
            Achivements : 3 Gold medals, 5 Silver Medals, 9 Bronze Medals <br />
          </b>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>



  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
    crossorigin="anonymous"></script>


</body>

</html>