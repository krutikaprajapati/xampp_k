const validateFile = function (usr) {
  var fileName = usr.value;
  var idxDot = fileName.lastIndexOf(".") + 1;
  var extFile = fileName.substr(idxDot, fileName.length).toLowerCase();
  if (extFile == "jpg" || extFile == "jpeg" || extFile == "png") {
    if (usr.files[0].size > 2097152) {
      alert("Image should be less then 2MB.");
      usr.value = null;
    } else {
      return true;
    }
  } else {
    alert("Only jpg/jpeg and png files are allowed!");
    usr.value = null;
  }
};
