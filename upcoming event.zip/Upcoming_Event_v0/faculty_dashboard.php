<?php

include('database/include.php');
include 'header.php';
include('faculty_check.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <title>Dashboard</title>
    <style>
        table.dataTable.no-footer {
            border-bottom: none;
        }

        #example2 th,
        #example2 td {
            border-right: none;
        }

        #example3 th,
        #example3 td {
            border-right: none;
        }

        #example th {
            border-right: none;
        }
    </style>
</head>


<body>

    <div class="container" style="display: flex;
    flex-direction: column;
    align-items: center;">
        <center>
            <div class="detail">
                <p><b>Department Name:</b> <?php echo $_SESSION['d_name']; ?></p>
                <p><b>Coordinator Name:</b> <?php echo $_SESSION['c_name']; ?></p>
                <p><b>Coordinator Email:</b> <?php echo $_SESSION['c_email']; ?></p>
                <a href="./ChangePassword.php">Change Password</a>
                <a href="./logout_f.php"> Logout</a>
            </div>
        </center>

        <center style="margin-top: 1rem;margin-bottom: 0.5rem;">
            <h2>Reverted</h2>
        </center>

        <div class="p-4 mb-4" id="research_sch" style="border: 1px solid rgb(0, 56, 101); width: 100%;">
            <table id="example" class="row-border hover order-column stat stat-hover table-responsive table" style="width:100%">
                <thead class="text-center">
                    <tr>
                        <th>Sr No.</th>
                        <th>Date </th>
                        <th style="width: 20%;">Department Name</th>
                        <th style="width: 20%;">Event Name</th>
                        <th>Coordinator Name</th>
                        <th style="width: 10%;">Remarks</th>
                        <th style="width: 10%;">Edit</th>
                    </tr>
                </thead>
                <tbody class="text-center">

                    <?php

                    $sql = "SELECT * FROM `event_table` ORDER BY `e_id` DESC ";
                    $result = Select_Record($sql, $conn);
                    if ($result->num_rows > 0) {
                        foreach ($result as $k) {
                            $i = 1;
                            $id = $k['e_id'];
                            $rek = $k['remarks'];
                    ?>
                            <?php if ($rek != NULL) {
                            ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $k['e_start_date']; ?></td>
                                    <td><?php echo $k['Dept_name']; ?></td>
                                    <td><?php echo $k['e_title']; ?></td>
                                    <td><?php echo $k['e_coordinator']; ?></td>
                                    <td> <?php echo $k['remarks']; ?> </td>
                                    <td>
                                        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                                            <center>
                                                <div class="px-3 py-2 text-center">
                                                    <input type="hidden" name="getId" value="<?php echo $k['e_id'] ?>">
                                                    <input type="submit" name="editEvent" class="btn btn-primary py-2" value="Edit" />
                                                </div>
                                            </center>
                                        </form>
                                    </td>
                                    <?php
                                    $i++;
                                    ?>
                                </tr>
                            <?php

                            }
                            ?>
                    <?php
                        }
                    }
                    ?>

                </tbody>
            </table>
        </div>



        <center style="margin-top: 1rem;">
            <h2>Not Approved</h2>
        </center>

        <div class="p-4 mb-4" id="research_sch" style="border: 1px solid rgb(0, 56, 101); width: 100%;">
            <table id="example2" class="row-border hover order-column stat stat-hover table-responsive table" style="width:100%">
                <thead class="text-center" style="border: 1px solid black;">
                    <tr>
                        <th>Sr No.</th>
                        <!-- <th>Year</th> -->
                        <th>Date </th>
                        <th style="width: 25.8%;">Department Name</th>
                        <th>Event Name</th>
                        <th>Coordinator Name</th>
                        <th>Edit</th>
                        <th>View</th>
                    </tr>
                </thead>
                <tbody class="text-center">

                    <?php

                    $sql = "SELECT * FROM `event_table` ORDER BY `e_id` DESC ";
                    $result = Select_Record($sql, $conn);
                    if ($result->num_rows > 0) {
                        foreach ($result as $k) {
                            $j = 1;
                            $id = $k['e_id'];
                            $rek = $k['remarks'];
                            $flag = $k['flag'];
                    ?>
                            <?php if ($rek == NULL && $flag == 0) {
                            ?>
                                <tr>
                                    <td><?php echo $j; ?></td>
                                    <td><?php echo $k['e_start_date']; ?></td>
                                    <td><?php echo $k['Dept_name']; ?></td>
                                    <td><?php echo $k['e_title']; ?></td>
                                    <td><?php echo $k['e_coordinator']; ?></td>
                                    <td>
                                        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                                            <center>
                                                <div class="px-3 py-2 text-center">
                                                    <input type="hidden" name="getId" value="<?php echo $k['e_id'] ?>">
                                                    <input type="submit" name="editEvent" class="btn btn-primary py-2" value="Edit" />
                                                </div>
                                            </center>
                                        </form>
                                    </td>
                                    <td style="border-right: 1px solid black;">
                                        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                                            <center>
                                                <div class="px-3 py-2 text-center">
                                                    <input type="hidden" name="getId" value="<?php echo $k['e_id'] ?>">
                                                    <input type="submit" name="ViewEvent" class="btn btn-primary py-2" value="View" />
                                                </div>
                                            </center>
                                        </form>
                                    </td>
                                    <?php
                                    $j = $j + 1;;
                                    ?>
                                </tr>
                            <?php
                            }
                            ?>
                    <?php
                        }
                    }
                    ?>

                </tbody>
            </table>
        </div>



        <center style="margin-top: 1rem;">
            <h2>Approved</h2>
        </center>

        <div class="p-4 mb-4" id="research_sch" style="border: 1px solid rgb(0, 56, 101); width: 100%;">
            <table id="example3" class="row-border hover order-column stat stat-hover table-responsive table" style="width:100%">
                <thead class="text-center">
                    <tr>
                        <th>Sr No.</th>
                        <!-- <th>Year</th> -->
                        <th style="width: 11%;">Date </th>
                        <th style="width: 25%;">Department Name</th>
                        <th style="width: 19.87%;">Event Name</th>
                        <th style="width: 21%;">Coordinator Name</th>
                        <th style="width: 15%;">View</th>
                    </tr>
                </thead>
                <tbody class="text-center">

                    <?php

                    $sql = "SELECT * FROM `event_table` ORDER BY `e_id` DESC ";
                    $result = Select_Record($sql, $conn);
                    if ($result->num_rows > 0) {
                        foreach ($result as $k) {
                            $x = 1;
                            $id = $k['e_id'];
                            $rek = $k['remarks'];
                            $flag = $k['flag'];
                    ?>

                            <?php if ($rek == NULL && $flag == 1) {
                            ?>
                                <tr>
                                    <td><?php echo $x; ?></td>
                                    <td><?php echo $k['e_start_date']; ?></td>
                                    <td><?php echo $k['Dept_name']; ?></td>
                                    <td><?php echo $k['e_title']; ?></td>
                                    <td><?php echo $k['e_coordinator']; ?></td>
                                    <td style="border-right: 1px solid black;">

                                        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                                            <center>
                                                <div class="px-3 py-2 text-center">

                                                    <input type="hidden" name="getId" value="<?php echo $k['e_id'] ?>">
                                                    <input type="submit" name="ViewEvent" class="btn btn-primary py-2" value="View" />
                                                </div>
                                            </center>
                                        </form>
                                    </td>
                                    <?php
                                    $x = $x + 1;
                                    ?>
                                </tr>
                            <?php
                            }
                            ?>
                    <?php
                        }
                    }
                    ?>

                </tbody>
            </table>
        </div>


    </div>

    <?php

    include 'footer.php' ?>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            var table = $('#example').DataTable();
            $('#example tbody').on('mouseenter', 'td', function() {
                var colIdx = table.cell(this).index().column;
                $(table.cells().nodes()).removeClass('highlight');
                $(table.column(colIdx).nodes()).addClass('highlight');
            });
            var table2 = $('#example2').DataTable();
            $('#example2 tbody').on('mouseenter', 'td', function() {
                var colIdx = table2.cell(this).index().column;
                $(table2.cells().nodes()).removeClass('highlight');
                $(table2.column(colIdx).nodes()).addClass('highlight');
            });
            var table3 = $('#example3').DataTable();
            $('#example3 tbody').on('mouseenter', 'td', function() {
                var colIdx = table3.cell(this).index().column;
                $(table3.cells().nodes()).removeClass('highlight');
                $(table3.column(colIdx).nodes()).addClass('highlight');
            });
            $(".sorting:contains(More)").removeClass('sorting');
        });
    </script>
</body>

</html>