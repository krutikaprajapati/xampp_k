<?php

session_start();
include("DbConnection.php");
$conn = OpenCon();

include("header.php");
if(isset($_POST['login_stud_del'])){
    $uname=$_POST['username'];
    $pass = $_POST['password'];

    $search = "SELECT * FROM `add_event_login` WHERE `username` = '$uname' AND `password` = '$pass'";
    $searchResult = Select_Record($search, $conn);

    $result = mysqli_fetch_array($searchResult);

    if($searchResult->num_rows > 0) {
        if($result['authority'] == 1) {
            $_SESSION['admin'] = $uname;
            echo "<script>alert('Successfully Login Of Admin !!')</script>";
            echo "<script>window.open('./Dashboard.php','_self')</script>";
        } else {
            $_SESSION['type'] = "Faculty";
            $_SESSION['c_name'] = $result['c_name'];
            $_SESSION['c_email'] = $result['c_email'];
            $_SESSION['d_name'] = $result['d_name'];

            echo "<script>alert('Successfully Login Of Faculty !!')</script>";
            echo "<script>window.open('./faculty_dashboard.php','_self')</script>";
        }


        // header('location:./Dashboard.php');
    }
}
?>
<!-- <div class="row"></div>
<div class="col-md-2"></div> -->
<pre>


</pre>
<div id="page">
    <div class="col-md-6 mx-auto my-5">
        <h2 class="dept-title"> Login for Deleting Data</h2>
        <div class="px-3 mb-4 pt-3 apply" style="border: 1px solid #003865;">
            <!-- <h4 class="headingsall bg-light"></h4> -->
            <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
                <div class="headingsall">
                    <label name="username">Username</label>
                    <input name="username" type="text" class="form-control" required="required">
                </div>
                <div class="mt-3 headingsall">
                    <label name="password">Password</label>
                    <input name="password" type="password" class="form-control" required="required">
                </div>
                <center>
                <div class="col-md-6 my-3 text-center">
                    <input type="submit" name="login_stud_del" class="btn btn-primary py-2" value="Login" />
                </div>
                </center>
            </form>
        </div>
    </div>
</div>
<div class="space" style="margin-bottom: 5.75%;"></div>
<?php
    // echo "<script>window.open('index.php','_self')</script>"; 
    include("footer.php");
?>