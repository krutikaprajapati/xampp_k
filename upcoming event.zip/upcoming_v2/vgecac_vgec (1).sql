-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2022 at 02:25 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vgecac_vgec`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_event_login`
--

CREATE TABLE `add_event_login` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `d_name` varchar(255) NOT NULL,
  `c_name` varchar(255) NOT NULL,
  `c_email` varchar(255) NOT NULL,
  `authority` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_event_login`
--

INSERT INTO `add_event_login` (`id`, `username`, `password`, `d_name`, `c_name`, `c_email`, `authority`) VALUES
(1, 'admin', 'admin@123', '', '', 'admin@gmail.com', 1),
(2, 'jrd', 'jasvant@123', 'I.T.', 'Jasvant R. Dave', 'jrd@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `event_table`
--

CREATE TABLE `event_table` (
  `e_id` int(11) NOT NULL,
  `e_title` varchar(200) CHARACTER SET latin1 NOT NULL,
  `Dept_name` varchar(200) CHARACTER SET latin1 NOT NULL,
  `e_dpoints` text CHARACTER SET latin1 NOT NULL,
  `e_start_date` date NOT NULL,
  `e_end_date` date NOT NULL,
  `e_time` time NOT NULL,
  `e_venue` varchar(200) NOT NULL,
  `e_coordinator` varchar(200) CHARACTER SET latin1 NOT NULL,
  `e_contact` varchar(15) CHARACTER SET latin1 NOT NULL,
  `e_register` varchar(255) CHARACTER SET latin1 NOT NULL,
  `e_additional` text NOT NULL,
  `e_pdf` text CHARACTER SET latin1 NOT NULL,
  `remarks` varchar(200) CHARACTER SET latin1 NOT NULL,
  `flag` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event_table`
--

INSERT INTO `event_table` (`e_id`, `e_title`, `Dept_name`, `e_dpoints`, `e_start_date`, `e_end_date`, `e_time`, `e_venue`, `e_coordinator`, `e_contact`, `e_register`, `e_additional`, `e_pdf`, `remarks`, `flag`) VALUES
(1, 'XYZ', 'Instrumentation & Control', '<p>hello&nbsp;</p>\r\n', '2022-04-07', '2022-05-01', '00:00:00', 'LMA', 'MED', '9526824568', '', '<p><strong>byyy</strong></p>\r\n', './uploads/EventFiles/1648901886_200170116029_OOP_Practical02.pdf', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_event_login`
--
ALTER TABLE `add_event_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_table`
--
ALTER TABLE `event_table`
  ADD PRIMARY KEY (`e_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_event_login`
--
ALTER TABLE `add_event_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `event_table`
--
ALTER TABLE `event_table`
  MODIFY `e_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
