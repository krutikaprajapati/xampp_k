<?php
session_start();
include 'header.php';
include 'DbConnection.php';
if (!isset($_SESSION['admin'])) {
    echo "<script>window.open('./login_stud_delete.php','_self')</script>";
}
$conn = OpenCon();
if (isset($_POST['ViewEvent'])) {
    $_SESSION['eventId'] = $_POST['getId'];
    echo "<script>window.open('./ViewEvent.php','_self')</script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<style>
    table {
        width: 100%;

    }

    table td,
    th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    table tr:nth-child(even) {
        background-color: #dddddd;
    }

    .detail {
        margin: 1rem;
    }

    .detail span {
        padding: 8px;
    }
</style>

<body>

    <center style="margin-top: 1rem;margin-bottom: 0.5rem;">
    <a href="./logout_a.php"> Logout</a>

        <h2>Not Approved</h2>
    </center>
    <table style="margin-bottom: 1rem;">
        <tr>
            <th>Sr No.</th>
            <!-- <th>Year</th> -->
            <th>Date </th>
            <th>Department Name</th>
            <th>Event Name</th>
            <th>Coordinator Name</th>
            <th>View</th>
        </tr>
        <?php
        $i = 1;
        $sql = "SELECT * FROM `event_table` ORDER BY `e_id` DESC ";
        $result = Select_Record($sql, $conn);
        if ($result) {
            foreach ($result as $k) {
                $id = $k['e_id'];
                $rek = $k['remarks'];
                $flag = $k['flag'];
        ?>
                <?php if ($rek == NULL && $flag == 0) {
                ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $k['e_start_date']; ?></td>
                        <td><?php echo $k['Dept_name']; ?></td>
                        <td><?php echo $k['e_title']; ?></td>
                        <td><?php echo $k['e_coordinator']; ?></td>
                        <td>
                            <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                                <center>
                                    <div class="col-md-6 my-3 text-center">
                                        <input type="hidden" name="getId" value="<?php echo $k['e_id']; ?>">
                                        <input type="submit" name="ViewEvent" class="btn btn-primary py-2" value="View" />
                                    </div>
                                </center>
                            </form>
                        </td>

                    </tr>
                <?php
                }
                ?>
        <?php
                $i++;
            }
        }
        ?>
    </table>

</body>

</html>
<?php
include 'footer.php'
?>