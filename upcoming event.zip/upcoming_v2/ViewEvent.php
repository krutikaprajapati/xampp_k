<?php
session_start();
include 'header.php';
include 'DbConnection.php';

$conn = OpenCon();

if (isset($_SESSION['eventId'])) {

    $eventId = $_SESSION['eventId'];
    if (isset($_POST['approved_data']) && isset($_SESSION['admin'])) {
        $updateQuery = "UPDATE `event_table` SET `flag` = '1' WHERE `e_id` = '$eventId'";
        $runUpdateQuery = mysqli_query($conn, $updateQuery);
        // $row = mysqli_fetch_array($runUpdateQuery);

        if ($runUpdateQuery) {
            echo "<script>alert('Event Approved Successfully.')</script>";
            echo "<script>window.open('./Dashboard.php','_self')</script>";
        } else {
            echo "<script>alert('Approved Failed. Try Again!')</script>";
            echo "<script>window.open('./ViewEvent.php','_self')</script>";
        }
    }
    if (isset($_POST['not_approved_data']) && isset($_SESSION['admin'])) {

        // $remarks = readlink("Enter remarks for event disapproved");
        $remarks = $_POST['remarks'];


        if ($remarks != null) {

            $updateRemark = "UPDATE `event_table` SET `remarks` = '$remarks' WHERE `e_id` = '$eventId'";
            $runUpdateRemark = mysqli_query($conn, $updateRemark);

            if ($runUpdateRemark) {
                echo "<script>alert('Event Disapproved Successfully.')</script>";
                echo "<script>window.open('./Dashboard.php','_self')</script>";
            } else {
                echo "<script>alert('Disapproved Failed. Try Again!')</script>";
                echo "<script>window.open('./ViewEvent.php','_self')</script>";
            }
        } else {
            echo "<script>alert('For Disapproved remarks must be entered.')</script>";
            echo "<script>window.open('./ViewEvent.php','_self')</script>";
        }
    }


?>


    <div class="" id="event-content" style="margin-top: 1rem;margin-bottom: 1rem;">
        <div class="container col-sm-9 col-md-9 mb-4" style="border: 2px solid #003865;">
            <?php
            $eventId = $_SESSION['eventId'];
            $sql = "SELECT * FROM `event_table` d where d.e_id='$eventId'";
            $result = Select_Record($sql, $conn);
            // $idnumrow = $idquery->rowCount();        
            ?>
            <div class="row ">
                <div class="m-2 mx-auto">
                    <?php
                    while ($data = mysqli_fetch_array($result)) {
                    ?>
                        <h2 class="dept-title mx-auto text-center mt-3 mb-3"> Report on <?php echo $data['e_title'] ?></h2>
                </div>
            </div>
            <div class="row mx-auto">
                <table class="text-center table stat stat-hover table-center">
                    <thead>
                        <tr>
                            <th scope="row" class="text-left" style="width: 35%!important;">Name of Department</th>
                            <th class="text-center"> : </td>
                            <th class="text-left"><?php echo $data['Dept_name'] ?></td>
                        </tr>

                    </thead>
                    <tbody>
                        <?php
                        if ($data['e_title'] != null) {
                        ?>
                            <tr>
                                <th scope="row" class="w-25 text-left">Title of Event </th>
                                <td class="text-center"> : </td>
                                <td class="text-left w-75"><?php echo $data['e_title'] ?></td>
                            </tr>
                        <?php
                        } ?>
                        <?php
                        if ($data['e_coordinator'] != null) {
                        ?>
                            <tr>
                                <th scope="row  " class="w-25 text-left">Coordinator Name</th>
                                <td class="text-center"> : </td>
                                <td class="text-left w-75"><?php echo $data['e_coordinator'] ?></td>
                            </tr>
                        <?php
                        } ?>
                        <?php
                        if ($data['e_start_date'] != null) {
                            if ($data['e_end_date'] == $data['e_start_date']) {
                        ?>
                                <tr>
                                    <th scope="row " class="w-25 text-left">Date</th>
                                    <td class="text-center"> : </td>
                                    <td class="text-left w-75"><?php echo date('d-m-Y', strtotime($data['e_start_end'])) ?></td>
                                </tr>
                            <?php
                            } else { ?>
                                <tr>
                                    <th scope="row " class="w-25 text-left">Date</th>
                                    <td class="text-center"> : </td>
                                    <td class="text-left w-75"><?php echo date('d/m/Y', strtotime($data['e_start_date'])) . ' - ' . date('d/m/Y', strtotime($data['e_end_date'])) ?></td>
                                </tr>
                        <?php
                            }
                        } ?>
                        <?php
                        if ($data['e_time'] != null) {
                        ?>
                            <tr>
                                <th scope="row " class="w-25 text-left">Time</th>
                                <td class="text-center"> : </td>
                                <td class="text-left w-75"><?php echo $data['e_time'] ?></td>
                            </tr>
                        <?php
                        } ?>
                        <?php
                        if ($data['e_venue'] != null) {
                        ?>
                            <tr>
                                <th scope="row " class="w-25 text-left">Venue</th>
                                <td class="text-center"> : </td>
                                <td class="text-left w-75"><?php echo $data['e_venue'] ?></td>
                            </tr>
                        <?php
                        } ?>
                        <?php
                        if ($data['e_contact'] != null) {
                        ?>
                            <tr>
                                <th scope="row " class="w-25 text-left">Contact No. </th>
                                <td class="text-center"> : </td>
                                <td class="text-left w-75"><?php echo $data['e_contact'] ?></td>
                            </tr>
                        <?php
                        } ?>
                        <?php
                        if ($data['e_register'] != null) {
                        ?>
                            <tr>
                                <th scope="row " class="w-25 text-left">Registration Link</th>
                                <td class="text-center"> : </td>
                                <td class="text-left w-75"><?php echo $data['e_register'] ?></td>
                            </tr>
                        <?php
                        } ?>
                    </tbody>
                </table>
            </div>

            <?php
                        if ($data['e_dpoints'] != null) {
            ?>
                <div class="row" style="border-top: 2px solid #003865;">
                    <div class="ml-2 mr-2">
                        <h2 class="headingsall text-left mt-3"> Discussion points </h2>
                        <div class="ml-5">
                            <?php echo $data['e_dpoints'] ?>
                        </div>

                    </div>
                </div>
            <?php
                        } ?>
            <?php
                        if ($data['e_additional'] != null) {
            ?>
                <div class="row" style="border-top: 2px solid #003865;">
                    <div class="ml-2 mr-2">
                        <h2 class="headingsall text-left mt-3"> Additional Details </h2>
                        <div class="ml-5">
                            <?php echo $data['e_additional'] ?>
                        </div>

                    </div>
                </div>
            <?php
                        } ?>
            <?php if ($data['flag'] == '0' && isset($_SESSION['admin'])) { ?>
                <form method="post" enctype="multipart/form-data">
                    <div class="row d-flex justify-content-center" style="margin-bottom: 0.5rem; margin-top: 1rem;" id="approve-button">
                        <div class="text-right">
                            <button type="submit" name="approved_data" class="btn btn-primary ml-1 mb-2"> Approve</button>
                        </div>
                    </div>
                </form>

                <form method="post" enctype="multipart/form-data">
                    <div class="" style="margin-top: 0.5rem; margin-bottom: 1rem;" id="not_approve-button">
                        <div class="form-group">
                            <label for="remarks" class="col-sm-2 p-0 col-form-label">Remarks :*</label>
                            <textarea class="form-control" style="min-height: 8rem;" name="remarks" id="remarks" placeholder="Add Remarks For Not-Approved" required="true" pattern="[a-zA-Z][a-zA-Z\s]*" required title="Only capital, small letters and numeric values are allowed."></textarea>
                        </div>

                        <div class="text-right d-flex justify-content-center">
                            <button type="submit" name="not_approved_data" class="btn btn-primary ml-1 mb-2">Not Approve</button>
                        </div>
                    </div>
                </form>
            <?php
                        }
            ?>
        <?php
                    } ?>


        </div>

    </div>
    <script type="text/javascript">
        function myFunction(x) {
            if (x.matches) { // If media query matches
                var content = document.getElementById('event-content')
                content.classList.add('col-sm-9')

            } else {
                var content = document.getElementById('event-content')
                content.classList.remove('col-sm-9')

            }
        }

        var x = window.matchMedia("(max-width: 575px)")
        myFunction(x) // Call listener function at run time
        x.addListener(myFunction) // Attach listener function on state changes
    </script>
<?php

} else {
    echo "<script>window.location='./faculty_dashboard.php'</script>";
}
?>