<?php
session_start();
include 'header.php';
include 'DbConnection.php';

// if(!isset($_SESSION['']))
// {
// 	header('Location:./AdminLogin.php');
// }
$conn = OpenCon();
if ($conn) {

	$sql1 = "SELECT * FROM `event_table`";
	$ress = Select_Record($sql1, $conn);

	if (isset($_POST['submit_data'])) {
		$uploadsDir2 = "./uploads/EventFiles/";
		$finalname = null;
		$e_title = $_POST['e_title'];
		$dept_name = $_POST['Dept_Name'];
		$e_coordinator = $_POST['coordinator_Name'];
		$e_date = date('Y-m-d', strtotime($_POST['e_date']));
		$e_end_date = date('Y-m-d', strtotime($_POST['e_end_date']));
		// $e_time = time('HH:MM:SS', $_POST['e_time']);
		$e_time = $_POST['e_time'];
		$e_venue = $_POST['e_venue'];
		$e_contact_details = $_POST['e_contact_details'];
		$e_registration_link = $_POST['e_registration_link'];
		$a_points = $_POST['a_points'];
		$o_points = $_POST['o_points'];


		$pdfname = $_FILES['attachment']['name'];


		$tmp_name = $_FILES['attachment']['tmp_name'];
		$targetFilePath2  = $uploadsDir2 . $pdfname;
		$fileType2        = strtolower(pathinfo($targetFilePath2, PATHINFO_EXTENSION));
		$path2 = "./uploads/EventFiles/" . time() . "_" . basename($pdfname);
		$name3 = "./uploads/EventFiles/" . time() . "_" . basename($pdfname);

		move_uploaded_file($_FILES["attachment"]["tmp_name"], $path2);
		// $sql="INSERT INTO `tblevents` (`e_id`, `Dept_Name`, `e_title`, `e_affiliation`, `date_time`,`e_end_date`, `e_venue`, `e_participants`, `e_coordinator`, `e_about`, `e_objectives`, `e_dpoints`, `e_outcomes`,`e_thumb`,`e_pdf`) VALUES (NULL, '$dept_name', '$e_title', '$e_affiliation', '$e_venue', '$e_participants', '$e_coordinator', '$a_points', '$o_points', '$d_points', '$outcomes', '$ThumbName', '$name3')";
		$sql = "INSERT INTO `event_table`(`e_title`, `Dept_name`, `e_dpoints`, `e_start_date`, `e_end_date`, `e_time`, `e_venue`, `e_coordinator`, `e_contact`, `e_register`, `e_additional`, `e_pdf`, `flag`) VALUES ('$e_title','$dept_name','$a_points','$e_date','$e_end_date','$e_time','$e_venue','$e_coordinator','$e_contact_details','$e_registration_link','$o_points','$name3','0')";

		if (Insert_Record($sql, $conn)) {
			// header('refresh:3;url=form.php');

			echo "<script>alert('Record Successfully Inserted!!')</script>";
			if ($_SESSION['admin'])
				echo "<script>window.open('./Dashboard.php','_self')</script>";
			unset($_POST['submit_data']);
		} else {
			echo "<script>alert('Error In Inserting.')</script>";
			exit();
		}
	}

	// if(isset($_POST['Update']))
	// {
	// 	// echo "inside update";
	// 	$Year = $_POST["Year"];
	// 	$File = $_FILES["File"];
	// 	$DateAndMonth = $_POST["DateAndMonth"];
	// 	$Event_Name = $_POST["Event_Name"];
	// 	$Event_Report_Title = $_POST["Event_Report_Title"];
	// 	$Dept_Name = $_POST["Dept_Name"];
	// 	$name = $File['name'];
	// 	$FileName = $_POST['f1'];
	// 	if(empty($DateAndMonth))
	// 	{
	// 		$DateAndMonth = $_POST['dateyear'];
	// 	}

	// 	if(empty($Dept_Name))
	// 	{
	// 		$Dept_Name = $_POST['dep'];
	// 	}
	// 	$path1 = "../uploads/EventFiles/" . basename($name);
	// 	$name2 = "./uploads/EventFiles/" . basename($name);
	// 	if(empty($name))
	// 	{
	// 		$id = $_POST['id'];

	// 			    $sql = "UPDATE `tbleventsandachievements` SET `Year`= '$Year' ,`DateAndMonth`= '$DateAndMonth' ,`Dept_Name`= '$Dept_Name' ,`Event_Name`= '$Event_Name' ,`Event_Report_Title`= '$Event_Report_Title' ,`File`= '$FileName' WHERE `Event_Id` = ".$id." ";

	// 				if(Insert_Record($sql,$conn))
	// 				{
	// 					echo "<script>alert('Record Successfully Updated!!')</script>";
	// 					echo "<script>window.open('./EventsandAchievements.php','_self')</script>";
	// 				}
	// 				else
	// 				{
	// 					echo "<script>alert('Error In Query')</script>";
	// 				}
	// 	}
	// 	else
	// 	{
	// 			 if (move_uploaded_file($File['tmp_name'], $path1)) 
	// 			 {

	// 				$id = $_POST['id'];

	// 			    $sql = "UPDATE `tbleventsandachievements` SET `Year`= '$Year' ,`DateAndMonth`= '$DateAndMonth' ,`Dept_Name`= '$Dept_Name' ,`Event_Name`= '$Event_Name' ,`Event_Report_Title`= '$Event_Report_Title' ,`File`= '$name2' WHERE `Event_Id` = ".$id." ";

	// 				if(Insert_Record($sql,$conn))
	// 				{
	// 					echo "<script>alert('Record Successfully Updated!!')</script>";
	// 					echo "<script>window.open('./EventsandAchievements.php','_self')</script>";
	// 				}
	// 				else
	// 				{
	// 					echo "<script>alert('Error In Query')</script>";
	// 				}
	// 			 } 
	// 			 else 
	// 			 {
	// 			 	echo "<script>alert('Your File Size is Big So Reduce The File Or Other Error')</script>";
	// 			 }
	// 	}

	// }
}
//echo "connected";
?>

<!DOCTYPE html>
<html>

<head>
	<title>Add Event</title>
	<script type="text/javascript">
		function fileValidation() {
			var fileInput = document.getElementById('file');
			var filePath = fileInput.value;
			var allowedExtensions = /(\.pdf)$/i;
			if (!allowedExtensions.exec(filePath)) {
				alert('Please upload file having extensions .pdf only.');
				fileInput.value = '';
				return false;
			}
		}
	</script>
</head>

<body>
	<center style="margin-top: 1rem;">
		<h3>Add Event<h3>
	</center>


	<div class="container m-5">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
		<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">

			<div class="form-group row">
				<label for="e_title" class="col-sm-2 col-form-label">Event title :*</label>
				<input type="text" class="form-control w-25" name="e_title" id="e_title" placeholder="Event title" required="true" pattern="[a-zA-Z][a-zA-Z\s]*" required title="Only capital, small letters and numeric values are allowed." maxlength="20">
			</div>
			<div class="form-group row">

				<label for="e_title" class="col-sm-2 col-form-label">Department Name :*</label>
				<select name="Dept_Name" class="form-control w-25" required>
					<option value="" disabled selected>Select Department</option>
					<option value="Instrumentation & Control">Instrumentation & Control</option>
					<option value="Institute">Institute</option>
					<option value="Computer Engineering">Computer Engineering</option>
					<option value="Chemical Engineering">Chemical Engineering</option>
					<option value="Electrical Engineering">Electrical Engineering</option>
					<option value="Civil Engineering">Civil Engineering</option>
					<option value="Electronics & Communication">Electronics & Communication</option>
					<option value="Mechanical Engineering">Mechanical Engineering</option>
					<option value="Information Technology">Information Technology</option>
					<option value="WDC">WDC</option>
					<option value="NSS">NSS</option>
					<option value="NCC">NCC</option>
					<option value="IEI">IEI</option>
					<option value="IEEE">IEEE</option>
				</select>
			</div>

			<div class="form-group row">
				<label for="coordinator_Name" class="col-sm-2 col-form-label">Coordinator Name :*</label>
				<input type="text" class="form-control w-25" name="coordinator_Name" id="coordinator_Name" placeholder="Coordinator Name" required="true" pattern="[a-zA-Z][a-zA-Z\s]*" required title="Only capital, small letters and numeric values are allowed." maxlength="20">
			</div>
			<div class="form-group row">
				<label for="e_date" class="col-sm-2 col-form-label">Start Date :*</label>
				<input type="date" class="form-control w-25" name="e_date" id="e_date" required="true">
			</div>
			<div class="form-group row">
				<label for="e_end_date" class="col-sm-2 col-form-label">End Date :*</label>
				<input type="date" class="form-control w-25" name="e_end_date" id="e_end_date" required="true">
			</div>
			<div class="form-group row">
				<label for="e_time" class="col-sm-2 col-form-label">Time :*</label>
				<input type="time" class="form-control w-25" name="e_time" id="e_time" required="true">
			</div>


			<div class="form-group row">
				<label for="e_venue" class="col-sm-2 col-form-label">venue :*</label>
				<input type="text" class="form-control w-25" name="e_venue" id="e_venue" placeholder="venue" required="true" pattern="[a-zA-Z][a-zA-Z\s]*" required title="Only capital, small letters and numeric values are allowed." maxlength="20">

			</div>

			<div class="form-group row">
				<label for="e_contact_details" class="col-sm-2 col-form-label">Contact Details :*</label>
				<input type="text" class="form-control w-25" name="e_contact_details" id="e_contact_details" placeholder="contact_details" required="true" pattern="[6-9]{1}[0-9]{9}" required title="Enter valid Contact No." maxlength="10">
				<!-- <input type="text" class="form-control" id="contact" pattern="[6-9]{1}[0-9]{9}" required title="Enter valid Contact No." maxlength="10" placeholder="Enter Contact No"> -->
			</div>


			<div class="form-group row">
				<label for="e_registration_link" class="col-sm-2 col-form-label">Registration Link :</label>
				<input type="text" class="form-control w-25" name="e_registration_link" id="e_registration_link" placeholder="registration_link">
			</div>

			<div class="form-group row">
				<label for="a_points" class="col-sm-2 col-form-label">Description :*</label>
				<textarea class="form-control" name="a_points" id="a_points" rows="3" required placeholder="Description section(in paragraph)" required="true"></textarea>
			</div>
			<div class="form-group row">
				<label for="o_points" class="col-sm-2 col-form-label">Additional Details :</label>
				<textarea class="form-control" name="o_points" id="o_points" rows="3"></textarea>
			</div>

			<div class="form-group row">
				<label for="pdf" class="col-sm-2 col-form-label">Attachment :</label>
				<input type="file" name="attachment" class="form-control w-25" accept=".png, .jpg, .jpeg, .pdf">
			</div>
			<button type="submit" name="submit_data" class="btn btn-primary">Submit</button>
			<br />
		</form>
	</div>
	<script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
	<script>
		CKEDITOR.replace('a_points');
		CKEDITOR.replace('o_points');
	</script>







</body>

</html>
<?php
include 'footer.php';

?>