<!doctype html>
<html lang="en">

<head>

  <meta charset="utf-8">


  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <link rel="icon" href="GP_ICON.png">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
  <link rel="stylesheet" href="OwlCarousel2-2.3.4\dist\assets\owl.carousel.css">
  <link rel="stylesheet" href="OwlCarousel2-2.3.4\dist\assets\owl.theme.default.min.css">
  <link rel="stylesheet" href="style.css">

  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet'>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800;900&display=swap" rel="stylesheet">
  <!-- <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> -->

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="nav.css">
  <title>Vishwakarma Government Engineering College</title>

  <style>
    /*
    *
    * ==========================================
    * CUSTOM UTIL CLASSES
    * ==========================================
    *
    */

    .dropdown-submenu {
      position: relative;
    }

    .dropdown-submenu>a:after {
      content: "\f0da";
      float: right;
      border: none;
      font-family: 'FontAwesome';
    }

    .dropdown-submenu>.dropdown-menu {
      top: 0;
      left: 100%;
      margin-top: 0px;
      margin-left: 0px;
    }

    /*
    *
    * ==========================================
    * FOR DEMO PURPOSES
    * ==========================================
    *
    */




    @media (min-width: 992px) {
      .dropdown-menu {
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      }
    }

    .dropdown-submenu {
      position: relative;
    }

    .dropdown-submenu>.dropdown-menu {
      top: 0;
      left: 100%;
      margin-top: -6px;
      margin-left: -1px;
      -webkit-border-radius: 0 6px 6px 6px;
      -moz-border-radius: 0 6px 6px;
      border-radius: 0 6px 6px 6px;
    }

    .dropdown-submenu:hover>.dropdown-menu {
      display: block;
    }

    .dropdown-submenu>a:after {
      display: block;
      content: " ";
      float: right;
      width: 0;
      height: 0;
      border-color: transparent;
      border-style: solid;
      border-width: 5px 0 5px 5px;
      border-left-color: #ccc;
      margin-top: 5px;
      margin-right: -10px;
    }

    .dropdown-submenu:hover>a:after {
      border-left-color: #fff;
    }

    .dropdown-submenu.pull-left {
      float: none;
    }

    .dropdown-submenu.pull-left>.dropdown-menu {
      left: -100%;
      margin-left: 10px;
      -webkit-border-radius: 6px 0 6px 6px;
      -moz-border-radius: 6px 0 6px 6px;
      border-radius: 6px 0 6px 6px;
    }
  </style>
  <script>
    $(function() {
      // ------------------------------------------------------- //
      // Multi Level dropdowns
      // ------------------------------------------------------ //
      $("ul.dropdown-menu [data-toggle='dropdown']").on("click", function(event) {
        event.preventDefault();
        event.stopPropagation();

        $(this).siblings().toggleClass("show");


        if (!$(this).next().hasClass('show')) {
          $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
        }
        $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
          $('.dropdown-submenu .show').removeClass("show");
        });

      });
    });
  </script>
</head>

<body>
  <!--navbar-->
  <section id="navbar">
    <div class="info col-lg-12">
      <a class="ds m-0 px-1" href="https://twitter.com/OfficialVgec/" target="_BLANK"><i class="fa fa-twitter-square " aria-hidden="true"></i> </a>
      <a class="ds m-0 px-1" href="https://www.instagram.com/vgec.official/" target="_BLANK"><i class="fa fa-instagram " aria-hidden="true"></i> </a>

      <a class="ds m-0 px-1" href="https://www.facebook.com/VGEC.Official/" target="_BLANK"><i class="fa fa-facebook-official" aria-hidden="true"></i> </a>



      <a class="in m-0 p-1 px-3" href="./e_news_letter.php">News Letter </a>
      <a class="in m-0 p-1 px-3" href="#">Virtual Tour</a>
      <a class="in m-0 p-1 px-3" href="./">Home</a>

    </div>
    <div class=" container-float no" id="no">
      <div class="contra">
        <div class="row">
          <div class="col-lg-1 col-md-2 col-sm-3 col-3">
            <img class="logo" id="logo" src="clogo.png">
          </div>
          <div class="col-lg-11 col-md-10 col-sm-9 col-9 row op px-0">
            <div class="col-lg-5 col-md-6 col-sm-11 col-10 px-0" id="fzl_vgec">
              <div class="name pr-0" id="name">Vishwakarma Government Engineering College, <br /> Chandkheda, Ahmedabad
              </div>
              <div id="navbarContent" class="text-left collapse navbar-collapse">
                <?php include 'nav.php' ?>
              </div>
            </div>

            <div class="col-lg-7 col-md-6 col-sm-1 col-2 p-0" style="float: right;" id="fzl_logo">
              <div class="menu" id="menu">
                <nav class="navbar navbar-expand-lg navbar-light px-0" id="nv" style="padding: 1rem 1rem">
                  <a class="navbar-brand" href="#"></a>
                  <button type="button" data-toggle="collapse" data-target="#navbarContent" aria-controls="navbars" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div id="navbarContent1" class="collapse navbar-collapse">
                    <?php include 'nav.php' ?>
                  </div>
              </div>

              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  </section>

  <!-- <section id="cor"></section> -->