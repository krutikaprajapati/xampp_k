<?php
session_start();
include 'header.php';
include 'DbConnection.php';

if (!isset($_SESSION['type'])) {
    echo "<script>window.open('./login_stud_delete.php','_self')</script>";
}
$conn = OpenCon();
if ($conn) {

    $sql1 = "SELECT * FROM `event_table`";
    $ress = Select_Record($sql1, $conn);


    $eventId = $_SESSION['eventId'];
    $searchQuery = "SELECT * FROM `event_table` WHERE `e_id` = '$eventId'";
    $runsearchQuery = mysqli_query($conn, $searchQuery);
    $row = mysqli_fetch_array($runsearchQuery);
    $e_title = $row['e_title'];
    $dept_name = $row['Dept_name'];
    $e_dpoints = $row['e_dpoints'];
    $e_start_date = $row['e_start_date'];
    $e_end_date = $row['e_end_date'];
    $e_time = $row['e_time'];
    $e_venue = $row['e_venue'];
    $e_coordinator = $row['e_coordinator'];
    $e_contact = $row['e_contact'];
    $e_register = $row['e_register'];
    $e_additional = $row['e_additional'];
    $e_pdf = $row['e_pdf'];


    if (isset($_POST['update_data'])) {
        $uploadsDir2 = "./uploads/EventFiles/";
        $finalname = null;
        $e_title = $_POST['e_title'];
        $dept_name = $_POST['Dept_Name'];
        $e_coordinator = $_POST['coordinator_Name'];
        $e_date = date('Y-m-d', strtotime($_POST['e_date']));
        $e_end_date = date('Y-m-d', strtotime($_POST['e_end_date']));
        // $e_time = time('HH:MM:SS', $_POST['e_time']);
        $e_time = $_POST['e_time'];
        $e_venue = $_POST['e_venue'];
        $e_contact_details = $_POST['e_contact_details'];
        $e_registration_link = $_POST['e_registration_link'];
        $a_points = $_POST['a_points'];
        $o_points = $_POST['o_points'];


        $pdfname = $_FILES['attachment']['name'];


        $tmp_name = $_FILES['attachment']['tmp_name'];
        $targetFilePath2  = $uploadsDir2 . $pdfname;
        $fileType2        = strtolower(pathinfo($targetFilePath2, PATHINFO_EXTENSION));
        $path2 = "./uploads/EventFiles/" . time() . "_" . basename($pdfname);
        $name3 = "./uploads/EventFiles/" . time() . "_" . basename($pdfname);

        move_uploaded_file($_FILES["attachment"]["tmp_name"], $path2);
        // $sql="INSERT INTO `tblevents` (`e_id`, `Dept_Name`, `e_title`, `e_affiliation`, `date_time`,`e_end_date`, `e_venue`, `e_participants`, `e_coordinator`, `e_about`, `e_objectives`, `e_dpoints`, `e_outcomes`,`e_thumb`,`e_pdf`) VALUES (NULL, '$dept_name', '$e_title', '$e_affiliation', '$e_venue', '$e_participants', '$e_coordinator', '$a_points', '$o_points', '$d_points', '$outcomes', '$ThumbName', '$name3')";
        $updateEvent = "UPDATE `event_table` SET `e_title`= '$e_title', `Dept_name`= '$dept_name', `e_dpoints` = '$a_points', `e_start_date` = '$e_date', `e_end_date` = '$e_end_date', `e_time` = '$e_time', `e_venue` = '$e_venue', `e_coordinator` = '$e_coordinator', `e_contact` = '$e_contact_details', `e_register` = '$e_registration_link', `e_additional` = '$o_points', `e_pdf` = '$name3', `flag` = '0', `remarks` = null WHERE `e_id` = '$eventId'";
        $updateEventRun = mysqli_query($conn, $updateEvent);

        if ($updateEventRun) {
            echo "<script>alert('Record Successfully Updated !!!')</script>";
            echo "<script>window.open('./faculty_dashboard.php','_self')</script>";
            unset($_POST['update_data']);
        } else {
            echo "<script>alert('Error In Updating.')</script>";
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Add Event</title>
    <script type="text/javascript">
        function fileValidation() {
            var fileInput = document.getElementById('file');
            var filePath = fileInput.value;
            var allowedExtensions = /(\.pdf)$/i;
            if (!allowedExtensions.exec(filePath)) {
                alert('Please upload file having extensions .pdf only.');
                fileInput.value = '';
                return false;
            }
        }
    </script>
</head>

<body>
    <center style="margin-top: 1rem;">
        <h3>Add Event<h3>
    </center>


    <div class="container m-5">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">

            <div class="form-group row">
                <label for="e_title" class="col-sm-2 col-form-label">Event title :*</label>
                <input type="text" class="form-control w-25" name="e_title" id="e_title" value="<?php echo $e_title ?>" placeholder="Event title" required="true" pattern="/^[a-zA-Z0-9 !?.-]+$/" required title="Only capital, small letters and numeric values are allowed." maxlength="20">
            </div>
            <div class="form-group row">

                <label for="e_title" class="col-sm-2 col-form-label">Department Name :*</label>
                <select name="Dept_Name" class="form-control w-25" required>
                    <option value="" disabled selected value="<?php echo $dept_name ?>"><?php echo $dept_name ?></option>
                    <option value="Instrumentation & Control">Instrumentation & Control</option>
                    <option value="Institute">Institute</option>
                    <option value="Computer Engineering">Computer Engineering</option>
                    <option value="Chemical Engineering">Chemical Engineering</option>
                    <option value="Electrical Engineering">Electrical Engineering</option>
                    <option value="Civil Engineering">Civil Engineering</option>
                    <option value="Electronics & Communication">Electronics & Communication</option>
                    <option value="Mechanical Engineering">Mechanical Engineering</option>
                    <option value="Information Technology">Information Technology</option>
                    <option value="WDC">WDC</option>
                    <option value="NSS">NSS</option>
                    <option value="NCC">NCC</option>
                    <option value="IEI">IEI</option>
                    <option value="IEEE">IEEE</option>
                </select>
            </div>

            <div class="form-group row">
                <label for="coordinator_Name" class="col-sm-2 col-form-label">Coordinator Name :*</label>
                <input type="text" class="form-control w-25" name="coordinator_Name" id="coordinator_Name" placeholder="Coordinator Name" required="true" pattern="[a-zA-Z][a-zA-Z\s]*" required title="Only capital, small letters and numeric values are allowed." maxlength="20" value="<?php echo $e_coordinator ?>">
            </div>
            <div class="form-group row">
                <label for="e_date" class="col-sm-2 col-form-label">Start Date :*</label>
                <input type="date" class="form-control w-25" name="e_date" id="e_date" required="true" value="<?php echo $e_start_date ?>">
            </div>
            <div class="form-group row">
                <label for="e_end_date" class="col-sm-2 col-form-label">End Date :*</label>
                <input type="date" class="form-control w-25" name="e_end_date" id="e_end_date" required="true" value="<?php echo $e_end_date ?>">
            </div>
            <div class="form-group row">
                <label for="e_time" class="col-sm-2 col-form-label">Time :*</label>
                <input type="time" class="form-control w-25" name="e_time" id="e_time" required="true" value="<?php echo $e_time ?>">
            </div>


            <div class="form-group row">
                <label for="e_venue" class="col-sm-2 col-form-label">venue :*</label>
                <input type="text" class="form-control w-25" name="e_venue" id="e_venue" placeholder="venue" required="true" pattern="[a-zA-Z][a-zA-Z\s]*" required title="Only capital, small letters and numeric values are allowed." maxlength="20" value="<?php echo $e_venue ?>">

            </div>

            <div class="form-group row">
                <label for="e_contact_details" class="col-sm-2 col-form-label">Contact Details :*</label>
                <input type="text" class="form-control w-25" name="e_contact_details" id="e_contact_details" value="<?php echo $e_contact ?>" placeholder="contact_details" required="true" pattern="[6-9]{1}[0-9]{9}" required title="Enter valid Contact No." maxlength="10">
                <!-- <input type="text" class="form-control" id="contact" pattern="[6-9]{1}[0-9]{9}" required title="Enter valid Contact No." maxlength="10" placeholder="Enter Contact No"> -->
            </div>


            <div class="form-group row">
                <label for="e_registration_link" class="col-sm-2 col-form-label">Registration Link :</label>
                <input type="text" class="form-control w-25" name="e_registration_link" id="e_registration_link" placeholder="registration_link" value="<?php echo $e_register ?>">
            </div>

            <div class="form-group row">
                <label for="a_points" class="col-sm-2 col-form-label">Description :*</label>
                <textarea class="form-control" name="a_points" id="a_points" rows="3" required placeholder="Description section(in paragraph)" required="true" value="<?php echo $e_dpoints ?>"></textarea>
            </div>
            <div class="form-group row">
                <label for="o_points" class="col-sm-2 col-form-label">Additional Details :</label>
                <textarea class="form-control" name="o_points" id="o_points" rows="3" value="<?php echo $e_additional ?>"></textarea>
            </div>

            <div class="form-group row">
                <label for="pdf" class="col-sm-2 col-form-label">Attachment :</label>
                <input type="file" name="attachment" class="form-control w-25" accept=".png, .jpg, .jpeg, .pdf" value="<?php echo $e_pdf ?>">
            </div>
            <button type="submit" name="update_data" class="btn btn-primary">Update</button>
            <br />
        </form>
    </div>
    <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('a_points');
        CKEDITOR.replace('o_points');
    </script>







</body>

</html>
<?php
include 'footer.php';

?>