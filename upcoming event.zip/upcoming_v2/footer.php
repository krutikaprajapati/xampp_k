<?php
$conn = null;
?>

<script>
    // var hash1 = window.location.hash;
    // if (hash1) {
    //     $('html, body').animate({
    //         scrollTop: $(hash1).offset().top
    //     });
    // }

    $(window).ready(function() {
        document.getElementById("nv").style.padding = "1rem 1rem";
        if ($(window).width() > 1270) {
            $('#fzl_vgec').addClass('col-lg-5');
            $('#fzl_vgec').addClass('col-md-6');
            $('#fzl_vgec').removeClass('col-lg-11');
            $('#fzl_vgec').removeClass('col-md-11');
            // $('#fzl_logo').addClass('col-lg-7');
            // $('#fzl_logo').addClass('col-md-6');
            $('#fzl_logo').removeClass('col-lg-1');
            $('#fzl_logo').removeClass('col-md-1');
            $('#navbarContent').removeClass('show');
        } else {
            $('#fzl_vgec').addClass('col-lg-11');
            $('#fzl_vgec').addClass('col-md-11');
            $('#fzl_vgec').removeClass('col-lg-5');
            $('#fzl_vgec').removeClass('col-md-6');
            $('#fzl_logo').addClass('col-lg-1');
            $('#fzl_logo').addClass('col-md-1');
            $('#fzl_logo').removeClass('col-lg-7');
            $('#fzl_logo').removeClass('col-md-6');
        }
        if ($(window).width() < 390) {
            document.getElementById("logo").style.width = "50px";
            document.getElementById("logo").style.height = "50px";
        }

        if ($(window).width() < 380) {
            $('.in').removeClass('px-3');
        } else {
            $('.in').addClass('px-3');
        }
    });

    $(window).resize(function() {
        if ($(window).width() > 1270) {
            $('#fzl_vgec').addClass('col-lg-5');
            $('#fzl_vgec').addClass('col-md-6');
            $('#fzl_vgec').removeClass('col-lg-11');
            $('#fzl_vgec').removeClass('col-md-11');
            $('#fzl_logo').addClass('col-lg-7');
            $('#fzl_logo').addClass('col-md-6');
            $('#fzl_logo').removeClass('col-lg-1');
            $('#fzl_logo').removeClass('col-md-1');
            $('#navbarContent').removeClass('show');
        } else {
            $('#fzl_vgec').addClass('col-lg-11');
            $('#fzl_vgec').addClass('col-md-11');
            $('#fzl_vgec').removeClass('col-lg-5');
            $('#fzl_vgec').removeClass('col-md-6');
            $('#fzl_logo').addClass('col-lg-1');
            $('#fzl_logo').addClass('col-md-1');
            $('#fzl_logo').removeClass('col-lg-7');
            $('#fzl_logo').removeClass('col-md-6');
        }

        if ($(window).width() < 380) {
            $('.in').removeClass('px-3');
        } else {
            $('.in').addClass('px-3');
        }
    })
</script>

<!--footer-->
<section id="footer">
    <div class="ft">
        <div class="row">
            <div class="col-md-9 col-12">
                <div class="row mb-2">
                    <div class="col-md-2 text-center" style="padding: 0;">
                        <img class="logo-f" src="clogo.png">
                    </div>
                    <div class="col-md-10 row my-auto">
                        <h4 class="col-md-12 col-12 text-left">Vishwakarma Government Engineering College, Ahmedabad</h4>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-1"></div>
                    <div class="col-md-4 col-12 mt-2 mb-2">
                        <div class="row">
                            <div class="col-md-1 col-1">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                            </div>
                            <div class="col-md-10 col-10 text-left">
                                Nr. Visat three roads,
                                Sabarmati-Koba highway,
                                Chandkheda, Ahmedabad-382424
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-12 mt-2 mb-2">
                        <div class="row">
                            <div class="col-md-1 col-1">
                                <i class="fa fa-phone" aria-hidden="true"></i>
                            </div>
                            <div class="col-md-11 col-11 row text-left">
                                <div class="col-md-12 col-12"><a class="text-white text-decoration-none" href="tel:07923293866">(079) 23293866</a></div>
                            </div>
                            <div class="col-md-1 col-1 mt-2">
                                <i class="fa fa-envelope-o" aria-hidden="true"></i>
                            </div>
                            <div class="col-md-11 row col-11 text-left mt-2">
                                <div class="col-md-12 col-12 text-wrap"><a class="text-white text-decoration-none" href="mailto:principal@vgecg.ac.in">principal@vgecg.ac.in</a></div>
                                <div class="col-md-12 col-12 text-wrap"><a class="text-white text-decoration-none" href="mailto:vgec-abd-dte@gujarat.gov.in">vgec-abd-dte@gujarat.gov.in</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-12 mt-2 mb-2">
                        <div class="row">
                            <!-- <div class="row mt-2 text-left"> -->
                            <div class="col-md-12 col-6">
                                <a class="text-white" href="./sitemap.php">
                                    Campus Map
                                </a>
                            </div>
                            <div class="col-md-12 col-6">
                                <a class="text-white" href="./disclosure.php">
                                    Disclosures
                                </a>
                            </div>
                            <div class="col-md-12 col-6">
                                <a class="text-white" href="./useful_links.php">
                                    Important Links
                                </a>
                            </div>
                            <div class="col-md-12 col-6">
                                <a class="text-white" href="http://audies.vgecg.ac.in/" target="_blank">
                                Auditorium Booking
                                </a>
                            </div>
                        </div>

                        <!-- </div> -->
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-12 mt-3">
                <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3669.744498774129!2d72.59257941496932!3d23.106447134910596!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e83c959d4de6f%3A0x748d0828c02cf9fa!2sVishwakarma%20Government%20Engineering%20College!5e0!3m2!1sen!2sin!4v1596020468974!5m2!1sen!2sin" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
            <div class="col-md-12 col-12 mt-3 text-center">
                Last Updated: <?php echo date('d/m/Y'); ?> | Designed & Developed by <a href="developer.php" class="text-reset">Information Technology Department</a>
            </div>
        </div>
    </div>
</section>


<!--footer-->



<script defer src="nav.js"></script>


<!-- jQuery -->
<script src="js/jquery.min.js"></script>
</script>
<!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script> -->
<!-- <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script> -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>

</html>