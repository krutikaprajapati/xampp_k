<?php 

if (!isset($_SESSION['type'])) {
    echo "<script>window.open('./login.php','_self')</script>";
}
if (isset($_POST['ViewEvent'])) {
    $eventId = $_POST['getId'];
    $_SESSION['eventId'] = $eventId;
    echo "<script>window.open('./ViewEvent.php','_self')</script>";
}
if (isset($_POST['editEvent'])) {
    $eventId = $_POST['getId'];
    $_SESSION['eventId'] = $eventId;
    echo "<script>window.open('./editEvent.php','_self')</script>";
}

?>