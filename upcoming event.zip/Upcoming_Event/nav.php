<ul class="navbar-nav mr-auto fzl-nav">
    <!-- <li class="nav-item">
                        <a class="nav-link" href="./">Home</a>
                      </li> -->
    <!-- Level one dropdown -->


    <!-- End Level one -->
    <li class="nav-item dropdown">

        <a id="dropdownMenu1" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle" style="color:#003975 !important;">About us</a>
        <ul aria-labelledby="dropdownMenu1" class="fzl-dropdown-menu dropdown-menu border-0 shadow">
            <li><a href="./index.php#details" class="dropdown-item">Vision</a></li>
            <li><a href="./index.php#details" class="dropdown-item">Mission</a></li>
            <li><a href="./principal.php" class="dropdown-item">Principal</a></li>
            <li><a href="./awards_and_achievements.php" class="dropdown-item">Awards and Achievements</a></li>
            <li><a href="./e_news_letter.php" class="dropdown-item">VGEC E-News Letter</a></li>
        </ul>
    </li>
    <li class="nav-item dropdown">

        <a id="dropdownMenu1" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle" style="color:#003975 !important;">Academics</a>
        <ul aria-labelledby="dropdownMenu1" class="dropdown-menu border-0 shadow">
            <li><a href="admissions.php" class="dropdown-item">Admissions</a></li>
            <!-- Level two dropdown-->
            <li class="dropdown-submenu">
                <a id="dropdownMenu2" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-item dropdown-toggle">UG Programs</a>
                <ul aria-labelledby="dropdownMenu2" class="dropdown-menu border-0 shadow">
                    <li>
                        <a tabindex="-1" href="./department.php?dept=2" class="dropdown-item">Chemical Engineering</a>
                    </li>
                    <li><a href="./department.php?dept=4" class="dropdown-item">Civil Engineering</a></li>
                    <li><a href="./department.php?dept=3" class="dropdown-item">Computer Engineering</a></li>
                    <li><a href="./department.php?dept=5" class="dropdown-item">Electrical Engineereing</a></li>
                    <li><a href="./department.php?dept=6" class="dropdown-item">Electronics and Communication</a></li>
                    <li><a href="./department.php?dept=7" class="dropdown-item">Information Technology</a></li>
                    <li><a href="./department.php?dept=8" class="dropdown-item">Instrumentation and Control</a></li>
                    <li><a href="./department.php?dept=9" class="dropdown-item">Mechanical Engineering</a></li>
                    <li><a href="./department.php?dept=10" class="dropdown-item">Power Electronics</a></li>
                    <li><a href="./department.php?dept=12" class="dropdown-item">Applied Mechanics</a></li>
                    <li><a href="./department.php?dept=11" class="dropdown-item">Science And Humanities</a></li>
                </ul>
            </li>
            <li class="dropdown-submenu">
                <a id="dropdownMenu2" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-item dropdown-toggle">PG Programs</a>
                <ul aria-labelledby="dropdownMenu2" class="dropdown-menu border-0 shadow">
                    <li>
                        <a tabindex="-1" href="./department.php?dept=2" class="dropdown-item">Chemical Engineering</a>
                    </li>

                    <li><a href="./department.php?dept=6" class="dropdown-item">Electronics and Communication</a></li>

                </ul>
            </li>
            <li class="dropdown-submenu">
                <a id="dropdownMenu2" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-item dropdown-toggle">Research & Innovation </a>
                <ul aria-labelledby="dropdownMenu2" class="dropdown-menu border-0 shadow">
                    <li><a tabindex="-1" href="./r&i_projects.php" class="dropdown-item">Funded Projects</a></li>
                    <li><a href="./research.php" class="dropdown-item">Research</a></li>
                    <li><a href="./r&i_ssip.php" class="dropdown-item">SSIP</a></li>
                    <li><a href="./r&i_patents.php" class="dropdown-item">Patents</a></li>
                </ul>
            </li>
            <!-- End Level two -->
        </ul>
    </li>
    <li class="nav-item dropdown">

        <a id="dropdownMenu1" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle" style="color:#003975 !important;">Facilities</a>
        <ul aria-labelledby="dropdownMenu1" class="dropdown-menu border-0 shadow">
            <li><a href="./hostel.php" class="dropdown-item">Hostel</a></li>
            <li><a href="./library.php" class="dropdown-item">Library</a></li>
            <li><a href="./sports.php" class="dropdown-item">Sports</a></li>
            <!-- <li><a href="#" class="dropdown-item">Laboratories</a></li> -->
            <li><a href="./central_facility.php" class="dropdown-item">Central Facilities</a></li>
            <li><a href="./student_section.php" class="dropdown-item">Student Section</a></li>
            <li><a href="./medical.php" class="dropdown-item">Medical Facilities</a></li>
            <li><a href="./transport.php" class="dropdown-item">Transportation</a></li>
        </ul>
    </li>
    <li class="nav-item dropdown">

        <a id="dropdownMenu1" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle" style="color:#003975 !important;">Life @ VGEC</a>
        <ul aria-labelledby="dropdownMenu1" class="dropdown-menu border-0 shadow">
            <li><a href="./events.php" class="dropdown-item">Events</a></li>
            <!-- <li><a href="#" class="dropdown-item">TechFest</a></li> -->
            <li class="dropdown-submenu">
                <a id="dropdownMenu2" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-item dropdown-toggle">Student Chapters</a>
                <ul aria-labelledby="dropdownMenu2" class="dropdown-menu border-0 shadow">
                    <li>
                        <a tabindex="-1" href="./iei.php" class="dropdown-item">IEI Chapters</a>
                    </li>

                    <li><a target="_BLANK" href="http://ieee.vgecg.ac.in/" class="dropdown-item">IEEE Chapters</a></li>
                </ul>
            </li>
            <li class="dropdown-submenu">
                <a id="dropdownMenu2" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-item dropdown-toggle">Student Clubs</a>
                <ul aria-labelledby="dropdownMenu2" class="dropdown-menu border-0 shadow">
                    <li>
                        <a tabindex="-1" href="./advanature.php" class="dropdown-item">AdvaNature</a>
                    </li>
                </ul>
            </li>
            <!-- <li class="dropdown-submenu">
                <a id="dropdownMenu2" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-item dropdown-toggle">Nation Building</a>
                <ul aria-labelledby="dropdownMenu2" class="dropdown-menu border-0 shadow">
                    <li>
                        <a tabindex="-1" href="./ncc.php" class="dropdown-item">NCC</a>
                    </li>
                    <li><a href="./nss.php" class="dropdown-item">NSS</a></li>
                </ul>
            </li> -->
            <li><a href="./ncc.php" class="dropdown-item">NCC</a></li>
            <li><a href="./nss.php" class="dropdown-item">NSS</a></li>
            <li><a href="./women_empowerment.php" class="dropdown-item">Women Empowerment</a></li>

        </ul>
    </li>
    <li class="nav-item dropdown">

        <a id="dropdownMenu1" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle" style="color:#003975 !important;">Placements</a>
        <ul aria-labelledby="dropdownMenu1" class="dropdown-menu border-0 shadow">
            <li><a href="./placement.php#team" class="dropdown-item">Placement Team</a></li>
            <li><a href="./placement.php#partner" class="dropdown-item">Placement Partners</a></li>
            <li><a href="http://placement.vgecg.ac.in/placement_details.php" target="_BLANK" class="dropdown-item">Statistics</a></li>
            <li><a href="http://placement.vgecg.ac.in" class="dropdown-item" target="_BLANK">Placement Portal</a></li>
        </ul>
    </li>
    <li class="nav-item dropdown">

        <a id="dropdownMenu1" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle" style="color:#003975 !important;">People</a>
        <ul aria-labelledby="dropdownMenu1" class="dropdown-menu border-0 shadow">
            <li><a href="./faculties.php" class="dropdown-item">Faculty</a></li>
            <li><a href="./other_staff.php" class="dropdown-item">Other Staff</a></li>
            <li><a href="https://www.vgecalumni.org" class="dropdown-item" target="_BLANK">Alumni</a></li>
        </ul>
    </li>

    <li class="nav-item dropdown">
        <a id="dropdownMenu1" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle" style="color:#003975 !important;">Other</a>
        <ul aria-labelledby="dropdownMenu1" class="dropdown-menu border-0 shadow">
            <li><a href="./iqse.php" class="dropdown-item">IQAC</a></li>
            <li><a href="./aicte_eoc.php" class="dropdown-item">AICTE EOA Report</a></li>
            <li><a href="./disclosure.php" class="dropdown-item">Disclosure</a></li>
            <li><a href="./grievance.php" class="dropdown-item">Grievance Cell</a></li>
            <li><a href="./imp_forms.php" class="dropdown-item">Important Forms</a></li>

        </ul>
    </li>

    <!-- <li class="nav-item">
                        <a class="nav-link" href="#footer">Contact Us</a>
                      </li> -->
</ul>