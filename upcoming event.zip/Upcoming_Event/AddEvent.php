<?php

include('database/include.php');
include 'header.php';

?>

<!DOCTYPE html>
<html>

<head>
	<title>Add Event</title>
	<script type="text/javascript">
		function fileValidation() {
			var fileInput = document.getElementById('file');
			var filePath = fileInput.value;
			var allowedExtensions = /(\.pdf)$/i;
			if (!allowedExtensions.exec(filePath)) {
				alert('Please upload file having extensions .pdf only.');
				fileInput.value = '';
				return false;
			}
		}
	</script>
</head>

<body>
	<center style="margin-top: 1rem;">
		<h3>Add Event<h3>
	</center>


	<div class="container m-5">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
		<form action="addEvent_check.php" method="post" enctype="multipart/form-data">

			<div class="form-group row">
				<label for="e_title" class="col-sm-2 col-form-label">Event title :*</label>
				<input type="text" class="form-control w-25" name="e_title" id="e_title" placeholder="Event title" required="true" onkeypress="return event.charCode>=65 && event.charCode<=90 || event.charCode>=97 && event.charCode<=122 || event.charCode==32 || event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" pattern="[a-zA-Z0-9.\s]+" required title="Only capital, small letters and numeric values are allowed." maxlength="20">
			</div>
			<div class="form-group row">

				<label for="e_title" class="col-sm-2 col-form-label">Department Name :*</label>
				<select name="Dept_Name" class="form-control w-25" required>
					<option value="" disabled selected>Select Department</option>
					<option value="Instrumentation & Control">Instrumentation & Control</option>
					<option value="Institute">Institute</option>
					<option value="Computer Engineering">Computer Engineering</option>
					<option value="Chemical Engineering">Chemical Engineering</option>
					<option value="Electrical Engineering">Electrical Engineering</option>
					<option value="Civil Engineering">Civil Engineering</option>
					<option value="Electronics & Communication">Electronics & Communication</option>
					<option value="Mechanical Engineering">Mechanical Engineering</option>
					<option value="Information Technology">Information Technology</option>
					<option value="WDC">WDC</option>
					<option value="NSS">NSS</option>
					<option value="NCC">NCC</option>
					<option value="IEI">IEI</option>
					<option value="IEEE">IEEE</option>
				</select>
			</div>

			<div class="form-group row">
				<label for="coordinator_Name" class="col-sm-2 col-form-label">Coordinator Name :*</label>
				<input type="text" class="form-control w-25" name="coordinator_Name" id="coordinator_Name" placeholder="Coordinator Name" required="true" onkeypress="return event.charCode>=65 && event.charCode<=90 || event.charCode>=97 && event.charCode<=122 || event.charCode==32 || event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" pattern="[a-zA-Z0-9.\s]+" required title="Only capital, small letters and numeric values are allowed." maxlength="20">
			</div>
			<div class="form-group row">
				<label for="e_date" class="col-sm-2 col-form-label">Start Date :*</label>
				<input type="date" class="form-control w-25 e_start_date" name="e_date" id="e_date" required="true">
			</div>
			<div class="form-group row">
				<label for="e_end_date" class="col-sm-2 col-form-label">End Date :*</label>
				<input type="date" class="form-control w-25" name="e_end_date" id="e_end_date" required="true">
			</div>
			<div class="form-group row">
				<label for="e_time" class="col-sm-2 col-form-label">Time :*</label>
				<input type="time" class="form-control w-25" name="e_time" id="e_time" required="true">
			</div>


			<div class="form-group row">
				<label for="e_venue" class="col-sm-2 col-form-label">venue :*</label>
				<input type="text" class="form-control w-25" name="e_venue" id="e_venue" placeholder="venue" required="true" onkeypress="return event.charCode>=65 && event.charCode<=90 || event.charCode>=97 && event.charCode<=122 || event.charCode==32 || event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" pattern="[a-zA-Z0-9-\s]+" required title="Only capital, small letters and numeric values are allowed." maxlength="20">

			</div>

			<div class="form-group row">
				<label for="e_contact_details" class="col-sm-2 col-form-label">Contact Details :*</label>
				<input type="text" class="form-control w-25" name="e_contact_details" id="e_contact_details" placeholder="contact details" required="true" pattern="[6-9]{1}[0-9]{9}" required title="Enter valid Contact No." maxlength="10">
			</div>


			<div class="form-group row">
				<label for="e_registration_link" class="col-sm-2 col-form-label">Registration Link :</label>
				<input type="text" class="form-control w-25" name="e_registration_link" id="e_registration_link" placeholder="registration link">
			</div>

			<div class="form-group row">
				<label for="a_points" class="col-sm-2 col-form-label">Description :*</label>
				<textarea class="form-control" name="a_points" id="a_points" rows="3" required placeholder="Description section(in paragraph)" required="true"></textarea>
			</div>
			<div class="form-group row">
				<label for="o_points" class="col-sm-2 col-form-label">Additional Details :</label>
				<textarea class="form-control" name="o_points" id="o_points" rows="3"></textarea>
			</div>

			<div class="form-group row">
				<label for="pdf" class="col-sm-2 col-form-label">Attachment :</label>
				<input type="file" name="attachment" class="form-control w-25" accept=".png, .jpg, .jpeg, .pdf">
			</div>
			<button type="submit" name="submit_data" class="btn btn-primary">Submit</button>
			<br />
		</form>
	</div>
	<script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
	<script>
		CKEDITOR.replace('a_points');
		CKEDITOR.replace('o_points');
	</script>

	<script>
		let today = new Date();
		let day = today.getDate();
		let month = today.getMonth() + 1;
		let year = today.getFullYear();
		if(day<10){
                day='0'+day
            } 
        if(month<10){
            month='0'+month
        }
		today = year+'-'+month+'-'+day;

		var startDate = document.getElementById("e_date");
        var endDate = document.getElementById("e_end_date");
		
        startDate.setAttribute('min', today);
        endDate.setAttribute('min', startDate.value);
        startDate.onchange = function() {
            endDate.setAttribute('min', this.value);
        }
	</script>





</body>

</html>
<?php
include 'footer.php';

?>