<?php

include('database/include.php');
include 'header.php';
include('editEvent_data.php');

?>

<!DOCTYPE html>
<html>

<head>
    <title>Add Event</title>
    <script type="text/javascript">
        function fileValidation() {
            var fileInput = document.getElementById('file');
            var filePath = fileInput.value;
            var allowedExtensions = /(\.pdf)$/i;
            if (!allowedExtensions.exec(filePath)) {
                alert('Please upload file having extensions .pdf only.');
                fileInput.value = '';
                return false;
            }
        }
    </script>
</head>

<body>
    <center style="margin-top: 1rem;">
        <h3>Edit Event<h3>
    </center>


    <div class="container m-5">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
        <form action="editEvent_UpdateData.php" method="post" enctype="multipart/form-data">

            <div class="form-group row">
                <label for="e_title" class="col-sm-2 col-form-label">Event title :*</label>
                <input type="text" class="form-control w-25" name="e_title" id="e_title" value="<?php echo $e_title ?>" placeholder="Event title" required="true" required title="Only capital, small letters and numeric values are allowed." pattern="[a-zA-Z0-9.\s]+" maxlength="20">
            </div>
            <div class="form-group row">

                <label for="e_title" class="col-sm-2 col-form-label">Department Name :*</label>
                <?php $arrayOfSelect = array("Instrumentation & Control","Institute","Computer Engineering","Chemical Engineering","Electrical Engineering","Civil Engineering","Electronics & Communication","Mechanical Engineering","Information Technology","WDC","NSS","NCC","IEI","IEEE");
                    $dammyarray = array();
                    for($i=0;$i<count($arrayOfSelect);$i++){
                        if($dept_name == $arrayOfSelect[$i]) {
                            $dammyarray[$i] = "selected";
                        } else {
                            $dammyarray[$i] = "";
                        }
                    }
                ?>
                <select name="Dept_Name" class="form-control w-25" required>
                    <option <?php echo $dammyarray[0]; ?> value="Instrumentation & Control">Instrumentation & Control</option>
                    <option <?php echo $dammyarray[1]; ?> value="Institute">Institute</option>
                    <option <?php echo $dammyarray[2]; ?> value="Computer Engineering">Computer Engineering</option>
                    <option <?php echo $dammyarray[3]; ?> value="Chemical Engineering">Chemical Engineering</option>
                    <option <?php echo $dammyarray[4]; ?> value="Electrical Engineering">Electrical Engineering</option>
                    <option <?php echo $dammyarray[5]; ?> value="Civil Engineering">Civil Engineering</option>
                    <option <?php echo $dammyarray[6]; ?> value="Electronics & Communication">Electronics & Communication</option>
                    <option <?php echo $dammyarray[7]; ?> value="Mechanical Engineering">Mechanical Engineering</option>
                    <option <?php echo $dammyarray[8]; ?> value="Information Technology">Information Technology</option>
                    <option <?php echo $dammyarray[9]; ?> value="WDC">WDC</option>
                    <option <?php echo $dammyarray[10]; ?> value="NSS">NSS</option>
                    <option <?php echo $dammyarray[11]; ?> value="NCC">NCC</option>
                    <option <?php echo $dammyarray[12]; ?> value="IEI">IEI</option>
                    <option <?php echo $dammyarray[13]; ?> value="IEEE">IEEE</option>
                </select>
            </div>

            <div class="form-group row">
                <label for="coordinator_Name" class="col-sm-2 col-form-label">Coordinator Name :*</label>
                <input type="text" class="form-control w-25" name="coordinator_Name" id="coordinator_Name" placeholder="Coordinator Name" required="true" pattern="[a-zA-Z0-9.\s]+" required title="Only capital, small letters and numeric values are allowed." maxlength="20" value="<?php echo $e_coordinator ?>">
            </div>
            <div class="form-group row">
                <label for="e_date" class="col-sm-2 col-form-label">Start Date :*</label>
                <input type="date" class="form-control w-25" name="e_date" id="e_date" required="true" value="<?php echo $e_start_date ?>">
            </div>
            <div class="form-group row">
                <label for="e_end_date" class="col-sm-2 col-form-label">End Date :*</label>
                <input type="date" class="form-control w-25" name="e_end_date" id="e_end_date" required="true" value="<?php echo $e_end_date ?>">
            </div>
            <div class="form-group row">
                <label for="e_time" class="col-sm-2 col-form-label">Time :*</label>
                <input type="time" class="form-control w-25" name="e_time" id="e_time" required="true" value="<?php echo $e_time ?>">
            </div>


            <div class="form-group row">
                <label for="e_venue" class="col-sm-2 col-form-label">venue :*</label>
                <input type="text" class="form-control w-25" name="e_venue" id="e_venue" placeholder="venue" required="true" pattern="[a-zA-Z0-9-\s]+" required title="Only capital, small letters and numeric values are allowed." maxlength="20" value="<?php echo $e_venue ?>">

            </div>

            <div class="form-group row">
                <label for="e_contact_details" class="col-sm-2 col-form-label">Contact Details :*</label>
                <input type="text" class="form-control w-25" name="e_contact_details" id="e_contact_details" value="<?php echo $e_contact ?>" placeholder="contact_details" required="true" pattern="[6-9]{1}[0-9]{9}" required title="Enter valid Contact No." maxlength="10">
                <!-- <input type="text" class="form-control" id="contact" pattern="[6-9]{1}[0-9]{9}" required title="Enter valid Contact No." maxlength="10" placeholder="Enter Contact No"> -->
            </div>


            <div class="form-group row">
                <label for="e_registration_link" class="col-sm-2 col-form-label">Registration Link :</label>
                <input type="text" class="form-control w-25" name="e_registration_link" id="e_registration_link" placeholder="registration_link" value="<?php echo $e_register ?>">
            </div>

            <div class="form-group row">
                <label for="a_points" class="col-sm-2 col-form-label">Description :*</label>
                <textarea class="form-control" name="a_points" id="a_points" rows="3" required placeholder="Description section(in paragraph)" required="true"><?php echo htmlspecialchars($e_dpoints); ?></textarea>
            </div>
            <div class="form-group row">
                <label for="o_points" class="col-sm-2 col-form-label">Additional Details :</label>
                <textarea class="form-control" name="o_points" id="o_points" rows="3"><?php echo htmlspecialchars($e_additional); ?></textarea>
                <br>
            </div>

            <div class="form-group row">
                <label for="pdf" class="col-sm-2 col-form-label">Attachment :</label>
                <input type="file" name="attachment" class="form-control w-25" accept=".png, .jpg, .jpeg, .pdf">
                <p style="margin-top: 1rem;margin-left: 0.65rem;"><strong>Note : </strong>If You Are not uploading anything then old file be consider and if you want to add new then simple add pdf/image above.</p>
            </div>
            <button type="submit" name="update_data" class="btn btn-primary">Update</button>
            <br />
        </form>
    </div>
    <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('a_points');
        CKEDITOR.replace('o_points');
    </script>

    <script>
        let today = new Date();
		let day = today.getDate();
		let month = today.getMonth() + 1;
		let year = today.getFullYear();
		if(day<10){
                day='0'+day
            } 
        if(month<10){
            month='0'+month
        }
		today = year+'-'+month+'-'+day;

		var startDate = document.getElementById("e_date");
        var endDate = document.getElementById("e_end_date");
		
        startDate.setAttribute('min', today);
        endDate.setAttribute('min', startDate.value);
        startDate.onchange = function() {
            endDate.setAttribute('min', this.value);
        }
    </script>



</body>

</html>
<?php
include 'footer.php';
?>