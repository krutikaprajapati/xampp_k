<?php

include("database/include.php");
include("header.php");

?>
<pre>


</pre>
<div id="page">
    <div class="col-md-6 mx-auto my-5">
        <h2 class="dept-title"> Login for Deleting Data</h2>
        <div class="px-3 mb-4 pt-3 apply" style="border: 1px solid #003865;">
            <!-- <h4 class="headingsall bg-light"></h4> -->
            <form method="post" action="changePassword_check.php">
                <div class="headingsall">
                    <label name="email">Email</label>
                    <input name="email" type="text" class="form-control" required="required">
                </div>

                <div class="mt-3 headingsall">
                    <label name="oldpassword">Old Password</label>
                    <input name="oldpassword" type="password" class="form-control" required="required">
                </div>
                <div class="mt-3 headingsall">
                    <label name="newpassword">New Password</label>
                    <input name="newpassword" type="password" class="form-control" required="required">
                </div>
                <div class="mt-3 headingsall">
                    <label name="confirmpassword">Confirm Password</label>
                    <input name="confirmpassword" type="password" class="form-control" required="required">
                </div>
                <center>
                    <div class="col-md-6 my-3 text-center">
                        <input type="submit" name="change_pwd" class="btn btn-primary py-2" value="Update" />
                    </div>
                </center>
            </form>
        </div>
    </div>
</div>
<div class="space" style="margin-bottom: 5.75%;"></div>
<?php
// echo "<script>window.open('index.php','_self')</script>"; 
include("footer.php");
?>