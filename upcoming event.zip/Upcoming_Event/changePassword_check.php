<?php

include('database/include.php');

    $email = $_POST['email'];
    $opwd = $_POST['oldpassword'];
    $npwd = $_POST['newpassword'];
    $cpwd = $_POST['confirmpassword'];


    $search = "SELECT * FROM `add_event_login` WHERE `c_email` = '$email' AND `password` = '$opwd'";
    $searchResult = Select_Record($search, $conn);

    $result = mysqli_fetch_array($searchResult);

    if ($searchResult->num_rows > 0) {
        if ($npwd === $cpwd) {
            $update = "UPDATE `add_event_login` SET `password`='$npwd' WHERE `c_email` = '$email'";
            $updateResult = mysqli_query($conn, $update);

            if ($updateResult) {
                echo "<script>alert('Password Changed !!')</script>";
                echo "<script>window.open('./faculty_dashboard.php','_self')</script>";
            } else {
                echo "<script>alert('Error in update password !!')</script>";
                echo "<script>window.open('./faculty_dashboard.php','_self')</script>";
            }
        } else {
            echo "<script>alert('Password are not matching !!')</script>";
            echo "<script>window.open('./ChangePassword.php','_self')</script>";
        }
    } else {
        echo "<script>alert('User dose not exists !!')</script>";
        echo "<script>window.open('./ChangePassword.php','_self')</script>";
    }

?>