<?php 

include "database/include.php";
if(isset($_SESSION['admin']))
{
unset($_SESSION['admin']);
$_SESSION['message']="<div class='chip green white-text'>successfully Logged Out.</div>";
header("Location: login.php");
}
else
{
  $_SESSION['message']="<div class='chip red black-text'>Login To Continue</div>";
  header("Location: login.php");
}
?>