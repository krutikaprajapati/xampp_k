<?php

include('database/include.php');
include 'header.php';
include('editEventByAdmin.php');
include('media_check.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css"> -->
    <title>Dashboard</title>
</head>

<body>
    <div class="container" style="display: flex;
    flex-direction: column;
    align-items: center;">
        <center style="margin-top: 1rem;margin-bottom: 0.5rem;">
            <a href="./logout_a.php"> Logout</a>

            <h2>Not Approved</h2>
        </center>
        <div class="p-4 mb-4" id="research_sch" style="border: 1px solid rgb(0, 56, 101); width: 100%;">
            <table id="example2" class="row-border hover order-column stat stat-hover table-responsive table" style="width:100%">
                <thead class="text-center">
                    <tr>
                        <th>Sr No.</th>
                        <th>Date </th>
                        <th>Department Name</th>
                        <th>Event Name</th>
                        <th>Coordinator Name</th>
                        <th>Edit</th>
                        <th>View</th>
                    </tr>
                </thead>
                <tbody class="text-center">

                    <?php
                    $i = 1;
                    $sql = "SELECT * FROM `event_table` ORDER BY `e_id` DESC ";
                    $result = Select_Record($sql, $conn);
                    if ($result) {
                        foreach ($result as $k) {
                            $id = $k['e_id'];
                            $rek = $k['remarks'];
                            $flag = $k['flag'];
                    ?>
                            <?php if ($rek == NULL && $flag == 0) {
                            ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $k['e_start_date']; ?></td>
                                    <td><?php echo $k['Dept_name']; ?></td>
                                    <td><?php echo $k['e_title']; ?></td>
                                    <td><?php echo $k['e_coordinator']; ?></td>
                                    <td>
                                        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                                            <center>
                                                <div class=" px-3 py-2 text-center">
                                                    <input type="hidden" name="getId" value="<?php echo $k['e_id'] ?>">
                                                    <input type="submit" name="editEvent" class="btn btn-primary py-2" value="Edit" />
                                                </div>
                                            </center>
                                        </form>
                                    </td>
                                    <td>
                                        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                                            <center>
                                                <div class="px-3 py-2 text-center">
                                                    <input type="hidden" name="getId" value="<?php echo $k['e_id']; ?>">
                                                    <input type="submit" name="ViewEvent" class="btn btn-primary py-2" value="View" />
                                                </div>
                                            </center>
                                        </form>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                    <?php
                            $i++;
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php

    include 'footer.php' ?>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            var table = $('#example').DataTable();
            $('#example tbody').on('mouseenter', 'td', function() {
                var colIdx = table.cell(this).index().column;
                $(table.cells().nodes()).removeClass('highlight');
                $(table.column(colIdx).nodes()).addClass('highlight');
            });
            var table2 = $('#example2').DataTable();
            $('#example2 tbody').on('mouseenter', 'td', function() {
                var colIdx = table2.cell(this).index().column;
                $(table2.cells().nodes()).removeClass('highlight');
                $(table2.column(colIdx).nodes()).addClass('highlight');
            });
            $(".sorting:contains(More)").removeClass('sorting');
        });
    </script>
</body>

</html>