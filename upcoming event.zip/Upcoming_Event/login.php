<?php

session_start();

include("header.php");
?>
<pre>


</pre>
<div id="page">
    <div class="col-md-6 mx-auto my-5">
        <h2 class="dept-title"> Login For Event</h2>
        <div class="px-3 mb-4 pt-3 apply" style="border: 1px solid #003865;">
            <!-- <h4 class="headingsall bg-light"></h4> -->
            <form method="post" action="login_check.php">
                <div class="headingsall">
                    <label name="username">Username</label>
                    <input name="username" type="text" class="form-control" required="required">
                </div>
                <div class="mt-3 headingsall">
                    <label name="password">Password</label>
                    <input name="password" type="password" class="form-control" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required="required">
                </div>
                <center>
                <div class="col-md-6 my-3 text-center">
                    <input type="submit" name="login" class="btn btn-primary py-2" value="Login" />
                </div>
                </center>
            </form>
        </div>
    </div>
</div>
<div class="space" style="margin-bottom: 5.75%;"></div>
<?php
    include("footer.php");
?>