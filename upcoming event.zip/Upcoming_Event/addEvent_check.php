<?php 

include('database/include.php');

    $sql1 = "SELECT * FROM `event_table`";
	$ress = Select_Record($sql1, $conn);

	if (isset($_POST['submit_data'])) {
		$uploadsDir2 = "./uploads/EventFiles/";
		$finalname = null;
		$e_title = $_POST['e_title'];
		$dept_name = $_POST['Dept_Name'];
		$e_coordinator = $_POST['coordinator_Name'];
		$e_date = date('Y-m-d', strtotime($_POST['e_date']));
		$e_end_date = date('Y-m-d', strtotime($_POST['e_end_date']));
		// $e_time = time('HH:MM:SS', $_POST['e_time']);
		$e_time = $_POST['e_time'];
		$e_venue = $_POST['e_venue'];
		$e_contact_details = $_POST['e_contact_details'];
		$e_registration_link = $_POST['e_registration_link'];
		$a_points = $_POST['a_points'];
		$o_points = $_POST['o_points'];


		if(empty($_FILES["attachment"]["name"])){
			$nameOfPdf = "";
		} else {
			$pdfname = $_FILES['attachment']['name'];
			$tmp_name = $_FILES['attachment']['tmp_name'];
			$targetFilePath2  = $uploadsDir2 . $pdfname;
			$fileType2 = strtolower(pathinfo($targetFilePath2, PATHINFO_EXTENSION));
			$path2 = "./uploads/EventFiles/" . time() . "_" . basename($pdfname);
			$nameOfPdf = "./uploads/EventFiles/" . time() . "_" . basename($pdfname);
		}

		move_uploaded_file($_FILES["attachment"]["tmp_name"], $path2);
		$sql = "INSERT INTO `event_table`(`e_title`, `Dept_name`, `e_dpoints`, `e_start_date`, `e_end_date`, `e_time`, `e_venue`, `e_coordinator`, `e_contact`, `e_register`, `e_additional`, `e_pdf`, `flag`) VALUES ('$e_title','$dept_name','$a_points','$e_date','$e_end_date','$e_time','$e_venue','$e_coordinator','$e_contact_details','$e_registration_link','$o_points','$nameOfPdf','0')";

		if (Insert_Record($sql, $conn)) {
			echo "<script>alert('Record Successfully Inserted!!')</script>";
			echo "<script>window.open('./faculty_dashboard.php','_self')</script>";
			unset($_POST['submit_data']);
		} else {
			echo "<script>alert('Error In Inserting.')</script>";
			exit();
		}
	}

?>