<?php

if (isset($_POST['editEvent'])) {
    $eventId = $_POST['getId'];
    $_SESSION['eventId'] = $eventId;
    echo "<script>window.open('./editEvent.php','_self')</script>";
}

?>