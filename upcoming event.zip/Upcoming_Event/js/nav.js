window.onscroll = function() { scrollFunction() };

function scrollFunction() {
    if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 60) {

        document.getElementById("logo").style.width = "70px";
        document.getElementById("logo").style.height = "70px";

        // document.getElementById("nv").style.padding="1rem 1rem";
        // document.getElementById("name").style.display = "none";

    } else {
        document.getElementById("logo").style.width = "70px";
        document.getElementById("logo").style.height = "70px";
        document.getElementById("name").style.display = "inline-block";
        // document.getElementById("nv").style.padding="1rem 1rem";
    }
}