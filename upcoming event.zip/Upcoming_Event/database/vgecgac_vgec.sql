-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2022 at 01:03 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vgecgac_vgec`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_event_login`
--

CREATE TABLE `add_event_login` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `d_name` varchar(255) NOT NULL,
  `c_name` varchar(255) NOT NULL,
  `c_email` varchar(255) NOT NULL,
  `authority` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_event_login`
--

INSERT INTO `add_event_login` (`id`, `username`, `password`, `d_name`, `c_name`, `c_email`, `authority`) VALUES
(1, 'admin', 'Admin@123', 'Media', 'Admin', 'admin@gmail.com', 1),
(2, 'jrd', 'Jrd@1234', 'I.T.', 'Jasvant R. Dave', 'jrd@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `event_table`
--

CREATE TABLE `event_table` (
  `e_id` int(11) NOT NULL,
  `e_title` varchar(200) CHARACTER SET latin1 NOT NULL,
  `Dept_name` varchar(200) CHARACTER SET latin1 NOT NULL,
  `e_dpoints` text CHARACTER SET latin1 NOT NULL,
  `e_start_date` date NOT NULL,
  `e_end_date` date NOT NULL,
  `e_time` time NOT NULL,
  `e_venue` varchar(200) NOT NULL,
  `e_coordinator` varchar(200) CHARACTER SET latin1 NOT NULL,
  `e_contact` varchar(15) CHARACTER SET latin1 NOT NULL,
  `e_register` varchar(255) CHARACTER SET latin1 NOT NULL,
  `e_additional` text NOT NULL,
  `e_pdf` text CHARACTER SET latin1 NOT NULL,
  `remarks` varchar(200) CHARACTER SET latin1 NOT NULL,
  `flag` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event_table`
--

INSERT INTO `event_table` (`e_id`, `e_title`, `Dept_name`, `e_dpoints`, `e_start_date`, `e_end_date`, `e_time`, `e_venue`, `e_coordinator`, `e_contact`, `e_register`, `e_additional`, `e_pdf`, `remarks`, `flag`) VALUES
(2, 'ABC', 'Chemical Engineering', '<p>cjdhdjh</p>\r\n', '2022-04-13', '2022-04-08', '21:27:00', 'KFH', 'KFL', '9526824568', '', '<p>sjfkm,gf</p>\r\n', './uploads/EventFiles/1648904153_', '', 1),
(3, 'Yaksh', 'Computer Engineering', '<p>Hello</p>\r\n', '2022-04-06', '2022-04-07', '15:05:00', 'Btwozerotwo', 'JRD', '9526824568', 'null', '<p><strong>Byy</strong></p>\r\n', './uploads/EventFiles/1649097105_', 'This is for demo.', 0),
(4, 'Yaksh 2.1', 'Information Technology', '<p>Hello My name is <em><strong>Yaksh</strong></em>.</p>\r\n', '2022-04-06', '2022-04-13', '14:59:00', 'Btwozerotwo', 'JRD', '9526824568', '', '<p>This Is <s>Add Event Project</s> all about.</p>\r\n', './uploads/EventFiles/1649138271_Linux_Command.pdf', '', 1),
(5, 'Nilay', 'WDC', '<p>Yoga Class</p>\r\n', '2022-04-10', '2022-04-20', '05:45:00', 'Yoga', 'SJM', '9526824568', '', '', './uploads/EventFiles/1649097342_', '', 0),
(6, 'Harsh', 'Information Technology', '<p>It is for&nbsp;<strong>demo.</strong></p>\r\n', '2022-04-01', '2022-04-09', '17:00:00', 'L202', 'SJM', '9526824568', '', '<p>Yeah we did&nbsp;<em>it.</em></p>\r\n', './uploads/EventFiles/1649154877_200170116029_OOP_Practical02.pdf', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_event_login`
--
ALTER TABLE `add_event_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_table`
--
ALTER TABLE `event_table`
  ADD PRIMARY KEY (`e_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_event_login`
--
ALTER TABLE `add_event_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `event_table`
--
ALTER TABLE `event_table`
  MODIFY `e_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
