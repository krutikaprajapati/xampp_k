<?php
function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $db = "vgecgac_vgec";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connection to 
 Db failed: %s\n". $conn -> error);
 
 return $conn;
 }
 
function CloseCon($conn)
 {
 $conn -> close();
 }

 function Insert_Record($sql,$conn)
 {
 	try
 	{
 		if ($conn->query($sql) === TRUE) {
	    	//	echo "New record inserted successfully";
	    		return TRUE;
			} else {
	    	//	echo "Error: " . $sql . "<br>" . $conn->error;
	    		return False;
			} 
 	}
 	catch(Exception $e)
 	{
 		echo "$e";
 	}
 			
 }

 function Select_Record($sql,$conn)
 {
 	if($conn->query($sql)==TRUE){
 		$result = $conn->query($sql);
 		return $result;
 	}
 	else
 		echo "error message";
 }
