<?php 

if (!isset($_SESSION['admin'])) {
    echo "<script>window.open('./login.php','_self')</script>";
}
if (isset($_POST['ViewEvent'])) {
    $_SESSION['eventId'] = $_POST['getId'];
    echo "<script>window.open('./ViewEvent.php','_self')</script>";
}
?>