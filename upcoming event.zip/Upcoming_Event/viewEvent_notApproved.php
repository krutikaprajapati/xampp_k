<?php

include('database/include.php');
$eventId = $_SESSION['eventId'];

if (isset($_SESSION['admin'])) {

    $remarks = $_POST['remarks'];

    if ($remarks != null) {

        $updateRemark = "UPDATE `event_table` SET `remarks` = '$remarks' WHERE `e_id` = '$eventId'";
        $runUpdateRemark = mysqli_query($conn, $updateRemark);

        if ($runUpdateRemark) {
            echo "<script>alert('Event Disapproved Successfully.')</script>";
            echo "<script>window.open('./Dashboard.php','_self')</script>";
        } else {
            echo "<script>alert('Disapproved Failed. Try Again!')</script>";
            echo "<script>window.open('./ViewEvent.php','_self')</script>";
        }
    } else {
        echo "<script>alert('For Disapproved remarks must be entered.')</script>";
        echo "<script>window.open('./ViewEvent.php','_self')</script>";
    }
}

?>