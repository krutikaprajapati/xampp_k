<?php

include('database/include.php');
include 'header.php';
include('faculty_check.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <title>Dashboard</title>
</head>
<style>
    table {
        width: 100%;

    }

    table td,
    th {
        /* border: 1px solid #dddddd; */
        text-align: left;
        padding: 8px;
    }

    .detail {
        margin: 1rem;
    }

    .detail span {
        padding: 8px;
    }
</style>

<body>
    <center>
        <div class="detail">
            <p><b>Department Name:</b> <?php echo $_SESSION['d_name']; ?></p>
            <p><b>Coordinator Name:</b> <?php echo $_SESSION['c_name']; ?></p>
            <p><b>Coordinator Email:</b> <?php echo $_SESSION['c_email']; ?></p>
            <a href="./ChangePassword.php">Change Password</a>
            <a href="./logout_f.php"> Logout</a>
        </div>
    </center>

    <center style="margin-top: 1rem;">
        <h2>Reverted</h2>
    </center>
    <table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>Sr No.</th>
                <!-- <th>Year</th> -->
                <th>Date </th>
                <th>Department Name</th>
                <th>Event Name</th>
                <th>Coordinator Name</th>
                <th>Remarks</th>
                <th>Edit</th>
            </tr>
        </thead>
        <?php
        $i = 1;
        $sql = "SELECT * FROM `event_table` ORDER BY `e_id` DESC ";
        $result = Select_Record($sql, $conn);
        if ($result->num_rows > 0) {
            foreach ($result as $k) {
                $id = $k['e_id'];
                $rek = $k['remarks'];
        ?>
                <?php if ($rek != NULL) {
                ?>
                    <tbody>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><?php echo $k['e_start_date']; ?></td>
                            <td><?php echo $k['Dept_name']; ?></td>
                            <td><?php echo $k['e_title']; ?></td>
                            <td><?php echo $k['e_coordinator']; ?></td>
                            <td> <?php echo $k['remarks']; ?> </td>
                            <td>
                                <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                                    <center>
                                        <div class="col-md-6 text-center">
                                            <input type="hidden" name="getId" value="<?php echo $k['e_id'] ?>">
                                            <input type="submit" name="editEvent" class="btn btn-primary py-2" value="Edit" />
                                        </div>
                                    </center>
                                </form>
                            </td>

                        </tr>
                    </tbody>
                <?php
                }
                ?>
        <?php
                $i++;
            }
        }
        ?>
    </table>




    <center style="margin-top: 1rem;">
        <h2>Not Approved</h2>
    </center>
    <table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>Sr No.</th>
                <!-- <th>Year</th> -->
                <th>Date </th>
                <th>Department Name</th>
                <th>Event Name</th>
                <th>Coordinator Name</th>
                <th>Edit</th>
                <th>View</th>
            </tr>
        </thead>
        <?php
        $i = 1;
        $sql = "SELECT * FROM `event_table` ORDER BY `e_id` DESC ";
        $result = Select_Record($sql, $conn);
        if ($result->num_rows > 0) {
            foreach ($result as $k) {
                $id = $k['e_id'];
                $rek = $k['remarks'];
                $flag = $k['flag'];
        ?>
                <?php if ($rek == NULL && $flag == 0) {
                ?>
                    <tbody>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><?php echo $k['e_start_date']; ?></td>
                            <td><?php echo $k['Dept_name']; ?></td>
                            <td><?php echo $k['e_title']; ?></td>
                            <td><?php echo $k['e_coordinator']; ?></td>
                            <td>
                                <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                                    <center>
                                        <div class="col-md-6 text-center">
                                            <input type="hidden" name="getId" value="<?php echo $k['e_id'] ?>">
                                            <input type="submit" name="editEvent" class="btn btn-primary py-2" value="Edit" />
                                        </div>
                                    </center>
                                </form>
                            </td>
                            <td>
                                <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                                    <center>
                                        <div class="col-md-6 text-center">
                                            <input type="hidden" name="getId" value="<?php echo $k['e_id'] ?>">
                                            <input type="submit" name="ViewEvent" class="btn btn-primary py-2" value="View" />
                                        </div>
                                    </center>
                                </form>
                            </td>
                            <!-- <td><input type="submit" name="Edit" value="Edit"></td> -->
                            <!-- <td><input type="submit" name="Delete" value="Delete"></td> -->

                        </tr>
                    </tbody>
                <?php
                } ?>
        <?php
                $i++;
            }
        }
        ?>
    </table>



    <center style="margin-top: 1rem;">
        <h2> Approved</h2>
    </center>
    <table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>Sr No.</th>
                <!-- <th>Year</th> -->
                <th>Date </th>
                <th>Department Name</th>
                <th>Event Name</th>
                <th>Coordinator Name</th>
                <th>View</th>
            </tr>
        </thead>
        <?php
        $i = 1;
        $sql = "SELECT * FROM `event_table` ORDER BY `e_id` DESC ";
        $result = Select_Record($sql, $conn);
        if ($result->num_rows > 0) {
            foreach ($result as $k) {
                $id = $k['e_id'];
                $rek = $k['remarks'];
                $flag = $k['flag'];
        ?>

                <?php if ($rek == NULL && $flag == 1) {
                ?>
                    <tbody>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><?php echo $k['e_start_date']; ?></td>
                            <td><?php echo $k['Dept_name']; ?></td>
                            <td><?php echo $k['e_title']; ?></td>
                            <td><?php echo $k['e_coordinator']; ?></td>
                            <td>
                                <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                                    <center>
                                        <div class="col-md-6 text-center">

                                            <input type="hidden" name="getId" value="<?php echo $k['e_id'] ?>">
                                            <input type="submit" name="ViewEvent" class="btn btn-primary py-2" value="View" />
                                        </div>
                                    </center>
                                </form>
                            </td>
                            <!-- <td><input type="submit" name="Edit" value="Edit"></td> -->
                            <!-- <td><input type="submit" name="Delete" value="Delete"></td> -->

                        </tr>
                    </tbody>
                <?php
                }
                ?>
        <?php
                $i++;
            }
        }
        ?>
    </table>


    <center>
        <form method="post" action="./AddEvent.php">
            <input class="btn" type="submit" style="margin-bottom: 70px; margin-top: 10px" name="insert" value="Insert">
        </form>
    </center>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/select/1.3.4/js/dataTables.select.min.js"></script>
    <script src="js/table.js"></script>
</body>

</html>
<?php
include 'footer.php'
?>