<?php

include('database/include.php');
$eventId = $_SESSION['eventId'];

if (isset($_SESSION['admin'])) {
    $updateQuery = "UPDATE `event_table` SET `flag` = '1' WHERE `e_id` = '$eventId'";
    $runUpdateQuery = mysqli_query($conn, $updateQuery);
    // $row = mysqli_fetch_array($runUpdateQuery);

    if ($runUpdateQuery) {
        echo "<script>alert('Event Approved Successfully.')</script>";
        echo "<script>window.open('./Dashboard.php','_self')</script>";
    } else {
        echo "<script>alert('Approved Failed. Try Again!')</script>";
        echo "<script>window.open('./ViewEvent.php','_self')</script>";
    }
}

?>