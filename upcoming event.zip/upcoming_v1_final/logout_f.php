<?php
include "database/include.php";
if(isset($_SESSION['type']))
{
unset($_SESSION['type']);
$_SESSION['message']="<div class='chip green white-text'>successfully Logged Out.</div>";
header("Location: login.php");
}
else
{
  $_SESSION['message']="<div class='chip red black-text'>Login To Continue</div>";
  header("Location: login.php");
}
?>