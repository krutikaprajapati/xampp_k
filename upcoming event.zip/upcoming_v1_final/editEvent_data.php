<?php

    if (!isset($_SESSION['type'])) {
        echo "<script>window.open('./login_stud_delete.php','_self')</script>";
    }

    $sql1 = "SELECT * FROM `event_table`";
    $ress = Select_Record($sql1, $conn);


    $eventId = $_SESSION['eventId'];
    $searchQuery = "SELECT * FROM `event_table` WHERE `e_id` = '$eventId'";
    $runsearchQuery = mysqli_query($conn, $searchQuery);
    $row = mysqli_fetch_array($runsearchQuery);
    $e_title = $row['e_title'];
    $dept_name = $row['Dept_name'];
    $e_dpoints = $row['e_dpoints'];
    $e_start_date = $row['e_start_date'];
    $e_end_date = $row['e_end_date'];
    $e_time = $row['e_time'];
    $e_venue = $row['e_venue'];
    $e_coordinator = $row['e_coordinator'];
    $e_contact = $row['e_contact'];
    $e_register = $row['e_register'];
    $e_dpoints = ($row['e_dpoints']);
    $e_additional = $row['e_additional'];
    $e_pdf = $row['e_pdf'];
    $_SESSION['old_pdf'] = $e_pdf;
?>