<?php

include('database/include.php');
include 'header.php';
include('media_check.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <title>Dashboard</title>
</head>
<style>
    table {
        width: 100%;

    }

    table td,
    th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    table tr:nth-child(even) {
        /* background-color: #dddddd; */
    }

    .detail {
        margin: 1rem;
    }

    .detail span {
        padding: 8px;
    }
</style>

<body>

    <center style="margin-top: 1rem;margin-bottom: 0.5rem;">
        <a href="./logout_a.php"> Logout</a>

        <h2>Not Approved</h2>
    </center>
    <table style="margin-bottom: 1rem;width:100%" id="example" class="table table-striped">
        <tr>
            <th>Sr No.</th>
            <!-- <th>Year</th> -->
            <th>Date </th>
            <th>Department Name</th>
            <th>Event Name</th>
            <th>Coordinator Name</th>
            <th>View</th>
        </tr>
        <?php
        $i = 1;
        $sql = "SELECT * FROM `event_table` ORDER BY `e_id` DESC ";
        $result = Select_Record($sql, $conn);
        if ($result) {
            foreach ($result as $k) {
                $id = $k['e_id'];
                $rek = $k['remarks'];
                $flag = $k['flag'];
        ?>
                <?php if ($rek == NULL && $flag == 0) {
                ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $k['e_start_date']; ?></td>
                        <td><?php echo $k['Dept_name']; ?></td>
                        <td><?php echo $k['e_title']; ?></td>
                        <td><?php echo $k['e_coordinator']; ?></td>
                        <td>
                            <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                                <center>
                                    <div class="col-md-6 my-3 text-center">
                                        <input type="hidden" name="getId" value="<?php echo $k['e_id']; ?>">
                                        <input type="submit" name="ViewEvent" class="btn btn-primary py-2" value="View" />
                                    </div>
                                </center>
                            </form>
                        </td>

                    </tr>
                <?php
                }
                ?>
        <?php
                $i++;
            }
        }
        ?>
    </table>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/select/1.3.4/js/dataTables.select.min.js"></script>
    <script src="js/table.js"></script>
</body>

</html>
<?php
include 'footer.php'
?>