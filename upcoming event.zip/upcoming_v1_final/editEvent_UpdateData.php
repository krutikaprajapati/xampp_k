<?php

    include('database/include.php');
    $eventId = $_SESSION['eventId'];
    $old_pdf = $_SESSION['old_pdf'];

    $uploadsDir2 = "./uploads/EventFiles/";
    $finalname = null;
    $e_title = $_POST['e_title'];
    $dept_name = $_POST['Dept_Name'];
    $e_coordinator = $_POST['coordinator_Name'];
    $e_date = date('Y-m-d', strtotime($_POST['e_date']));
    $e_end_date = date('Y-m-d', strtotime($_POST['e_end_date']));
    $e_time = $_POST['e_time'];
    $e_venue = $_POST['e_venue'];
    $e_contact_details = $_POST['e_contact_details'];
    $e_registration_link = $_POST['e_registration_link'];
    $a_points = $_POST['a_points'];
    $o_points = $_POST['o_points'];


    if (empty($_FILES["attachment"]["name"])) {
        $UploadPdfName = $old_pdf;
    } else {
        $pdfname = $_FILES['attachment']['name'];
        $tmp_name = $_FILES['attachment']['tmp_name'];
        $targetFilePath2  = $uploadsDir2 . $pdfname;
        $fileType2  = strtolower(pathinfo($targetFilePath2, PATHINFO_EXTENSION));
        $path2 = "./uploads/EventFiles/" . time() . "_" . basename($pdfname);
        $UploadPdfName = "./uploads/EventFiles/" . time() . "_" . basename($pdfname);
    }

    move_uploaded_file($_FILES["attachment"]["tmp_name"], $path2);
    $updateEvent = "UPDATE `event_table` SET `e_title`= '$e_title', `Dept_name`= '$dept_name', `e_dpoints` = '$a_points', `e_start_date` = '$e_date', `e_end_date` = '$e_end_date', `e_time` = '$e_time', `e_venue` = '$e_venue', `e_coordinator` = '$e_coordinator', `e_contact` = '$e_contact_details', `e_register` = '$e_registration_link', `e_additional` = '$o_points', `e_pdf` = '$UploadPdfName', `flag` = '0', `remarks` = null WHERE `e_id` = '$eventId'";
    $updateEventRun = mysqli_query($conn, $updateEvent);

    if ($updateEventRun) {
        echo "<script>alert('Record Successfully Updated !!!')</script>";
        echo "<script>window.open('./faculty_dashboard.php','_self')</script>";
        unset($_POST['update_data']);
    } else {
        echo "<script>alert('Error In Updating.')</script>";
        exit();
    }

?>