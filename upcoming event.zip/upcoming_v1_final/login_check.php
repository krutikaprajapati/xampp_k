<?php
include('database/include.php');
    $uname=$_POST['username'];
    $pass = $_POST['password'];

    $searchUser = "SELECT * FROM `add_event_login` WHERE `username` = '$uname'";
    $searchUserResult = Select_Record($searchUser, $conn);

    if($searchUserResult->num_rows > 0) {
        $done = "SELECT * FROM `add_event_login` WHERE `username` = '$uname' AND `password` = '$pass'";
        $doneSearch = Select_Record($done,$conn);
        $result = mysqli_fetch_array($doneSearch);

        if($doneSearch->num_rows > 0) {
            if($result['authority'] == 1) {
                $_SESSION['admin'] = $uname;
                echo "<script>alert('Successfully Login Of Admin !!')</script>";
                echo "<script>window.open('./Dashboard.php','_self')</script>";
            } else {
                $_SESSION['type'] = "Faculty";
                $_SESSION['c_name'] = $result['c_name'];
                $_SESSION['c_email'] = $result['c_email'];
                $_SESSION['d_name'] = $result['d_name'];
    
                echo "<script>alert('Successfully Login Of Faculty !!')</script>";
                echo "<script>window.open('./faculty_dashboard.php','_self')</script>";
            }
        } else {
            echo "<script>alert('Password is not coorect !!')</script>";
            echo "<script>window.open('./login.php','_self')</script>";
        }
    } else {
        echo "<script>alert('User Does not Exist !!')</script>";
        echo "<script>window.open('./login.php','_self')</script>";
    }
?>