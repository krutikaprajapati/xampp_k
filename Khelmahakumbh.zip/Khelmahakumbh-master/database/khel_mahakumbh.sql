-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2023 at 06:05 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `khel_mahakumbh`
--

-- --------------------------------------------------------

--
-- Table structure for table `coach_registration`
--

CREATE TABLE `coach_registration` (
  `coach_id` int(15) NOT NULL,
  `game_id` int(15) NOT NULL,
  `team_id` int(15) NOT NULL,
  `f_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `m_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `l_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `email` varchar(25) COLLATE utf8_bin NOT NULL,
  `contact` bigint(10) NOT NULL,
  `dob` date NOT NULL,
  `category` varchar(20) COLLATE utf8_bin NOT NULL,
  `gender` varchar(10) COLLATE utf8_bin NOT NULL,
  `aadhar_no` bigint(12) NOT NULL,
  `address` varchar(100) COLLATE utf8_bin NOT NULL,
  `city_village` varchar(20) COLLATE utf8_bin NOT NULL,
  `district_id` int(15) NOT NULL,
  `taluka_id` int(15) NOT NULL,
  `pincode` int(6) NOT NULL,
  `height` int(3) NOT NULL,
  `weight` int(3) NOT NULL,
  `nationality` varchar(25) COLLATE utf8_bin NOT NULL,
  `qualification` varchar(30) COLLATE utf8_bin NOT NULL,
  `game_exp` int(2) NOT NULL,
  `blood_group` varchar(5) COLLATE utf8_bin NOT NULL,
  `physical_disabled` tinyint(1) NOT NULL,
  `pd_certi` longtext COLLATE utf8_bin NOT NULL,
  `photo` longtext COLLATE utf8_bin NOT NULL,
  `coach_certi` longtext COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `coach_registration`
--

INSERT INTO `coach_registration` (`coach_id`, `game_id`, `team_id`, `f_name`, `m_name`, `l_name`, `email`, `contact`, `dob`, `category`, `gender`, `aadhar_no`, `address`, `city_village`, `district_id`, `taluka_id`, `pincode`, `height`, `weight`, `nationality`, `qualification`, `game_exp`, `blood_group`, `physical_disabled`, `pd_certi`, `photo`, `coach_certi`) VALUES
(1, 1, 1, 'Kapil Dev', 'Ram Lal', 'Nikhanj', 'kapildev6@gmail.com', 8745782596, '1969-01-06', 'Open', 'Male', 0, '39, Sundar Nagar, New Delhi.', 'Sundar Nagar', 0, 0, 110093, 183, 80, '', '', 0, '', 0, '', '', ''),
(2, 2, 2, 'Pullela', 'Subhash', 'Gopichand', 'gopichand4@gmail.com', 9425458765, '1973-11-16', 'Open', 'Male', 0, '23, Nagandla, Prakasam, Andhra Pradesh', 'Nagandla', 0, 0, 523190, 183, 64, '', '', 0, '', 0, '', '', ''),
(3, 1, 1, 'heta', 'vinaykumar', 'Patel', 'ravi@gmail.com', 9879898990, '2022-10-27', 'SC', 'Female', 568687797646, 'abd', 'Kanz', 2, 1, 388000, 180, 49, 'Indian', 'DIPLOMA', 5, 'B-', 1, '../pdf/Industrial Visit_Janvi(210170116515).pdf', '../user/Janvi Gupta.jpg', '../pdf/Industrial Visit_Janvi(210170116515).pdf'),
(4, 1, 1, 'rthfgnfgn', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 8799989676, '2022-10-18', 'OBC', 'Male', 568679678798, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 170, 56, 'indian', 'GRADUATE', 3, 'A-', 1, '../pdf/Industrial Visit_Janvi(210170116515).pdf', '../user/Janvi Gupta.jpg', '../pdf/Industrial Visit_Janvi(210170116515).pdf'),
(5, 1, 1, 'rthfgnfgn', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 8799989676, '2022-10-18', 'OBC', 'Male', 568679678798, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 170, 56, 'indian', 'GRADUATE', 3, 'A-', 1, '../pdf/Industrial Visit_Janvi(210170116515).pdf', '../user/Janvi Gupta.jpg', '../pdf/Industrial Visit_Janvi(210170116515).pdf'),
(6, 1, 1, 'rthfgnfgn', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 8799989676, '2022-10-18', 'OBC', 'Male', 568679678798, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 170, 56, 'indian', 'GRADUATE', 3, 'A-', 1, '../pdf/Industrial Visit_Janvi(210170116515).pdf', '../user/Janvi Gupta.jpg', '../pdf/Industrial Visit_Janvi(210170116515).pdf'),
(7, 1, 1, 'rthfgnfgn', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 8799989676, '2022-10-18', 'OBC', 'Male', 568679678798, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 170, 56, 'indian', 'GRADUATE', 3, 'B+', 1, '../pdf/Industrial Visit_Janvi(210170116515).pdf', '../user/Janvi Gupta.jpg', '../pdf/Industrial Visit_Janvi(210170116515).pdf'),
(8, 1, 1, 'rthfgnfgn', 'sanjaykumar', 'gupta', 'janvisgupta77@gmail.com', 8799989676, '2022-10-18', 'OBC', 'Male', 568679678798, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 170, 56, 'indian', 'GRADUATE', 3, 'B+', 1, '../pdf/Industrial Visit_Janvi(210170116515).pdf', '../user/Janvi Gupta.jpg', '../pdf/Industrial Visit_Janvi(210170116515).pdf'),
(9, 1, 1, 'Sanchi', 'sanjaykumar', 'gupta', 'janvisgupta77@gmail.com', 8799989676, '2022-10-10', 'SC', 'Female', 568679678798, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 170, 56, 'indian', 'DIPLOMA', 3, 'AB+', 1, '../pdf/Industrial Visit_Janvi(210170116515).pdf', '../user/Janvi Gupta.jpg', '../pdf/Industrial Visit_Janvi(210170116515).pdf'),
(10, 1, 1, 'Sanchi', 'sanjaykumar', 'gupta', 'janvisgupta77@gmail.com', 8799989676, '2022-10-10', 'SC', 'Female', 568679678798, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 170, 56, 'indian', 'DIPLOMA', 3, 'AB+', 1, '../pdf/Industrial Visit_Janvi(210170116515).pdf', '../user/Janvi Gupta.jpg', '../pdf/Industrial Visit_Janvi(210170116515).pdf'),
(11, 1, 1, 'Sanchi', 'sanjaykumar', 'gupta', 'janvisgupta77@gmail.com', 8799989676, '2022-10-10', 'SC', 'Female', 568679678798, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 170, 56, 'indian', 'DIPLOMA', 3, 'AB+', 1, '../pdf/Industrial Visit_Janvi(210170116515).pdf', '../user/Janvi Gupta.jpg', '../pdf/Industrial Visit_Janvi(210170116515).pdf'),
(12, 1, 1, 'Sanchi', 'sanjaykumar', 'gupta', 'janvisgupta77@gmail.com', 8799989676, '2022-10-10', 'SC', 'Female', 568679678798, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 170, 56, 'indian', 'DIPLOMA', 3, 'AB+', 1, '../pdf/Industrial Visit_Janvi(210170116515).pdf', '../user/Janvi Gupta.jpg', '../pdf/Industrial Visit_Janvi(210170116515).pdf'),
(13, 1, 1, 'rahul', 'sanjaykumar', 'gupta', 'janvisgupta77@gmail.com', 8799989676, '2014-03-18', 'SC', 'Male', 568679678798, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 170, 67, 'indian', 'POST GRADUATE', 5, 'O+', 1, '../pdf/Industrial Visit_Janvi(210170116515).pdf', '../user/user1.jpg', '../pdf/Industrial Visit_Janvi(210170116515).pdf'),
(14, 1, 1, 'rahul', 'sanjaykumar', 'gupta', 'janvisgupta77@gmail.com', 8799989676, '2014-03-18', 'SC', 'Male', 568679678798, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 170, 67, 'indian', 'POST GRADUATE', 5, 'O+', 1, '../pdf/Industrial Visit_Janvi(210170116515).pdf', '../user/user1.jpg', '../pdf/Industrial Visit_Janvi(210170116515).pdf'),
(15, 1, 1, 'janvi', 'sanjaykumar', 'gupta', 'janvisgupta77@gmail.com', 8799989676, '2022-10-11', 'SC', 'Female', 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 170, 60, 'indian', 'HSC', 7, 'A+', 1, '../pdf/Industrial Visit_Janvi(210170116515).pdf', '../user/user1.jpg', '../pdf/Industrial Visit_Janvi(210170116515).pdf'),
(16, 1, 1, 'rthfgnfgn', 'sanjaykumar', 'gupta', 'janvisgupta77@gmail.com', 8799989676, '2014-06-14', 'SC', 'Male', 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 170, 56, 'indian', 'GRADUATE', 7, 'A-', 1, 'pdf/Industrial Visit_Janvi(210170116515).pdf', 'user/Janvi Gupta.jpg', 'pdf/Industrial Visit_Janvi(210170116515).pdf'),
(17, 1, 1, 'Mina', 'navinbhai', 'Patel', 'janvisgupta77@gmail.com', 9879898990, '2021-11-29', 'SC', 'Female', 986768745767, 'abd', 'Kanz', 2, 1, 388000, 150, 45, 'Indian', 'DIPLOMA', 5, 'O+', 1, 'pdf/Screenshot (5).png', 'user/Screenshot (3).png', 'pdf/Screenshot (5).png'),
(18, 1, 1, 'Mina', 'navinbhai', 'Patel', 'janvisgupta77@gmail.com', 9879898990, '2021-11-29', 'SC', 'Female', 986768745767, 'abd', 'Kanz', 2, 1, 388000, 150, 45, 'Indian', 'DIPLOMA', 5, 'O+', 1, 'pdf/Screenshot (5).png', 'user/Screenshot (3).png', 'pdf/Screenshot (5).png'),
(19, 1, 1, 'Mina', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 9879898990, '2021-11-30', 'SC', 'Female', 568687797646, 'abd', 'Kadi', 2, 1, 380005, 180, 40, 'Indian', 'DIPLOMA', 5, 'O+', 1, 'pdf/Screenshot (5).png', 'user/Screenshot (3).png', 'pdf/Screenshot (5).png'),
(20, 1, 1, 'Mina', 'navinbhai', 'Patel', 'janvigupta1507@gmail.com', 9879898990, '2019-11-29', 'ST', 'Male', 796697797646, 'DSFMSDM', 'Kadi', 2, 1, 380005, 180, 40, 'Indian', 'DIPLOMA', 5, 'A+', 1, 'pdf/Industrial Visit_Janvi(210170116515).pdf', 'user/Janvi Gupta.jpg', 'pdf/Industrial Visit_Janvi(210170116515).pdf'),
(21, 1, 1, 'Mina', 'navinbhai', 'Patel', 'janvigupta1507@gmail.com', 9879898990, '2019-11-29', 'ST', 'Male', 796697797646, 'DSFMSDM', 'Kadi', 2, 1, 380005, 180, 40, 'Indian', 'DIPLOMA', 5, 'A+', 1, 'pdf/Industrial Visit_Janvi(210170116515).pdf', 'user/Janvi Gupta.jpg', 'pdf/Industrial Visit_Janvi(210170116515).pdf'),
(22, 1, 1, 'Mina', 'navinbhai', 'Patel', 'janvigupta1507@gmail.com', 9879898990, '2019-11-29', 'ST', 'Male', 796697797646, 'DSFMSDM', 'Kadi', 2, 1, 380005, 180, 40, 'Indian', 'DIPLOMA', 5, 'A+', 1, 'pdf/Industrial Visit_Janvi(210170116515).pdf', 'user/Janvi Gupta.jpg', 'pdf/Industrial Visit_Janvi(210170116515).pdf'),
(23, 1, 1, 'Mina', 'navinbhai', 'Patel', 'janvigupta1507@gmail.com', 9879898990, '2019-11-29', 'ST', 'Male', 796697797646, 'DSFMSDM', 'Kadi', 2, 1, 380005, 180, 40, 'Indian', 'DIPLOMA', 5, 'A+', 1, 'pdf/Industrial Visit_Janvi(210170116515).pdf', 'user/Janvi Gupta.jpg', 'pdf/Industrial Visit_Janvi(210170116515).pdf'),
(24, 1, 1, 'Mina', 'manubhai ', 'pajapati', 'janvigupta1507@gmail.com', 9879898990, '2022-12-29', 'Open', 'Male', 986768745767, 'DSFMSDM', 'Kadi', 2, 1, 380005, 130, 40, 'Indian', 'DIPLOMA', 5, 'O+', 1, 'pdf/Industrial Visit_Janvi(210170116515).pdf', 'user/Janvi Gupta.jpg', 'pdf/Industrial Visit_Janvi(210170116515).pdf'),
(25, 1, 1, 'Mina', 'manubhai ', 'pajapati', 'janvigupta1507@gmail.com', 9879898990, '2022-12-29', 'Open', 'Male', 986768745767, 'DSFMSDM', 'Kadi', 2, 1, 380005, 130, 40, 'Indian', 'DIPLOMA', 5, 'O+', 1, 'pdf/Industrial Visit_Janvi(210170116515).pdf', 'user/Janvi Gupta.jpg', 'pdf/Industrial Visit_Janvi(210170116515).pdf'),
(26, 1, 1, 'Mina', 'manubhai ', 'pajapati', 'janvigupta1507@gmail.com', 9879898990, '2022-12-29', 'Open', 'Male', 986768745767, 'DSFMSDM', 'Kadi', 2, 1, 380005, 130, 40, 'Indian', 'DIPLOMA', 5, 'O+', 1, 'pdf/Industrial Visit_Janvi(210170116515).pdf', 'user/Janvi Gupta.jpg', 'pdf/Industrial Visit_Janvi(210170116515).pdf'),
(27, 1, 1, 'Hiral', 'navinbhai', 'Patel', 'janvisgupta77@gmail.com', 9879898990, '2011-04-27', 'Open', 'Female', 986768745767, 'abd', 'Kadi', 2, 1, 382139, 130, 57, 'Indian', 'GRADUATE', 5, 'O+', 1, 'pdf/Industrial Visit_Janvi(210170116515).pdf', 'user/Janvi Gupta.jpg', 'pdf/Industrial Visit_Janvi(210170116515).pdf'),
(28, 1, 1, 'Mina', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 9879898990, '2022-12-31', 'Open', 'Female', 796697797646, 'abd', 'Kadi', 2, 1, 388000, 180, 40, 'Indian', 'HSC', 5, 'A+', 1, 'pdf/Screenshot (3).png', 'user/Screenshot (6).png', 'pdf/Screenshot (3).png'),
(29, 1, 1, 'Mina', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 9879898990, '2022-12-31', 'Open', 'Female', 796697797646, 'abd', 'Kadi', 2, 1, 388000, 180, 40, 'Indian', 'HSC', 5, 'A+', 1, 'pdf/Screenshot (3).png', 'user/Screenshot (6).png', 'pdf/Screenshot (3).png'),
(30, 1, 1, 'Mina', 'navinbhai', 'Patel', 'janvisgupta77@gmail.com', 9879898990, '2022-12-31', 'Open', 'Female', 796697797646, 'abd', 'Kadi', 2, 1, 380005, 180, 40, 'Indian', 'HSC', -1, 'A+', 1, 'pdf/Screenshot (4).png', 'user/Screenshot (2).png', 'pdf/Screenshot (4).png'),
(31, 1, 1, 'Mina', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 9879898990, '2022-12-31', 'Open', 'Female', 796697797646, 'abd', 'Kadi', 2, 1, 388000, 180, 40, 'Indian', 'HSC', 5, 'A+', 1, 'pdf/Screenshot (3).png', 'user/Screenshot (6).png', 'pdf/Screenshot (3).png'),
(32, 1, 1, 'Aayushi', 'M', 'Prajapati', 'aayushiprajapati73@gmail.', 9874563210, '2022-11-04', 'OBC', 'Female', 122256568989, 'Ahmedabad', 'Ahmedabad', 2, 1, 380005, 180, 45, 'Indian', 'GRADUATE', 3, 'A-', 1, 'pdf/WD_5 (1).pdf', 'user/download.png', 'pdf/WD_5 (1).pdf');

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE `district` (
  `district_id` int(15) NOT NULL,
  `district_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`district_id`, `district_name`) VALUES
(2, 'Surat'),
(11, 'Ahmedabad');

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

CREATE TABLE `game` (
  `game_id` int(15) NOT NULL,
  `game_name` varchar(50) NOT NULL,
  `game_player` varchar(50) NOT NULL,
  `game_duration` datetime NOT NULL,
  `game_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game`
--

INSERT INTO `game` (`game_id`, `game_name`, `game_player`, `game_duration`, `game_type`) VALUES
(1, 'chess', '2', '2022-09-05 03:00:00', 'single'),
(2, 'kho-kho', '12', '2022-09-30 00:45:00', 'team'),
(3, 'badminton', '2', '2022-09-30 00:50:00', 'double');

-- --------------------------------------------------------

--
-- Table structure for table `grant`
--

CREATE TABLE `grant` (
  `grant_id` int(15) NOT NULL,
  `grant_name` varchar(25) NOT NULL,
  `grant_type` varchar(25) NOT NULL,
  `grant_amount` bigint(10) NOT NULL,
  `grant_status` int(10) NOT NULL,
  `grant_level` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grant`
--

INSERT INTO `grant` (`grant_id`, `grant_name`, `grant_type`, `grant_amount`, `grant_status`, `grant_level`) VALUES
(1, 'student ssholarship', 'game', 30000, 1, 'institute');

-- --------------------------------------------------------

--
-- Table structure for table `institutes`
--

CREATE TABLE `institutes` (
  `Institue_ID` int(11) NOT NULL,
  `Institute_name` varchar(50) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `City` varchar(20) NOT NULL,
  `District` varchar(20) NOT NULL,
  `Taluka` varchar(20) NOT NULL,
  `Pincode` int(6) NOT NULL,
  `Principal_name` varchar(30) NOT NULL,
  `Principal_contactno` bigint(10) NOT NULL,
  `PT_name` varchar(30) NOT NULL,
  `PT_contactno` bigint(10) NOT NULL,
  `Type_of_registration` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `institutes`
--

INSERT INTO `institutes` (`Institue_ID`, `Institute_name`, `Email`, `Address`, `City`, `District`, `Taluka`, `Pincode`, `Principal_name`, `Principal_contactno`, `PT_name`, `PT_contactno`, `Type_of_registration`) VALUES
(2, '', 'janvi1@gmail.com', '', 'rampura', 'abd', 'detroj', 386778, 'janvi sanjaykumar gu', 2147483647, 'dinesh mehta', 2147483647, ''),
(3, '', 'janvi1@gmail.com', '', 'rampura', 'abd', 'detroj', 386778, 'janvi sanjaykumar gu', 2147483647, 'dinesh mehta', 2147483647, ''),
(4, '', 'janvi1@gmail.com', '', 'rampura', 'abd', 'detroj', 386778, 'janvi sanjaykumar gu', 2147483647, 'dinesh mehta', 2147483647, ''),
(5, '', 'janvi1@gmail.com', '', 'rampura', 'abd', 'detroj', 386778, 'janvi sanjaykumar gu', 2147483647, 'dinesh mehta', 2147483647, 'school'),
(6, '', 'janvi1@gmail.com', '', 'rampura', 'abd', 'detroj', 386778, 'janvi sanjaykumar gu', 2147483647, 'dinesh mehta', 2147483647, 'school'),
(7, 'school', 'anfshfs@mgialkdsm.com', 'rampura', 'dholka', 'ahmedabad', 'absddg', 380900, 'abc', 9609569789, 'mahesh', 9809798788, 'college'),
(8, 'college', 'janvi1@gmail.com', 'ahmedabad', 'rampura', 'ahmedabad', 'detroj', 386778, 'janvi sanjaykumar gu', 9609569789, 'dinesh mehta', 7893457957, 'college'),
(9, 'college', 'janvi1@gmail.com', 'ahmedabad', 'rampura', 'ahmedabad', 'detroj', 386778, 'janvi sanjaykumar gu', 7877954677, 'dinesh mehta', 7987980987, 'college'),
(10, 'school', 'janvi@gmail.com', 'DSFMSDM', 'RAMPURA', 'ABD', 'TALUKA', 380959, 'kdkdskdsjk', 9887899077, 'DSMKLDSGJKL', 8795489887, 'school'),
(11, 'school', 'janvi@gmail.com', 'DSFMSDM', 'RAMPURA', 'ABD', 'TALUKA', 380959, 'kdkdskdsjk', 9887899077, 'DSMKLDSGJKL', 8795489887, 'school'),
(12, 'school', 'janvi@gmail.com', 'DSFMSDM', 'RAMPURA', 'ABD', 'TALUKA', 380959, 'kdkdskdsjk', 9887899077, 'DSMKLDSGJKL', 8795489887, 'school');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role1` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `role1`) VALUES
(1, 'hiral@gmail.com', '9ZUWH2Dh', ''),
(2, 'hiral@gmail.com', '9ZUWH2Dh', ''),
(3, 'hiral@gmail.com', '9ZUWH2Dh', ''),
(4, 'hiral@gmail.com', '9ZUWH2Dh', ''),
(5, 'hiral@gmail.com', '9ZUWH2Dh', ''),
(6, 'hiral@gmail.com', '9ZUWH2Dh', ''),
(7, 'hiral@gmail.com', '9ZUWH2Dh', ''),
(8, 'hiral@gmail.com', '9ZUWH2Dh', ''),
(9, 'hiral@gmail.com', '9ZUWH2Dh', ''),
(10, 'hiral@gmail.com', '9ZUWH2Dh', ''),
(11, 'hiral@gmail.com', '9ZUWH2Dh', ''),
(12, 'hiral@gmail.com', '9ZUWH2Dh', ''),
(13, 'hiral@gmail.com', 'ObKmx5jT', ''),
(14, 'hiral@gmail.com', 'ObKmx5jT', ''),
(15, 'hiral@gmail.com', '765858', ''),
(16, 'hiral@gmail.com', '765858', ''),
(17, 'hiral@gmail.com', '557567', ''),
(18, 'hiral@gmail.com', '557567', ''),
(19, '210170116515', 'jhhgk', ''),
(20, '210170116515', 'jhhgk', ''),
(21, '210170116515', 'tdhfh', ''),
(22, '210170116515', 'tdhfh', ''),
(23, '210170116515', 'ygfvnv', ''),
(24, '210170116515', 'ygfvnv', ''),
(25, 'janvi@gmail.com', '6zBeD1tH', ''),
(26, 'janvi@gmail.com', '6zBeD1tH', ''),
(27, 'janvi@gmail.com', '6zBeD1tH', ''),
(28, 'janvi@gmail.com', '6zBeD1tH', ''),
(29, 'janvi@gmail.com', '6zBeD1tH', ''),
(30, 'janvi@gmail.com', 'vmmbhmb', ''),
(31, 'janvi@gmail.co', 'gvjmhm', ''),
(32, 'janvi@gmail.com', 'dffhfgj', ''),
(33, 'mina124@gmail.com', '', ''),
(34, 'mina124@gmail.com', 'oZ6Lec8q', ''),
(35, 'dfgts23@gmail.com', 'lmCDurRi', ''),
(36, 'dfgts23@gmail.com', '7adVoKFv', ''),
(37, 'janvisgupta77@gmail.com', 'LDSHpT59', ''),
(38, 'janvisgupta77@gmail.com', 'iamKMLXj', ''),
(39, 'janvi1@gmail.com', '', ''),
(40, 'janvi1@gmail.com', '', ''),
(41, 'janvi1@gmail.com', '', ''),
(42, 'janvi1@gmail.com', '', ''),
(43, 'janvisgupta77@gmail.com', '', ''),
(44, 'janvisgupta77@gmail.com', '', ''),
(45, 'janvisgupta77@gmail.com', 'Zah457kj', 'coach'),
(46, 'janvisgupta77@gmail.com', '', ''),
(47, 'janvisgupta77@gmail.com', 'ZDPsdG6r', ''),
(48, 'janvisgupta77@gmail.com', 'ZDPsdG6r', ''),
(49, 'janvi1@gmail.com', 'twlcybIk', ''),
(50, 'janvisgupta77@gmail.com', '2FADdT4l', ''),
(51, 'janvisgupta77@gmail.com', '2FADdT4l', ''),
(52, 'janvisgupta77@gmail.com', 'S2sI3U4h', ''),
(53, 'janvisgupta77@gmail.com', 'S2sI3U4h', ''),
(54, 'janvisgupta77@gmail.com', 'qhjbyQdT', ''),
(55, 'janvisgupta77@gmail.com', '', ''),
(56, 'janvisgupta77@gmail.com', 'crjiN5fv', 'coach'),
(57, 'janvisgupta77@gmail.com', 'Lm6tVS8M', 'coach'),
(58, 'janvisgupta77@gmail.com', 'KlqTVkcn', 'player'),
(59, 'janvigupta1507@gmail.com', 'vRzxAXiO', 'player'),
(60, 'janvigupta1507@gmail.com', 'X5tHeyTV', 'player'),
(61, 'janvigupta1507@gmail.com', '9KHIG4et', 'player'),
(62, 'paayushi908@gmail.com', 'JZq2CsS8', 'player'),
(63, 'janvisgupta77@gmail.com', 'm9StOAsr', 'player'),
(64, 'janvisgupta77@gmail.com', 'SvabsL0U', 'player'),
(65, 'janvisgupta77@gmail.com', 'tmclaVfE', 'player'),
(66, 'janvisgupta77@gmail.com', 'LR6FdEYO', 'player'),
(67, 'janvisgupta77@gmail.com', 'c4CZpDJv', 'player'),
(68, 'janvisgupta77@gmail.com', 'KJDEb2lU', 'player'),
(69, 'janvisgupta77@gmail.com', 'MKZcJNGR', 'player'),
(70, 'janvisgupta77@gmail.com', 'bRUec41m', 'player'),
(71, 'janvisgupta77@gmail.com', 'e9HhMrTb', 'player'),
(72, 'janvisgupta77@gmail.com', 's8qHh9F3', 'player'),
(73, 'janvisgupta77@gmail.com', 'lvEAbXMG', 'coach'),
(74, 'janvisgupta77@gmail.com', 'KvBiagDr', 'coach'),
(75, 'janvisgupta77@gmail.com', '2vurUfpk', 'player'),
(76, 'janvisgupta77@gmail.com', 'ZdchQlKw', 'coach'),
(77, 'janvisgupta77@gmail.com', 'UsvWoBy9', 'player'),
(78, 'janvisgupta77@gmail.com', 'Aum5E479', 'player'),
(79, 'janvisgupta77@gmail.com', 'LEqTjKPM', 'player'),
(80, 'janvisgupta77@gmail.com', '4zr7qGRK', 'player'),
(81, 'janvigupta1507@gmail.com', 'TzYq7CyV', 'coach'),
(82, 'janvigupta1507@gmail.com', 'EuF5IMGX', 'coach'),
(83, 'janvigupta1507@gmail.com', 'aeGOqpDC', 'coach'),
(84, 'janvigupta1507@gmail.com', 'EIdgXSok', 'coach'),
(85, 'janvigupta1507@gmail.com', '', 'team'),
(86, 'janvigupta1507@gmail.com', '', 'team'),
(87, 'janvigupta1507@gmail.com', '', 'team'),
(88, 'janvigupta1507@gmail.com', '', 'team'),
(89, 'janvigupta1507@gmail.com', '', 'team'),
(90, 'janvigupta1507@gmail.com', 'sXc3gq2V', 'team'),
(91, 'janvigupta1507@gmail.com', 'gp5dVnB6', 'team'),
(92, 'janvigupta1507@gmail.com', 'm3xqakSg', 'team'),
(93, 'janvigupta1507@gmail.com', '3hgOxVTm', 'team'),
(94, 'janvigupta1507@gmail.com', '5fxy0mUw', 'team'),
(95, 'janvigupta1507@gmail.com', 'fOroC2Vn', 'team'),
(96, 'janvigupta1507@gmail.com', 'QPkXLp5M', 'team'),
(97, 'janvigupta1507@gmail.com', 'k7v0YSB1', 'team'),
(98, 'janvigupta1507@gmail.com', 'cgKoCwHv', 'team'),
(99, 'janvigupta1507@gmail.com', 'qHIjZhbW', 'team'),
(100, 'janvigupta1507@gmail.com', '6w2KiQNX', 'team'),
(101, 'janvigupta1507@gmail.com', '14hQvZP6', 'team'),
(102, 'janvigupta1507@gmail.com', 'x94qDJAu', 'coach'),
(103, 'janvigupta1507@gmail.com', 'fOwknCyF', 'coach'),
(104, 'janvigupta1507@gmail.com', 'Uw9qoAXh', 'coach'),
(105, 'janvigupta1507@gmail.com', '1dsmf6Co', 'team'),
(106, 'janvigupta1507@gmail.com', '9lzM3ehv', 'team'),
(107, 'janvigupta1507@gmail.com', '7OXK5WUk', 'team'),
(108, 'janvigupta1507@gmail.com', 'NmIV6SJE', 'team'),
(109, 'janvigupta1507@gmail.com', 'OTcsrRLq', 'team'),
(110, 'janvigupta1507@gmail.com', '1ECOpZBk', 'team'),
(111, 'janvigupta1507@gmail.com', '3ZBa5vOA', 'team'),
(112, 'janvigupta1507@gmail.com', 'Skr2viZN', 'player'),
(113, 'janvisgupta77@gmail.com', 'ZQ5tGfyw', 'player'),
(114, 'janvisgupta77@gmail.com', 'WcVer8S7', 'coach'),
(115, 'janvisgupta77@gmail.com', 'lQn314KW', 'team'),
(116, 'janvisgupta77@gmail.com', 'J4NtV5Ia', 'coach'),
(117, 'janvisgupta77@gmail.com', 'dGc3uJho', 'coach'),
(118, 'janvisgupta77@gmail.com', 'KkBvfzXc', 'coach'),
(119, 'bhavya20029@gmail.com', 'ml2wrLKp', 'team'),
(120, 'bhavya20029@gmail.com', '2YFMgVUA', 'team'),
(121, 'janvisgupta77@gmail.com', 'sqK8zWHf', 'coach'),
(122, 'janvisgupta77@gmail.com', 'ZuxLMwlX', 'player'),
(123, 'janvisgupta77@gmail.com', 'RZzHQNaL', 'player'),
(124, 'bhavya20029@gmail.com', 'v4I9Y0kr', 'team'),
(125, 'aayushi@gmail.com', 'fiuzLKY4', 'player'),
(126, 'aayushi@gmail.com', 'og5OvIWM', 'player'),
(127, 'aayushi@gmail.com', 'flc3bJRN', 'player'),
(128, 'aayushiprajapati73@gmail.com', 't8lXshOR', 'team'),
(129, 'aayushiprajapati73@gmail.com', 'NpiZ6GMV', 'coach');

-- --------------------------------------------------------

--
-- Table structure for table `player`
--

CREATE TABLE `player` (
  `player_id` int(15) NOT NULL,
  `grant_id` int(15) NOT NULL,
  `team_id` int(15) NOT NULL,
  `game_id` int(15) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `m_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `dob` date NOT NULL,
  `contact` bigint(10) NOT NULL,
  `category` varchar(20) NOT NULL,
  `height` int(3) NOT NULL,
  `weight` int(3) NOT NULL,
  `aadharcard_no` bigint(12) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city_village` varchar(20) NOT NULL,
  `district_id` int(15) NOT NULL,
  `taluka_id` int(15) NOT NULL,
  `pincode` int(6) NOT NULL,
  `p_contact` bigint(10) NOT NULL,
  `team_ref` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `player`
--

INSERT INTO `player` (`player_id`, `grant_id`, `team_id`, `game_id`, `f_name`, `m_name`, `l_name`, `email`, `gender`, `dob`, `contact`, `category`, `height`, `weight`, `aadharcard_no`, `address`, `city_village`, `district_id`, `taluka_id`, `pincode`, `p_contact`, `team_ref`) VALUES
(1, 1, 1, 1, 'janvi', 'sanjaykumar', 'gupta', 'janvi@gmail.com', 'f', '2020-09-23', 7656876790, 'open', 170, 55, 2065498701, 'abd', 'abd', 2, 1, 380005, 0, ''),
(2, 1, 2, 1, 'aayushi', 'mukeshkumar', 'prajapati', 'aayushi@gmail.com', 'female', '2003-03-07', 6876778790, 'sc', 167, 50, 678746789878, 'New CG Road,ahmedabad', 'Ahmedabad', 11, 1, 385689, 8656897909, ''),
(3, 1, 3, 3, 'heta', 'navinbhai', 'patel', 'heta@gmail.com', 'Female', '2002-10-29', 7967677898, 'Open', 180, 57, 568687797646, 'patel vas, kanz', 'Kanz', 11, 4, 382139, 7987767899, ''),
(51, 1, 1, 1, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', '', '2003-10-31', 6357693490, 'Open', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7839563056, ''),
(52, 1, 1, 1, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2003-10-31', 6357693490, 'Open', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7839563056, ''),
(53, 1, 1, 2, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2007-11-02', 6357693490, 'Open', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7839563056, ''),
(54, 1, 1, 1, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2020-06-06', 6357693490, 'OBC', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7475689870, ''),
(55, 1, 1, 2, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-12', 6357693490, 'ST', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7475689870, ''),
(56, 1, 1, 2, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-12', 6357693490, 'ST', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7475689870, ''),
(57, 1, 1, 2, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-12', 6357693490, 'ST', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7475689870, ''),
(58, 1, 1, 2, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-12', 6357693490, 'ST', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7475689870, ''),
(59, 1, 1, 2, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-12', 6357693490, 'ST', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7475689870, ''),
(61, 1, 1, 2, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-12', 6357693490, 'ST', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7475689870, ''),
(62, 1, 1, 2, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-12', 6357693490, 'ST', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7475689870, ''),
(63, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-05', 6357693490, 'ST', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7475689870, ''),
(64, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-05', 6357693490, 'ST', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7475689870, ''),
(70, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-26', 8799989676, 'OBC', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8798790870, ''),
(71, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-26', 8799989676, 'OBC', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8798790870, ''),
(72, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-26', 8799989676, 'OBC', 160, 56, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8798790870, ''),
(73, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-18', 8799989676, 'OBC', 160, 67, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8798790870, ''),
(74, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-18', 8799989676, 'OBC', 160, 67, 2147483647, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8798790870, ''),
(75, 1, 1, 3, '', '', '', '', '', '2022-09-26', 0, 'ST', 0, 0, 2147483647, '', '', 2, 1, 0, 8798790870, ''),
(76, 1, 1, 3, '', '', '', '', '', '2022-09-26', 0, 'ST', 0, 0, 368898573949, '', '', 2, 1, 0, 8798790870, ''),
(77, 1, 1, 3, '', '', '', 'janvi1@gmail.com', '', '2022-10-13', 0, 'SC', 0, 0, 368898573949, '', 'Ahmedabad', 2, 1, 0, 8798790870, ''),
(78, 1, 1, 3, 'janvi', 'sanjaykumar', '', 'janvi1@gmail.com', 'Other', '2022-10-11', 8799989676, 'SC', 0, 56, 368898573949, '', 'Ahmedabad', 2, 1, 0, 8798790870, ''),
(79, 1, 1, 3, 'janvi', 'sanjaykumar', '', 'janvi1@gmail.com', 'Other', '2022-10-11', 8799989676, 'SC', 0, 56, 368898573949, '', 'Ahmedabad', 2, 1, 0, 8798790870, ''),
(80, 1, 1, 3, 'janvi', 'sanjaykumar', '', 'janvi1@gmail.com', 'Other', '2022-10-11', 8799989676, 'SC', 0, 56, 368898573949, '', 'Ahmedabad', 2, 1, 0, 8798790870, ''),
(81, 1, 1, 3, 'rthfgnfgn', 'sanjaykumar', '', 'janvi1@gmail.com', 'Female', '2022-10-10', 8799989676, 'Open', 156, 56, 568679678798, '', 'Ahmedabad', 2, 1, 386778, 8798790870, ''),
(82, 1, 1, 3, 'rthfgnfgn', 'sanjaykumar', '', 'janvi1@gmail.com', 'Female', '2022-10-10', 8799989676, 'Open', 156, 56, 568679678798, '', 'Ahmedabad', 2, 1, 386778, 8798790870, ''),
(83, 1, 1, 3, 'abcd', 'efgh', 'pstu', 'abc@3458gmail.com', 'Other', '2022-10-18', 9896787885, 'SC', 156, 78, 568679678798, 'surat', 'kanz', 2, 1, 389008, 8798790870, ''),
(84, 1, 1, 2, 'Hiral', 'vinaykumar', 'pajapati', 'hiral@gmail.com', 'Female', '2022-10-19', 8976797809, 'Open', 130, 40, 796697797646, 'visavas Nani kadi', 'Kadi', 2, 1, 388000, 8797677798, ''),
(85, 1, 1, 2, 'Hiral', 'vinaykumar', 'pajapati', 'hiral@gmail.com', 'Female', '2022-10-19', 8976797809, 'Open', 130, 40, 796697797646, 'visavas Nani kadi', 'Kadi', 2, 1, 388000, 8797677798, ''),
(86, 1, 1, 2, 'Hiral', 'vinaykumar', 'pajapati', 'hiral@gmail.com', 'Female', '2022-10-19', 8976797809, 'Open', 130, 40, 796697797646, 'visavas Nani kadi', 'Kadi', 2, 1, 388000, 8797677798, ''),
(87, 1, 1, 3, 'Mina', 'Vivekbhai', 'Patel', 'mina124@gmail.com', 'Female', '2000-11-27', 9879987096, 'Open', 157, 49, 986768745767, 'Suvarn society, Chandkheda', 'Rampura', 2, 1, 380005, 7890789798, ''),
(88, 1, 1, 3, 'heta', 'navinbhai', 'patel', 'heta@gmail.com', 'Female', '2009-10-22', 9879987096, 'Open', 177, 68, 879757797646, 'Suvarn society, Chandkheda', 'Rampura', 2, 1, 382139, 7890789798, ''),
(89, 1, 1, 3, 'helly', 'manubhai ', 'chauhan', 'helly42@gmailcom', 'Female', '2007-07-24', 8706869898, 'SC', 177, 40, 796898067878, 'motera,ahmedabad', 'motera', 2, 1, 380007, 6798798986, ''),
(90, 1, 1, 3, 'helly', 'manubhai ', 'chauhan', 'helly42@gmailcom', 'Female', '2007-07-24', 8706869898, 'SC', 177, 40, 796898067878, 'motera,ahmedabad', 'motera', 2, 1, 380007, 6798798986, ''),
(91, 1, 1, 3, 'helly', 'manubhai ', 'chauhan', 'helly42@gmailcom', 'Female', '2007-07-24', 8706869898, 'SC', 177, 40, 796898067878, 'motera,ahmedabad', 'motera', 2, 1, 380007, 6798798986, ''),
(92, 1, 1, 3, 'helly', 'manubhai ', 'chauhan', 'helly42@gmailcom', 'Female', '2007-07-24', 8706869898, 'SC', 177, 40, 796898067878, 'motera,ahmedabad', 'motera', 2, 1, 380007, 6798798986, ''),
(93, 1, 1, 3, 'helly', 'manubhai ', 'chauhan', 'helly42@gmailcom', 'Female', '2007-07-24', 8706869898, 'SC', 177, 40, 796898067878, 'motera,ahmedabad', 'motera', 2, 1, 380007, 6798798986, ''),
(94, 1, 1, 3, 'Mina', 'manubhai ', 'pajapati', 'mina124@gmail.com', 'Female', '2022-10-19', 7967677898, 'SC', 157, 49, 879757797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 380005, 7987767899, ''),
(95, 1, 1, 3, 'Mina', 'manubhai ', 'pajapati', 'mina124@gmail.com', 'Female', '2022-10-19', 7967677898, 'SC', 157, 49, 879757797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 380005, 7987767899, ''),
(96, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-18', 8799989676, 'OBC', 170, 67, 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8799989676, ''),
(97, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-18', 8799989676, 'OBC', 170, 67, 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8799989676, ''),
(98, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-18', 8799989676, 'OBC', 170, 67, 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8799989676, ''),
(99, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-18', 8799989676, 'OBC', 170, 67, 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8799989676, ''),
(100, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-18', 8799989676, 'OBC', 170, 67, 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8799989676, ''),
(101, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-18', 8799989676, 'OBC', 170, 67, 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8799989676, ''),
(102, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-18', 8799989676, 'OBC', 170, 67, 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8799989676, ''),
(103, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-18', 8799989676, 'OBC', 170, 67, 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8799989676, ''),
(104, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-18', 8799989676, 'OBC', 170, 67, 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8799989676, ''),
(105, 1, 1, 2, 'rthfgnfgn', 'hirenkumar', 'chavda', 'dfgts23@gmail.com', 'Male', '1996-06-11', 9897698970, 'SC', 170, 78, 897777769880, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8908689676, ''),
(106, 1, 1, 2, 'rthfgnfgn', 'hirenkumar', 'chavda', 'dfgts23@gmail.com', 'Male', '1996-06-11', 9897698970, 'SC', 170, 78, 897777769880, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8908689676, ''),
(107, 1, 1, 2, 'Mina', 'navinbhai', 'Patel', 'janvisgupta77@gmail.com', 'Female', '2022-10-18', 9879987096, 'OBC', 130, 40, 796697797646, 'dfgdfhgf', 'Kadi', 2, 1, 380005, 7890789798, ''),
(108, 1, 1, 2, 'Mina', 'navinbhai', 'Patel', 'janvisgupta77@gmail.com', 'Female', '2022-10-18', 9879987096, 'OBC', 130, 40, 796697797646, 'dfgdfhgf', 'Kadi', 2, 1, 380005, 7890789798, ''),
(109, 1, 1, 2, 'janvi', 'sanjaykumar', 'gupta', 'janvi1@gmail.com', 'Female', '2022-10-25', 8799989676, 'SC', 170, 56, 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8799989676, ''),
(110, 1, 1, 2, 'rahul', 'sanjaykumar', 'gupta', 'janvisgupta77@gmail.com', 'Male', '0000-00-00', 0, 'SC', 170, 67, 568679678798, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 0, ''),
(111, 1, 1, 2, 'janvi', 'sanjaykumar', 'gupta', 'janvigupta1507@gmail.com', 'Female', '2022-10-24', 9896787885, 'SC', 170, 67, 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8799989676, ''),
(112, 1, 1, 2, 'janvi', 'sanjaykumar', 'gupta', 'janvigupta1507@gmail.com', 'Female', '2022-10-24', 9896787885, 'SC', 170, 67, 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 8799989676, ''),
(113, 1, 1, 3, 'janvi', 'sanjaykumar', 'gupta', 'janvigupta1507@gmail.com', 'Female', '2010-10-14', 6357693490, 'OBC', 170, 56, 368898573949, 'ahmedabad', 'Ahmedabad', 2, 1, 386778, 7475689870, ''),
(114, 1, 1, 2, 'Hiral', 'vinaykumar', 'pajapati', 'paayushi908@gmail.com', 'Female', '2022-10-12', 7967677898, 'SC', 130, 57, 568687797646, 'rampura,abd', 'Kadi', 2, 1, 380005, 8797677798, ''),
(115, 1, 1, 2, 'Hiral', 'vinaykumar', 'pajapati', 'janvisgupta77@gmail.com', 'Female', '2022-12-30', 7967677898, 'SC', 130, 40, 986768745767, 'd,mngdfj', 'Kanz', 2, 1, 388000, 7987767899, ''),
(116, 1, 1, 2, 'janvi', 'manubhai ', 'pajapati', 'janvisgupta77@gmail.com', 'Female', '2010-08-30', 8976797809, 'SC', 130, 57, 986768745767, 'fdghgf', 'Kadi', 2, 1, 380005, 7987767899, '12fjgj'),
(117, 1, 1, 2, 'janvi', 'manubhai ', 'pajapati', 'janvisgupta77@gmail.com', 'Female', '2010-08-30', 8976797809, 'SC', 130, 57, 986768745767, 'fdghgf', 'Kadi', 2, 1, 380005, 7987767899, '12fjgj'),
(118, 1, 1, 2, 'janvi', 'manubhai ', 'pajapati', 'janvisgupta77@gmail.com', 'Female', '2010-08-30', 8976797809, 'SC', 130, 57, 986768745767, 'fdghgf', 'Kadi', 2, 1, 380005, 7987767899, '12fjgj'),
(119, 1, 1, 2, 'heta', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 'Female', '2014-12-29', 7967677898, 'OBC', 180, 40, 796697797646, 'abd', 'Kanz', 2, 1, 380005, 7890789798, 'djnf9'),
(120, 1, 1, 2, 'heta', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 'Female', '2014-12-29', 7967677898, 'OBC', 180, 40, 796697797646, 'abd', 'Kanz', 2, 1, 380005, 7890789798, 'djnf9'),
(121, 1, 1, 2, 'heta', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 'Female', '2014-12-29', 7967677898, 'OBC', 180, 40, 796697797646, 'abd', 'Kanz', 2, 1, 380005, 7890789798, 'djnf9'),
(122, 1, 1, 2, 'heta', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 'Female', '2014-12-29', 7967677898, 'OBC', 180, 40, 796697797646, 'abd', 'Kanz', 2, 1, 380005, 7890789798, 'djnf9'),
(123, 1, 1, 2, 'heta', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 'Female', '2014-12-29', 7967677898, 'OBC', 180, 40, 796697797646, 'abd', 'Kanz', 2, 1, 380005, 7890789798, 'djnf9'),
(124, 1, 1, 2, 'heta', 'manubhai ', 'pajapati', 'janvisgupta77@gmail.com', 'Female', '2017-12-30', 9879987096, 'ST', 180, 40, 796697797646, 'ahmedabad', 'Kanz', 2, 1, 388000, 7987767899, ''),
(125, 1, 1, 3, 'heta', 'navinbhai', 'pajapati', 'janvigupta1507@gmail.com', 'Female', '2022-12-30', 9879987096, 'OBC', 157, 40, 796697797646, 'Suvarn society, Chandkheda', 'Rampura', 2, 1, 380005, 7890789798, ''),
(126, 1, 1, 3, 'Hiral', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 'Other', '2022-12-28', 9879987096, 'OBC', 177, 57, 986768745767, 'Suvarn society, Chandkheda', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(127, 1, 1, 2, 'Hiral', 'navinbhai', 'Patel', 'janvisgupta77@gmail.com', 'Female', '2011-12-30', 7967677898, 'ST', 180, 57, 568687797646, 'sdfknskj', 'Kadi', 2, 1, 388000, 7987767899, ''),
(128, 1, 1, 2, 'Hiral', 'navinbhai', 'Patel', 'janvisgupta77@gmail.com', 'Female', '2011-12-30', 7967677898, 'ST', 180, 57, 568687797646, 'sdfknskj', 'Kadi', 2, 1, 388000, 7987767899, ''),
(129, 1, 1, 2, 'heta', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 'Female', '2020-10-31', 9879987096, 'OBC', 180, 57, 796697797646, 'ahmedabad', 'Kadi', 2, 1, 382139, 7890789798, ''),
(130, 1, 1, 2, 'Mina', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 'Male', '2022-10-20', 9879987096, 'SC', 180, 45, 879757797646, 'sgfmdm', 'Kanz', 2, 1, 388000, 7987767899, ''),
(131, 1, 1, 3, 'heta', 'mukesbhai', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2010-12-30', 9879987096, 'ST', 157, 57, 986768745767, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(132, 1, 1, 3, 'heta', 'mukesbhai', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2010-12-30', 9879987096, 'ST', 157, 57, 986768745767, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(133, 1, 1, 3, 'heta', 'mukesbhai', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2010-12-30', 9879987096, 'ST', 157, 57, 986768745767, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(134, 1, 1, 3, 'Mina', 'manubhai ', 'Patel', 'janvigupta1507@gmail.com', 'Other', '2022-12-28', 9879987096, 'SC', 157, 40, 568687797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(135, 1, 1, 3, 'Mina', 'manubhai ', 'Patel', 'janvigupta1507@gmail.com', 'Other', '2022-12-28', 9879987096, 'SC', 157, 40, 568687797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(136, 1, 1, 3, 'Mina', 'manubhai ', 'Patel', 'janvigupta1507@gmail.com', 'Other', '2022-12-28', 9879987096, 'SC', 157, 40, 568687797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(137, 1, 1, 3, 'helly', 'vinaykumar', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2022-09-26', 8976797809, 'Open', 157, 49, 879757797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 382139, 8797677798, ''),
(138, 1, 1, 3, 'helly', 'vinaykumar', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2022-09-26', 8976797809, 'Open', 157, 49, 879757797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 382139, 8797677798, ''),
(139, 1, 1, 3, 'helly', 'vinaykumar', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2022-09-26', 8976797809, 'Open', 157, 49, 879757797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 382139, 8797677798, ''),
(140, 1, 1, 3, 'helly', 'vinaykumar', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2022-09-26', 8976797809, 'Open', 157, 49, 879757797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 382139, 8797677798, ''),
(141, 1, 1, 3, 'helly', 'vinaykumar', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2022-09-26', 8976797809, 'Open', 157, 49, 879757797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 382139, 8797677798, ''),
(142, 1, 1, 3, 'helly', 'vinaykumar', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2022-09-26', 8976797809, 'Open', 157, 49, 879757797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 382139, 8797677798, ''),
(143, 1, 1, 3, 'helly', 'vinaykumar', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2022-09-26', 8976797809, 'Open', 157, 49, 879757797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 382139, 8797677798, ''),
(144, 1, 1, 3, 'helly', 'vinaykumar', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2022-09-26', 8976797809, 'Open', 157, 49, 879757797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 382139, 8797677798, ''),
(145, 1, 1, 3, 'helly', 'vinaykumar', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2022-09-26', 8976797809, 'Open', 157, 49, 879757797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 382139, 8797677798, ''),
(146, 1, 1, 3, 'helly', 'vinaykumar', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2022-09-26', 8976797809, 'Open', 157, 49, 879757797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 382139, 8797677798, ''),
(147, 1, 1, 3, 'helly', 'vinaykumar', 'Patel', 'janvigupta1507@gmail.com', 'Female', '2022-09-26', 8976797809, 'Open', 157, 49, 879757797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 382139, 8797677798, ''),
(148, 1, 1, 3, 'Mina', 'navinbhai', 'Patel', 'janvigupta1507@gmail.com', 'Male', '2015-09-29', 9879987096, 'ST', 177, 40, 986768745767, 'Suvarn society, Chandkheda', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(149, 1, 1, 3, 'Mina', 'navinbhai', 'Patel', 'janvigupta1507@gmail.com', 'Male', '2015-09-29', 9879987096, 'ST', 177, 40, 986768745767, 'Suvarn society, Chandkheda', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(150, 1, 1, 3, 'Mina', 'navinbhai', 'Patel', 'janvigupta1507@gmail.com', 'Male', '2015-09-29', 9879987096, 'ST', 177, 40, 986768745767, 'Suvarn society, Chandkheda', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(151, 1, 1, 3, 'Mina', 'navinbhai', 'Patel', 'janvigupta1507@gmail.com', 'Male', '2015-09-29', 9879987096, 'ST', 177, 40, 986768745767, 'Suvarn society, Chandkheda', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(152, 1, 1, 3, 'Mina', 'navinbhai', 'Patel', 'janvigupta1507@gmail.com', 'Male', '2015-09-29', 9879987096, 'ST', 177, 40, 986768745767, 'Suvarn society, Chandkheda', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(153, 1, 1, 3, 'Mina', 'navinbhai', 'Patel', 'janvigupta1507@gmail.com', 'Male', '2015-09-29', 9879987096, 'ST', 177, 40, 986768745767, 'Suvarn society, Chandkheda', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(154, 1, 1, 3, 'Mina', 'navinbhai', 'Patel', 'janvigupta1507@gmail.com', 'Male', '2015-09-29', 9879987096, 'ST', 177, 40, 986768745767, 'Suvarn society, Chandkheda', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(155, 1, 1, 2, 'Mina', 'vinaykumar', 'gupta', 'janvigupta1507@gmail.com', 'Male', '2015-12-29', 9879987096, 'ST', 180, 40, 986768745767, 'abd', 'Kadi', 2, 1, 388000, 8797677798, ''),
(156, 1, 1, 1, 'Mina', 'navinbhai', 'Patel', 'janvisgupta77@gmail.com', 'Female', '2022-12-31', 7967677898, 'Open', 180, 40, 796697797646, 'dsdlfndskjg', 'Kadi', 2, 1, 380005, 7890789798, ''),
(157, 1, 1, 3, 'heta', 'navinbhai', 'Patel', 'janvisgupta77@gmail.com', 'Female', '2009-06-27', 9879987096, 'Open', 177, 40, 123456987899, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 380005, 7890789798, ''),
(158, 1, 1, 3, 'helly', 'mukesbhai', 'patel', 'bhavya20029@gmail.com', 'Male', '2022-10-16', 7967677898, 'Open', 157, 57, 796697797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 380007, 8797677798, ''),
(159, 1, 1, 3, 'helly', 'mukesbhai', 'patel', 'bhavya20029@gmail.com', 'Male', '2022-10-16', 7967677898, 'Open', 157, 57, 796697797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 380007, 8797677798, ''),
(160, 1, 1, 3, 'helly', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 'Male', '2021-10-31', 9879987096, 'ST', 130, 40, 986768745767, 'as,mfndskj', 'Kadi', 2, 1, 380005, 7890789798, ''),
(161, 1, 1, 3, 'helly', 'navinbhai', 'pajapati', 'janvisgupta77@gmail.com', 'Male', '2021-10-31', 9879987096, 'ST', 130, 40, 986768745767, 'as,mfndskj', 'Kadi', 2, 1, 380005, 7890789798, ''),
(162, 1, 1, 3, 'helly', 'mukesbhai', 'patel', 'bhavya20029@gmail.com', 'Male', '2022-10-16', 7967677898, 'Open', 157, 57, 796697797646, 'motera,ahmedabad', 'Ahmedabad', 2, 1, 380007, 8797677798, ''),
(163, 1, 1, 2, 'Aayushi', 'M', 'Prajapati', 'aayushi@gmail.com', 'Female', '2022-11-02', 7987746455, 'OBC', 180, 45, 122256568989, 'Ahmedabad', 'Ahmedabad', 2, 1, 380005, 8745693210, ''),
(164, 1, 1, 2, 'Aayushi', 'M', 'Prajapati', 'aayushi@gmail.com', 'Female', '2022-11-02', 7987746455, 'OBC', 180, 45, 122256568989, 'Ahmedabad', 'Ahmedabad', 2, 1, 380005, 8745693210, ''),
(165, 1, 1, 2, 'Aayushi', 'M', 'Prajapati', 'aayushi@gmail.com', 'Female', '2022-11-08', 7987746455, 'OBC', 5, 45, 122256568989, 'Ahmedabad', 'Ahmedabad', 2, 1, 380005, 8745693210, ''),
(166, 1, 1, 3, 'Aayushi', 'M', 'Prajapati', 'aayushiprajapati73@gmail.com', 'Female', '2022-11-09', 9874563210, 'OBC', 156, 55, 122256568989, 'Ahmedabad', 'Ahmedabad', 2, 1, 380005, 8745693210, '');

-- --------------------------------------------------------

--
-- Table structure for table `taluka`
--

CREATE TABLE `taluka` (
  `taluka_id` int(15) NOT NULL,
  `taluka_name` varchar(50) NOT NULL,
  `district_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taluka`
--

INSERT INTO `taluka` (`taluka_id`, `taluka_name`, `district_id`) VALUES
(1, 'Detroj', 0),
(4, 'daskoi', 1);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `team_id` int(15) NOT NULL,
  `game_id` int(15) NOT NULL,
  `coach_id` int(15) NOT NULL,
  `leader_id` int(15) NOT NULL,
  `team_name` varchar(50) NOT NULL,
  `total_member` int(2) NOT NULL,
  `team_ref` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`team_id`, `game_id`, `coach_id`, `leader_id`, `team_name`, `total_member`, `team_ref`) VALUES
(1, 2, 2, 1, 'Techbenders', 12, ''),
(2, 1, 1, 1, 'sikhsha', 1, ''),
(3, 1, 1, 1, 'sikhsha', 1, ''),
(4, 1, 1, 1, 'sikhsha', 2, ''),
(5, 1, 1, 1, 'sikhsha', 2, ''),
(6, 1, 1, 1, 'sikhsha', 1, ''),
(7, 1, 1, 1, 'sikhsha', 1, ''),
(8, 1, 1, 1, 'sikhsha', 12, ''),
(9, 1, 1, 1, 'asfsgsdhgfs', 1, ''),
(10, 1, 1, 1, 'asfsgsdhgfs', 1, ''),
(11, 1, 1, 1, 'asfsgsdhgfs', 1, ''),
(12, 1, 1, 1, 'asfsgsdhgfs', 2, ''),
(13, 1, 1, 1, 'asfsgsdhgfs', 2, ''),
(14, 1, 1, 1, 'happy', 4, ''),
(15, 1, 1, 1, 'Mitrata', 12, 'da39a3ee5e6b4b0d3255bfef9'),
(16, 1, 1, 1, 'Mitrata', 12, 'URFZ7ujz'),
(17, 1, 1, 1, 'Ekata', 15, 'FkV3DvaJ'),
(18, 1, 1, 1, 'Ekata', 15, 'ozxfC9ZR'),
(19, 1, 1, 1, 'Ekata', 15, '04M5FdHp'),
(20, 1, 1, 1, 'Ekata', 15, '6zBeD1tH'),
(21, 1, 1, 1, 'Ekata', 15, '8w3uPnYa'),
(22, 1, 1, 1, 'Mitrata', 10, 'UYZ6EBI9'),
(23, 1, 1, 1, 'Mitrata', 10, 'oZ6Lec8q'),
(24, 1, 1, 1, 'Ekata', 12, 'rsp7CMBd'),
(25, 1, 1, 1, 'janvi', 15, 'eOYDnJtU'),
(26, 1, 1, 1, 'kajal', 15, 'sdlKupJ6'),
(27, 1, 1, 1, 'kajal', 15, 'qvkwYIlj'),
(28, 1, 1, 1, 'kajal', 15, 'G3NrSRJ0'),
(29, 1, 1, 1, 'Mitrata', 16, 'uw2KPhRr'),
(30, 1, 1, 1, 'Mitrata', 16, 'Yg8uUqzx'),
(31, 1, 1, 1, 'Mitrata', 16, 'ovHPLrEd'),
(32, 1, 1, 1, 'Ekata', 12, 'sLyf9eV6'),
(33, 1, 1, 1, 'Ekata', 12, '1tLlUvqu'),
(34, 1, 1, 1, 'Ekata', 12, '5ot6vJlH'),
(35, 1, 1, 1, 'Ekata', 12, 'nNTtCERA'),
(36, 1, 1, 1, 'Ekata', 12, 'ONoW3ARU'),
(37, 1, 1, 1, 'Ekata', 12, '0bKYmLdM'),
(38, 1, 1, 1, 'Ekata', 12, '0ewBGY7J'),
(39, 1, 1, 1, 'Ekata', 12, 'HAm9yKFG'),
(40, 1, 1, 1, 'Ekata', 12, 'bisyeJkc'),
(41, 1, 1, 1, 'Ekata', 12, '3J1cNLVs'),
(42, 1, 1, 1, 'Ekata', 12, 'bqSfGCzK'),
(43, 1, 1, 1, 'Mitrata', 12, 'fy4iGpPc'),
(44, 1, 1, 1, 'Mitrata', 12, 'xFlLVR2i'),
(45, 1, 1, 1, 'Mitrata', 12, '5dDOZY9P'),
(46, 1, 1, 1, 'Mitrata', 12, 'WdGzcf8t'),
(47, 1, 1, 1, 'Mitrata', 12, 'fGK5kuQw'),
(48, 1, 1, 1, 'Mitrata', 12, 'QThxiO5y'),
(49, 1, 1, 1, 'Mitrata', 12, 'w8OBClkJ'),
(50, 1, 1, 1, 'kirtan', 15, 'Rg4I2cln'),
(51, 1, 1, 1, 'Mitrata', 12, 'QaXptj8r'),
(52, 1, 1, 1, 'Mitrata', 12, 'Vlig3yIS'),
(53, 1, 1, 1, 'Mitrata', 12, 'TFtagSCu'),
(54, 1, 1, 1, 'XYZ', 12, 'JhKeVEwD');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `coach_registration`
--
ALTER TABLE `coach_registration`
  ADD PRIMARY KEY (`coach_id`),
  ADD KEY `game_id` (`game_id`),
  ADD KEY `team_id` (`team_id`),
  ADD KEY `district_id` (`district_id`),
  ADD KEY `taluka_id` (`taluka_id`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`district_id`);

--
-- Indexes for table `game`
--
ALTER TABLE `game`
  ADD PRIMARY KEY (`game_id`);

--
-- Indexes for table `grant`
--
ALTER TABLE `grant`
  ADD PRIMARY KEY (`grant_id`);

--
-- Indexes for table `institutes`
--
ALTER TABLE `institutes`
  ADD PRIMARY KEY (`Institue_ID`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `player`
--
ALTER TABLE `player`
  ADD PRIMARY KEY (`player_id`),
  ADD KEY `scholarship_id` (`grant_id`),
  ADD KEY `team_id` (`team_id`),
  ADD KEY `game_id` (`game_id`),
  ADD KEY `district_id` (`district_id`),
  ADD KEY `taluka_id` (`taluka_id`),
  ADD KEY `district_id_2` (`district_id`),
  ADD KEY `taluka_id_2` (`taluka_id`);

--
-- Indexes for table `taluka`
--
ALTER TABLE `taluka`
  ADD PRIMARY KEY (`taluka_id`),
  ADD KEY `district_id` (`district_id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`team_id`),
  ADD KEY `game_id` (`game_id`),
  ADD KEY `coach_id` (`coach_id`),
  ADD KEY `leader_id` (`leader_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `coach_registration`
--
ALTER TABLE `coach_registration`
  MODIFY `coach_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `district`
--
ALTER TABLE `district`
  MODIFY `district_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `game`
--
ALTER TABLE `game`
  MODIFY `game_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `grant`
--
ALTER TABLE `grant`
  MODIFY `grant_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `institutes`
--
ALTER TABLE `institutes`
  MODIFY `Institue_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT for table `player`
--
ALTER TABLE `player`
  MODIFY `player_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=167;

--
-- AUTO_INCREMENT for table `taluka`
--
ALTER TABLE `taluka`
  MODIFY `taluka_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `team_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `coach_registration`
--
ALTER TABLE `coach_registration`
  ADD CONSTRAINT `coach_registration_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `game` (`game_id`),
  ADD CONSTRAINT `coach_registration_ibfk_2` FOREIGN KEY (`team_id`) REFERENCES `team` (`team_id`);

--
-- Constraints for table `player`
--
ALTER TABLE `player`
  ADD CONSTRAINT `player_ibfk_1` FOREIGN KEY (`grant_id`) REFERENCES `grant` (`grant_id`),
  ADD CONSTRAINT `player_ibfk_2` FOREIGN KEY (`game_id`) REFERENCES `game` (`game_id`),
  ADD CONSTRAINT `player_ibfk_3` FOREIGN KEY (`district_id`) REFERENCES `district` (`district_id`),
  ADD CONSTRAINT `player_ibfk_4` FOREIGN KEY (`taluka_id`) REFERENCES `taluka` (`taluka_id`),
  ADD CONSTRAINT `player_ibfk_5` FOREIGN KEY (`team_id`) REFERENCES `team` (`team_id`);

--
-- Constraints for table `team`
--
ALTER TABLE `team`
  ADD CONSTRAINT `team_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `game` (`game_id`),
  ADD CONSTRAINT `team_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `player` (`player_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
