-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2022 at 02:56 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `khel_mahakumbh`
--

-- --------------------------------------------------------

--
-- Table structure for table `coach registration`
--

CREATE TABLE `coach registration` (
  `coach_id` int(15) NOT NULL,
  `game_id` int(15) NOT NULL,
  `team_id` int(15) NOT NULL,
  `f_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `m_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `l_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `Email` varchar(25) COLLATE utf8_bin NOT NULL,
  `Contact` bigint(10) NOT NULL,
  `DOB` date NOT NULL,
  `Category` varchar(20) COLLATE utf8_bin NOT NULL,
  `Gender` varchar(10) COLLATE utf8_bin NOT NULL,
  `Address` varchar(100) COLLATE utf8_bin NOT NULL,
  `City/Village` varchar(20) COLLATE utf8_bin NOT NULL,
  `District` varchar(20) COLLATE utf8_bin NOT NULL,
  `Taluka` varchar(20) COLLATE utf8_bin NOT NULL,
  `Pin code` int(6) NOT NULL,
  `Height` int(3) NOT NULL,
  `Weight` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `coach registration`
--

INSERT INTO `coach registration` (`coach_id`, `game_id`, `team_id`, `f_name`, `m_name`, `l_name`, `Email`, `Contact`, `DOB`, `Category`, `Gender`, `Address`, `City/Village`, `District`, `Taluka`, `Pin code`, `Height`, `Weight`) VALUES
(1, 1, 1, 'Kapil Dev', 'Ram Lal', 'Nikhanj', 'kapildev6@gmail.com', 8745782596, '1969-01-06', 'Open', 'Male', '39, Sundar Nagar, New Delhi.', 'Sundar Nagar', 'Southern District of', 'New Delhi', 110093, 183, 80),
(2, 2, 2, 'Pullela', 'Subhash', 'Gopichand', 'gopichand4@gmail.com', 9425458765, '1973-11-16', 'Open', 'Male', '23, Nagandla, Prakasam, Andhra Pradesh', 'Nagandla', 'Prakasam', 'Prakasam', 523190, 183, 64);

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE `district` (
  `district_id` int(15) NOT NULL,
  `district_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`district_id`, `district_name`) VALUES
(2, 'Surat'),
(11, 'Ahmedabad');

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

CREATE TABLE `game` (
  `game_id` int(15) NOT NULL,
  `game_name` varchar(50) NOT NULL,
  `game_player` varchar(50) NOT NULL,
  `game_duration` datetime NOT NULL,
  `game_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game`
--

INSERT INTO `game` (`game_id`, `game_name`, `game_player`, `game_duration`, `game_type`) VALUES
(1, 'chess', '2', '2022-09-05 03:00:00', 'single'),
(2, 'kho-kho', '12', '2022-09-30 00:45:00', 'team'),
(3, 'badminton', '2', '2022-09-30 00:50:00', 'double');

-- --------------------------------------------------------

--
-- Table structure for table `grant`
--

CREATE TABLE `grant` (
  `grant_id` int(15) NOT NULL,
  `grant_name` varchar(25) NOT NULL,
  `grant_type` varchar(25) NOT NULL,
  `grant_amount` bigint(10) NOT NULL,
  `grant_status` int(10) NOT NULL,
  `grant_level` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grant`
--

INSERT INTO `grant` (`grant_id`, `grant_name`, `grant_type`, `grant_amount`, `grant_status`, `grant_level`) VALUES
(1, 'student ssholarship', 'game', 30000, 1, 'institute');

-- --------------------------------------------------------

--
-- Table structure for table `player`
--

CREATE TABLE `player` (
  `player_id` int(15) NOT NULL,
  `grant_id` int(15) NOT NULL,
  `team_id` int(15) NOT NULL,
  `game_id` int(15) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `m_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` enum('m','f','o') NOT NULL,
  `dob` date NOT NULL,
  `contact` bigint(10) NOT NULL,
  `category` varchar(20) NOT NULL,
  `height` int(3) NOT NULL,
  `weight` int(3) NOT NULL,
  `aadharcard_no` int(12) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city_village` varchar(20) NOT NULL,
  `district_id` int(15) NOT NULL,
  `taluka_id` int(15) NOT NULL,
  `pincode` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `player`
--

INSERT INTO `player` (`player_id`, `grant_id`, `team_id`, `game_id`, `f_name`, `m_name`, `l_name`, `email`, `gender`, `dob`, `contact`, `category`, `height`, `weight`, `aadharcard_no`, `address`, `city_village`, `district_id`, `taluka_id`, `pincode`) VALUES
(1, 1, 1, 1, 'janvi', 'sanjaykumar', 'gupta', 'janvi@gmail.com', 'f', '2020-09-23', 7656876790, 'open', 170, 55, 2065498701, 'abd', 'abd', 2, 1, 380005);

-- --------------------------------------------------------

--
-- Table structure for table `taluka`
--

CREATE TABLE `taluka` (
  `taluka_id` int(15) NOT NULL,
  `taluka_name` varchar(50) NOT NULL,
  `district_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taluka`
--

INSERT INTO `taluka` (`taluka_id`, `taluka_name`, `district_id`) VALUES
(1, 'Detroj', 0),
(4, 'daskoi', 1);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `team_id` int(15) NOT NULL,
  `game_id` int(15) NOT NULL,
  `coach_id` int(15) NOT NULL,
  `leader_id` int(15) NOT NULL,
  `team_name` varchar(50) NOT NULL,
  `total_member` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`team_id`, `game_id`, `coach_id`, `leader_id`, `team_name`, `total_member`) VALUES
(1, 2, 2, 1, 'Techbenders', 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `coach registration`
--
ALTER TABLE `coach registration`
  ADD PRIMARY KEY (`coach_id`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`district_id`);

--
-- Indexes for table `game`
--
ALTER TABLE `game`
  ADD PRIMARY KEY (`game_id`);

--
-- Indexes for table `grant`
--
ALTER TABLE `grant`
  ADD PRIMARY KEY (`grant_id`);

--
-- Indexes for table `player`
--
ALTER TABLE `player`
  ADD PRIMARY KEY (`player_id`),
  ADD KEY `scholarship_id` (`grant_id`),
  ADD KEY `team_id` (`team_id`),
  ADD KEY `game_id` (`game_id`),
  ADD KEY `district_id` (`district_id`),
  ADD KEY `taluka_id` (`taluka_id`),
  ADD KEY `district_id_2` (`district_id`),
  ADD KEY `taluka_id_2` (`taluka_id`);

--
-- Indexes for table `taluka`
--
ALTER TABLE `taluka`
  ADD PRIMARY KEY (`taluka_id`),
  ADD KEY `district_id` (`district_id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`team_id`),
  ADD KEY `game_id` (`game_id`),
  ADD KEY `coach_id` (`coach_id`),
  ADD KEY `leader_id` (`leader_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `coach registration`
--
ALTER TABLE `coach registration`
  MODIFY `coach_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `district`
--
ALTER TABLE `district`
  MODIFY `district_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `game`
--
ALTER TABLE `game`
  MODIFY `game_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `grant`
--
ALTER TABLE `grant`
  MODIFY `grant_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `player`
--
ALTER TABLE `player`
  MODIFY `player_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `taluka`
--
ALTER TABLE `taluka`
  MODIFY `taluka_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `team_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `player`
--
ALTER TABLE `player`
  ADD CONSTRAINT `player_ibfk_1` FOREIGN KEY (`grant_id`) REFERENCES `grant` (`grant_id`),
  ADD CONSTRAINT `player_ibfk_2` FOREIGN KEY (`game_id`) REFERENCES `game` (`game_id`),
  ADD CONSTRAINT `player_ibfk_3` FOREIGN KEY (`district_id`) REFERENCES `district` (`district_id`),
  ADD CONSTRAINT `player_ibfk_4` FOREIGN KEY (`taluka_id`) REFERENCES `taluka` (`taluka_id`),
  ADD CONSTRAINT `player_ibfk_5` FOREIGN KEY (`team_id`) REFERENCES `team` (`team_id`);

--
-- Constraints for table `team`
--
ALTER TABLE `team`
  ADD CONSTRAINT `team_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `game` (`game_id`),
  ADD CONSTRAINT `team_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `player` (`player_id`),
  ADD CONSTRAINT `team_ibfk_3` FOREIGN KEY (`coach_id`) REFERENCES `coach registration` (`coach_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
